/*
 * ACCELEROMETER OFFSET AUTO-CALIBRATION
 * STM32F405 + ICM-20602 (SPI)
 *
 * Run this ONCE. Place the drone PERFECTLY FLAT and LEVEL on a surface
 * you trust (check with a spirit level / phone level app if possible).
 * Keep it dead still. It averages 2000 samples and prints the exact
 * three lines you paste into gyro_signals() in the stabilize firmware.
 *
 * WIRING: SCK=PA5 MISO=PA6 MOSI=PA7 CS=PA4  VCC=3V3
 */

#include <SPI.h>
#define PIN_CS PA4

#define REG_CONFIG 0x1A
#define REG_GYRO_CONFIG 0x1B
#define REG_ACCEL_CONFIG 0x1C
#define REG_ACCEL_CONFIG_2 0x1D
#define REG_SMPLRT_DIV 0x19
#define REG_ACCEL_XOUT_H 0x3B
#define REG_SIGPATH_RESET 0x68
#define REG_USER_CTRL 0x6A
#define REG_PWR_MGMT_1 0x6B
#define REG_PWR_MGMT_2 0x6C
#define REG_WHO_AM_I 0x75
#define ICM_WHOAMI 0x12

static SPISettings SPI_SLOW(1000000, MSBFIRST, SPI_MODE3);
static SPISettings SPI_FAST(8000000, MSBFIRST, SPI_MODE3);

static void icmWrite(uint8_t reg, uint8_t val) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg & 0x7F); SPI.transfer(val);
  digitalWrite(PIN_CS, HIGH); SPI.endTransaction();
  delayMicroseconds(20);
}
static uint8_t icmRead(uint8_t reg) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  uint8_t v = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH); SPI.endTransaction();
  return v;
}
static void icmBurst(uint8_t reg, uint8_t *buf, uint8_t len) {
  SPI.beginTransaction(SPI_FAST);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  for (uint8_t i = 0; i < len; i++) buf[i] = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH); SPI.endTransaction();
}

void setup() {
  Serial.begin(57600);
  while (!Serial) {}
  pinMode(PIN_CS, OUTPUT); digitalWrite(PIN_CS, HIGH);
  SPI.begin(); delay(100);

  icmWrite(REG_PWR_MGMT_1, 0x80); delay(100);
  icmWrite(REG_SIGPATH_RESET, 0x03); delay(100);
  icmWrite(REG_USER_CTRL, 0x10);
  icmWrite(REG_PWR_MGMT_1, 0x01);
  icmWrite(REG_PWR_MGMT_2, 0x00); delay(20);

  if (icmRead(REG_WHO_AM_I) != ICM_WHOAMI) {
    Serial.println("ICM-20602 not found. Check wiring.");
    while (1) {}
  }
  icmWrite(REG_SMPLRT_DIV, 0x00);
  icmWrite(REG_CONFIG, 0x05);
  icmWrite(REG_GYRO_CONFIG, 0x08);
  icmWrite(REG_ACCEL_CONFIG, 0x10);
  icmWrite(REG_ACCEL_CONFIG_2, 0x05);
  delay(50);

  Serial.println("Keep the drone FLAT and STILL. Measuring in 3s...");
  delay(3000);

  double sx = 0, sy = 0, sz = 0;
  const int N = 2000;
  for (int i = 0; i < N; i++) {
    uint8_t b[6];
    icmBurst(REG_ACCEL_XOUT_H, b, 6);
    int16_t ax = (int16_t)((b[0] << 8) | b[1]);
    int16_t ay = (int16_t)((b[2] << 8) | b[3]);
    int16_t az = (int16_t)((b[4] << 8) | b[5]);
    sx += (double)ax / 4096.0;
    sy += (double)ay / 4096.0;
    sz += (double)az / 4096.0;
    delay(1);
  }
  float mx = sx / N, my = sy / N, mz = sz / N;

  // offsets that make flat reading = (0, 0, 1)
  float offX = -mx;
  float offY = -my;
  float offZ = 1.0 - mz;

  Serial.println();
  Serial.println("======== MEASURED (flat) ========");
  Serial.print("AccX="); Serial.print(mx, 4);
  Serial.print("  AccY="); Serial.print(my, 4);
  Serial.print("  AccZ="); Serial.println(mz, 4);
  Serial.println();
  Serial.println("Paste these 3 lines into gyro_signals():");
  Serial.println("---------------------------------------------");
  Serial.print("  AccX = (float)ax / 4096.0 + ("); Serial.print(offX, 4); Serial.println(");");
  Serial.print("  AccY = (float)ay / 4096.0 + ("); Serial.print(offY, 4); Serial.println(");");
  Serial.print("  AccZ = (float)az / 4096.0 + ("); Serial.print(offZ, 4); Serial.println(");");
  Serial.println("---------------------------------------------");

  // sanity check on the gravity vector magnitude
  float mag = sqrt(mx*mx + my*my + mz*mz);
  Serial.print("Gravity magnitude = "); Serial.print(mag, 4);
  if (mag < 0.95 || mag > 1.05)
    Serial.println("  <-- WARNING: not ~1.0, check ACCEL scale or sensor");
  else
    Serial.println("  (good, ~1.0)");
}

void loop() {}
