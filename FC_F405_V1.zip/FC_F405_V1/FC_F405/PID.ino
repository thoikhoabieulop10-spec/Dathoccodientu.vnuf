/* ===== TAB PID — hàm PID dùng chung cho mọi tầng ===== */

void pid_equation(float Error, float P, float I, float D,
                  float PrevError, float PrevIterm) {
  float Pterm = P * Error;
  float Iterm = PrevIterm + I * (Error + PrevError) * 0.004 / 2.0;
  // Anti-windup clamp. Tightened from 400 to 150 to stop the integral
  // term slowly building up and causing a diagonal wobble after a couple
  // of minutes. If the drone drifts (never quite levels), raise toward
  // 200. If it still wobbles after minutes, lower toward 100.
  if (Iterm > 150) Iterm = 150; else if (Iterm < -150) Iterm = -150;
  float Dterm = D * (Error - PrevError) / 0.004;
  float out = Pterm + Iterm + Dterm;
  if (out > 400) out = 400; else if (out < -400) out = -400;
  PIDReturn[0] = out; PIDReturn[1] = Error; PIDReturn[2] = Iterm;
}
void reset_pid(void) {
  PrevErrorRateRoll = PrevErrorRatePitch = PrevErrorRateYaw = 0;
  PrevItermRateRoll = PrevItermRatePitch = PrevItermRateYaw = 0;
  PrevErrorAngleRoll = PrevErrorAnglePitch = 0;
  PrevItermAngleRoll = PrevItermAnglePitch = 0;
}
