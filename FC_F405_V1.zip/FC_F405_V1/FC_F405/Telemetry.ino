/* =====================================================================
 *  TAB TELEMETRY — gửi dữ liệu bay & nhận lệnh PID qua BLE (DL-20)
 *
 *  DL-20 (chip CC2540) là module BLE UART, nối vào USART1:
 *     DL-20 TX -> PA10 (USART1_RX)
 *     DL-20 RX -> PA9  (USART1_TX)   [PA9 ra 3.3V, cắm thẳng an toàn]
 *     VCC 5V (hoặc 3.3V tùy module), GND
 *
 *  GIAO THỨC (text, xuống dòng '\n'):
 *    Gửi ĐI (drone -> web), 20 lần/giây:
 *      T,roll,pitch,yaw,rateR,rateP,rateY,alt,vbat\n
 *    Nhận VỀ (web -> drone), đổi PID tức thì:
 *      SET,<tên>,<giá trị>\n   ví dụ:  SET,PRateRoll,1.6
 *      SAVE\n                  (in lại toàn bộ PID để chép vào Config.h)
 *
 *  Bật/tắt bằng TELEMETRY_ENABLE trong Config.h.
 * =====================================================================
 */

#if TELEMETRY_ENABLE

HardwareSerial BleSerial(PA10, PA9);   // RX, TX cho USART1 (đã bỏ MTF)
char bleRxBuf[48];
uint8_t bleRxIdx = 0;

void telemetryInit(){
  BleSerial.begin(115200);           // khớp với ESP32 (F405_BAUD)
}

// gửi 1 gói dữ liệu bay
void telemetrySend(){
  // gửi qua BLE
  BleSerial.print("T,");
  BleSerial.print(KalmanAngleRoll, 1);  BleSerial.print(',');
  BleSerial.print(KalmanAnglePitch, 1); BleSerial.print(',');
  BleSerial.print(YawAngleDeg, 1);      BleSerial.print(',');
  BleSerial.print(RateRoll, 0);         BleSerial.print(',');
  BleSerial.print(RatePitch, 0);        BleSerial.print(',');
  BleSerial.print(RateYaw, 0);          BleSerial.print(',');
  BleSerial.print(AltitudeKalman, 0);   BleSerial.print(',');
  BleSerial.println(BatteryVoltage, 1);

  // GƯƠNG song song ra USB để chẩn đoán: mở Arduino Serial Monitor
  // 57600 sẽ thấy đúng dòng "T,..." này. Nếu USB thấy mà web không ->
  // lỗi ở đường BLE (module/UART). Bỏ khi xong.
  #if TELEMETRY_DEBUG_USB
  Serial.print("T,");
  Serial.print(KalmanAngleRoll, 1);  Serial.print(',');
  Serial.print(KalmanAnglePitch, 1); Serial.print(',');
  Serial.print(YawAngleDeg, 1);      Serial.print(',');
  Serial.println(BatteryVoltage, 1);
  #endif
}

// áp giá trị vào đúng biến PID theo tên
void telemetryApply(const char* name, float v){
  if     (!strcmp(name,"PRateRoll"))  { PRateRoll  = v; PRatePitch = v; }
  else if(!strcmp(name,"PRatePitch")) { PRatePitch = v; }
  else if(!strcmp(name,"PRateYaw"))   { PRateYaw   = v; }
  else if(!strcmp(name,"IRateRoll"))  { IRateRoll  = v; IRatePitch = v; }
  else if(!strcmp(name,"IRatePitch")) { IRatePitch = v; }
  else if(!strcmp(name,"IRateYaw"))   { IRateYaw   = v; }
  else if(!strcmp(name,"DRateRoll"))  { DRateRoll  = v; DRatePitch = v; }
  else if(!strcmp(name,"DRatePitch")) { DRatePitch = v; }
  else if(!strcmp(name,"PAngleRoll")) { PAngleRoll = v; PAnglePitch = v; }
  else if(!strcmp(name,"PAnglePitch")){ PAnglePitch= v; }
  else if(!strcmp(name,"IAngleRoll")) { IAngleRoll = v; IAnglePitch = v; }
  else if(!strcmp(name,"IAnglePitch")){ IAnglePitch= v; }
  BleSerial.print("OK,"); BleSerial.print(name);
  BleSerial.print(','); BleSerial.println(v, 3);
}

// in toàn bộ PID để chép vào Config.h
void telemetryDump(){
  BleSerial.println("=== COPY VAO Config.h ===");
  BleSerial.print("PRateRoll="); BleSerial.print(PRateRoll,2);
  BleSerial.print(" PRateYaw="); BleSerial.println(PRateYaw,2);
  BleSerial.print("IRateRoll="); BleSerial.print(IRateRoll,2);
  BleSerial.print(" IRatePitch="); BleSerial.print(IRatePitch,2);
  BleSerial.print(" IRateYaw="); BleSerial.println(IRateYaw,2);
  BleSerial.print("DRateRoll="); BleSerial.println(DRateRoll,3);
  BleSerial.print("PAngleRoll="); BleSerial.print(PAngleRoll,2);
  BleSerial.print(" IAngleRoll="); BleSerial.print(IAngleRoll,2);
  BleSerial.print(" IAnglePitch="); BleSerial.println(IAnglePitch,2);
}

// đọc lệnh đến (không chặn)
void telemetryReceive(){
  while(BleSerial.available()){
    char c = BleSerial.read();
    if(c=='\n' || c=='\r'){
      if(bleRxIdx==0) continue;
      bleRxBuf[bleRxIdx] = 0;
      // phân tích
      if(!strncmp(bleRxBuf,"SET,",4)){
        char* name = bleRxBuf + 4;
        char* comma = strchr(name, ',');
        if(comma){ *comma = 0; telemetryApply(name, atof(comma+1)); }
      } else if(!strcmp(bleRxBuf,"SAVE")){
        telemetryDump();
      }
      bleRxIdx = 0;
    } else if(bleRxIdx < sizeof(bleRxBuf)-1){
      bleRxBuf[bleRxIdx++] = c;
    }
  }
}

#endif
