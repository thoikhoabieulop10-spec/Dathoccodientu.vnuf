/* =====================================================================
 *  FC_F405 — TAB CHÍNH
 *  Flight controller STM32F405 · ICM-20602 · BMP388 · FS-iA6B
 *  Chế độ: rate + angle (tự cân bằng) + giữ độ cao (EKF 3 trạng thái)
 *
 *  CÁC TAB:
 *    FC_F405   — tab này: biến toàn cục, setup(), loop()
 *    Config    — TẤT CẢ thông số chỉnh ở đây (PID, offset, gain)
 *    IMU       — driver ICM-20602 + đọc gyro/accel + Kalman 1D góc
 *    Baro      — driver BMP388
 *    EKF       — bộ lọc độ cao 3 trạng thái (có ước lượng bias accel)
 *    Receiver  — đọc PPM từ FS-iA6B
 *    Motors    — PWM ra 4 ESC + trộn motor
 *    PID       — hàm PID dùng chung
 *
 *  Arduino IDE tự nối các tab lại khi biên dịch. Biến khai báo ở tab
 *  này nhìn thấy được từ mọi tab khác.
 * =====================================================================
 */

#include <SPI.h>
#include <HardwareTimer.h>
#include "Config.h"
#include "Filters.h"


// ---------------- pins ----------------
#define PIN_CS     PA4
#define BMP_CS     PA3
#define PPM_PIN    PA0
#define M1_PIN     PC6
#define M2_PIN     PC7
#define M3_PIN     PC8
#define M4_PIN     PC9
#define LED_GREEN  PB3
#define LED_RED    PB4

// ---------------- ICM-20602 ----------------
#define REG_CONFIG         0x1A
#define REG_GYRO_CONFIG    0x1B
#define REG_ACCEL_CONFIG   0x1C
#define REG_ACCEL_CONFIG_2 0x1D
#define REG_SMPLRT_DIV     0x19
#define REG_ACCEL_XOUT_H   0x3B
#define REG_SIGPATH_RESET  0x68
#define REG_USER_CTRL      0x6A
#define REG_PWR_MGMT_1     0x6B
#define REG_PWR_MGMT_2     0x6C
#define REG_WHO_AM_I       0x75
#define ICM_WHOAMI         0x12

static SPISettings SPI_SLOW(1000000, MSBFIRST, SPI_MODE3);
static SPISettings SPI_FAST(8000000, MSBFIRST, SPI_MODE3);

// ---------------- PPM / ESC ----------------
#define PPM_CH             8
#define PPM_SYNC_US        3000
#define PPM_MIN_US          800
#define PPM_MAX_US         2200
#define PPM_TIMEOUT_MS      100
#define ESC_PERIOD_US      4000
#define THROTTLE_CUT       1000
#define THROTTLE_MAX_CMD   1800

HardwareTimer *PPMTimer;
HardwareTimer *MotorTimer;

// ---------------- gyro + accel globals ----------------
float RateRoll, RatePitch, RateYaw;
float RateCalibrationRoll, RateCalibrationPitch, RateCalibrationYaw;
float AccX, AccY, AccZ;
float AngleRoll, AnglePitch;               // raw angle from accelerometer

// gyro software low-pass state
float RateRollFilt = 0, RatePitchFilt = 0, RateYawFilt = 0;

// ---------------- Kalman (Project 15) ----------------
float KalmanAngleRoll = 0,  KalmanUncertaintyAngleRoll  = 2*2;
float KalmanAnglePitch = 0, KalmanUncertaintyAnglePitch = 2*2;
float Kalman1DOutput[] = {0, 0};

// ---------------- BMP388 barometer (SPI) ----------------
#define BMP_CHIP_ID 0x00
#define BMP_DATA_0  0x04
#define BMP_PWR_CTRL 0x1B
#define BMP_OSR     0x1C
#define BMP_ODR     0x1D
#define BMP_CONFIG  0x1F
#define BMP_CAL_DATA 0x31
#define BMP_CMD     0x7E
#define BMP388_ID   0x50
static SPISettings BMP_SPI(8000000, MSBFIRST, SPI_MODE0);
struct { float t1,t2,t3,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11; } bcal;
float SeaLevel = 1013.25;
float BaroAltitude = 0, AltitudeStart = 0, t_lin_b;
float AccZInertial;

// ---------------- 2D Kalman (altitude + vertical velocity) ----------------
float AltitudeKalman = 0, VelocityKalman = 0;
// ---- EKF 3 trạng thái: [độ_cao(cm), vận_tốc(cm/s), bias_accel(cm/s²)] ----
float EkfX[3] = {0, 0, 0};
float EkfP[3][3] = {{100,0,0},{0,100,0},{0,0,25}};  // bias ban đầu bất định ±5
float AccelBiasEst = 0;      // để xem trên Serial

// ---------------- Vertical velocity PID state (gains in tuning block) ----------------
float DesiredVelocityVertical, ErrorVelocityVertical;
float PrevErrorVelocityVertical, PrevItermVelocityVertical;
float InputVertical;
bool  AltHoldOn = false;

// ---------------- Altitude PID state (gains in tuning block) ----------------
float DesiredAltitude, ErrorAltitude;
float PrevErrorAltitude, PrevItermAltitude;
float DesiredVel;

// ---------------- receiver ----------------
volatile float ReceiverValue[PPM_CH] = {0};
volatile int   ChannelNumber = 0;
static volatile uint32_t ppmLastCapture = 0;
static volatile uint8_t  ppmIndex = 0;
static volatile uint32_t ppmLastFrameMs = 0;

// ---------------- RATE PID state (gains in tuning block) ----------------
float DesiredRateRoll, DesiredRatePitch, DesiredRateYaw;
float ErrorRateRoll, ErrorRatePitch, ErrorRateYaw;
float InputRoll, InputThrottle, InputPitch, InputYaw;
float PrevErrorRateRoll, PrevErrorRatePitch, PrevErrorRateYaw;
float PrevItermRateRoll, PrevItermRatePitch, PrevItermRateYaw;
float PIDReturn[] = {0, 0, 0};

// ---------------- ANGLE PID state (gains in tuning block) ----------------
float DesiredAngleRoll, DesiredAnglePitch;
float ErrorAngleRoll, ErrorAnglePitch;
float PrevErrorAngleRoll, PrevErrorAnglePitch;
float PrevItermAngleRoll, PrevItermAnglePitch;

float MotorInput1, MotorInput2, MotorInput3, MotorInput4;
uint32_t LoopTimer;
uint32_t LoopMaxUs = 0;   // thoi gian vong lap dai nhat (us) — de chan doan

// ---- Cho telemetry ----
float YawAngleDeg = 0;      // góc yaw tích phân (chỉ để hiển thị, sẽ trôi)
float BatteryVoltage = 0;   // điện áp pin (V), đọc qua chia áp

// ---- Phân tích rung (để chỉnh notch). Bật bằng VIBE_ANALYZE trong Config.h ----
#if VIBE_ANALYZE
#define VIBE_N 1024
int16_t  vibeBuf[VIBE_N];
uint16_t vibeIdx = 0, vibeCount = 0;

float goertzelPower(int16_t *x, int n, float freq, float fs){
  float w = 2.0f*PI*freq/fs, coeff = 2.0f*cos(w);
  float s0, s1=0, s2=0;
  for(int i=0;i<n;i++){ s0 = x[i] + coeff*s1 - s2; s2=s1; s1=s0; }
  return s1*s1 + s2*s2 - coeff*s1*s2;
}
void analyzeVibration(){
  if(vibeCount < VIBE_N){ Serial.println("Chua du mau — bay lau hon."); return; }
  long sum=0; for(int i=0;i<VIBE_N;i++) sum += vibeBuf[i];
  int16_t mean = sum/VIBE_N;
  for(int i=0;i<VIBE_N;i++) vibeBuf[i] -= mean;
  float bestMag=0; int bestF=0;
  Serial.println("\nFreq(Hz) | Nang luong rung");
  for(int f=40; f<=200; f+=2){
    float mag = goertzelPower(vibeBuf, VIBE_N, f, 250.0f);  // loop 250Hz
    int bars = (int)(mag/500000.0f); if(bars>50) bars=50;
    Serial.print(f); Serial.print("\t| ");
    for(int b=0;b<bars;b++) Serial.print('#');
    Serial.println();
    if(mag>bestMag){ bestMag=mag; bestF=f; }
  }
  Serial.println("========================================");
  Serial.print(">>> TAN SO RUNG TROI: "); Serial.print(bestF); Serial.println(" Hz");
  Serial.print("  #define GYRO_NOTCH_HZ      "); Serial.println(bestF);
  Serial.println("  #define GYRO_NOTCH_ENABLE 1");
  Serial.println("========================================");
}
#endif

// =====================================================================
//  ICM-20602 driver
void setup() {
  Serial.begin(57600);
  pinMode(LED_GREEN, OUTPUT); pinMode(LED_RED, OUTPUT);
  digitalWrite(LED_RED, HIGH);

  if (!icmInit()) {
    while (1) { digitalWrite(LED_RED, !digitalRead(LED_RED)); delay(150); }
  }

  filtersInit();          // khởi tạo biquad TRƯỚC khi calib gyro

  // calibrate gyro -- giữ drone HOÀN TOÀN YÊN và PHẲNG
  for (int i = 0; i < 2000; i++) {
    gyro_signals();
    RateCalibrationRoll  += RateRoll;
    RateCalibrationPitch += RatePitch;
    RateCalibrationYaw   += RateYaw;
    delay(1);
  }
  RateCalibrationRoll  /= 2000;
  RateCalibrationPitch /= 2000;
  RateCalibrationYaw   /= 2000;

  receiver_init();
  motor_init();
  #if TELEMETRY_ENABLE
  telemetryInit();
  #endif

  // BMP388 init + altitude reference (drone must be still)
  if (bmpInit()) {
    float s = 0;
    for (int i = 0; i < 50; i++) { bmpAltitude(); s += BaroAltitude; delay(10); }
    AltitudeStart = s / 50.0;
  }
  // Khởi tạo EKF. Trong lúc drone nằm yên, cho bộ lọc "học" bias
  // gia tốc kế nhanh hơn bằng cách để P lớn -> hội tụ nhanh.
  EkfX[0] = 0; EkfX[1] = 0; EkfX[2] = 0;
  EkfP[0][0]=100; EkfP[0][1]=0;   EkfP[0][2]=0;
  EkfP[1][0]=0;   EkfP[1][1]=100; EkfP[1][2]=0;
  EkfP[2][0]=0;   EkfP[2][1]=0;   EkfP[2][2]=25;

  while (true) {
    if (receiver_alive()) {
      float t; noInterrupts(); t = ReceiverValue[2]; interrupts();
      if (t > 1020 && t < 1050) break;
    }
    setMotors(1000, 1000, 1000, 1000);
    digitalWrite(LED_RED, !digitalRead(LED_RED));
    delay(100);
  }
  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, HIGH);
  LoopTimer = micros();
}

// =====================================================================
//  loop() -- 250 Hz cascade controller
// =====================================================================
void loop() {
  // 1. đọc cảm biến + calibrate
  gyro_signals();
  RateRoll  -= RateCalibrationRoll;
  RatePitch -= RateCalibrationPitch;
  RateYaw   -= RateCalibrationYaw;

  // tích phân yaw thành góc (chỉ để hiển thị telemetry — sẽ trôi dần,
  // không dùng cho điều khiển nên trôi không sao)
  YawAngleDeg += RateYaw * 0.004;
  if (YawAngleDeg >  180) YawAngleDeg -= 360;
  if (YawAngleDeg < -180) YawAngleDeg += 360;

  // 2. Kalman fuse -> góc nghiêng tuyệt đối
  kalman_1d(KalmanAngleRoll, KalmanUncertaintyAngleRoll, RateRoll, AngleRoll);
  KalmanAngleRoll = Kalman1DOutput[0];
  KalmanUncertaintyAngleRoll = Kalman1DOutput[1];
  kalman_1d(KalmanAnglePitch, KalmanUncertaintyAnglePitch, RatePitch, AnglePitch);
  KalmanAnglePitch = Kalman1DOutput[0];
  KalmanUncertaintyAnglePitch = Kalman1DOutput[1];

  // 2b. gia tốc đứng (bù nghiêng) + Kalman 2D độ cao/vận tốc
  {
    float rr = KalmanAngleRoll * 0.0174533, pr = KalmanAnglePitch * 0.0174533;
    AccZInertial = -sin(pr)*AccX + cos(pr)*sin(rr)*AccY + cos(pr)*cos(rr)*AccZ;
    AccZInertial = (AccZInertial - 1.0) * 9.81 * 100.0;   // cm/s^2
    bmpAltitude();
    kalman_2d();
  }

  // 3. failsafe (mất sóng)
  if (!receiver_alive()) {
    setMotors(THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT);
    reset_pid();
    digitalWrite(LED_GREEN, LOW); digitalWrite(LED_RED, HIGH);
    LoopTimer = micros(); return;
  }
  digitalWrite(LED_RED, LOW); digitalWrite(LED_GREEN, HIGH);

  // 4. cần -> góc nghiêng mong muốn (cần = góc, không phải tốc độ)
  float rx[4]; read_receiver(rx);
  // Cần -> góc nghiêng qua ĐƯỜNG CONG EXPO.
  // Gần giữa cần: nhẹ (lái êm). Đẩy hết cần: toàn lực (phanh gấp).
  DesiredAngleRoll  = stickExpo(rx[0]) * MAX_ANGLE_DEG;
  DesiredAnglePitch = stickExpo(rx[1]) * MAX_ANGLE_DEG;
  // Chặn cứng — lưới an toàn cuối cùng
  if (DesiredAngleRoll  >  MAX_TILT_DEG) DesiredAngleRoll  =  MAX_TILT_DEG;
  if (DesiredAngleRoll  < -MAX_TILT_DEG) DesiredAngleRoll  = -MAX_TILT_DEG;
  if (DesiredAnglePitch >  MAX_TILT_DEG) DesiredAnglePitch =  MAX_TILT_DEG;
  if (DesiredAnglePitch < -MAX_TILT_DEG) DesiredAnglePitch = -MAX_TILT_DEG;
  DesiredRateYaw    = STICK_YAW_GAIN * (rx[3] - 1500);

  // 4b. GIỮ ĐỘ CAO -- bật/tắt bằng kênh 5 (công tắc trên tay cầm).
  // Đọc kênh 5 từ ReceiverValue[4]. Gạt lên = bật giữ độ cao.
  float ch5; noInterrupts(); ch5 = ReceiverValue[4]; interrupts();
  bool wantHold = (ch5 > 1500);

  if (wantHold && !AltHoldOn) {
    // vừa BẬT: chụp lại ga hiện tại làm mốc hover,
    // chụp độ cao hiện tại làm setpoint, reset cả hai PID
    HoverThrottle = rx[2];
    DesiredAltitude = AltitudeKalman;      // khóa vào độ cao hiện tại
    PrevErrorVelocityVertical = 0;
    PrevItermVelocityVertical = 0;
    PrevErrorAltitude = 0;
    PrevItermAltitude = 0;
    AltHoldOn = true;
  }
  if (!wantHold) AltHoldOn = false;

  if (AltHoldOn) {
    // cần ga dịch setpoint ĐỘ CAO lên/xuống (cm mỗi vòng lặp).
    // cần giữa = setpoint đứng yên = drone khóa vào độ cao đó.
    DesiredAltitude += STICK_ALT_GAIN * (rx[2] - 1500);

    // VÒNG NGOÀI: sai số độ cao -> vận tốc đứng mong muốn
    ErrorAltitude = DesiredAltitude - AltitudeKalman;
    pid_equation(ErrorAltitude, PAltitude, IAltitude, DAltitude,
                 PrevErrorAltitude, PrevItermAltitude);
    DesiredVel = PIDReturn[0];
    PrevErrorAltitude = PIDReturn[1];
    PrevItermAltitude = PIDReturn[2];

    // VÒNG TRONG: sai số vận tốc -> ga
    ErrorVelocityVertical = DesiredVel - VelocityKalman;
    pid_equation(ErrorVelocityVertical, PVelocityVertical, IVelocityVertical,
                 DVelocityVertical, PrevErrorVelocityVertical, PrevItermVelocityVertical);
    InputVertical = PIDReturn[0];
    PrevErrorVelocityVertical = PIDReturn[1];
    PrevItermVelocityVertical = PIDReturn[2];

    InputThrottle = HoverThrottle + InputVertical;
  } else {
    InputThrottle = rx[2];   // ga tay bình thường
  }

  // 5. VÒNG NGOÀI: sai số góc -> tốc độ quay mong muốn
  ErrorAngleRoll  = DesiredAngleRoll  - KalmanAngleRoll;
  ErrorAnglePitch = DesiredAnglePitch - KalmanAnglePitch;

  pid_equation(ErrorAngleRoll, PAngleRoll, IAngleRoll, DAngleRoll,
               PrevErrorAngleRoll, PrevItermAngleRoll);
  DesiredRateRoll = PIDReturn[0];
  PrevErrorAngleRoll = PIDReturn[1]; PrevItermAngleRoll = PIDReturn[2];

  pid_equation(ErrorAnglePitch, PAnglePitch, IAnglePitch, DAnglePitch,
               PrevErrorAnglePitch, PrevItermAnglePitch);
  DesiredRatePitch = PIDReturn[0];
  PrevErrorAnglePitch = PIDReturn[1]; PrevItermAnglePitch = PIDReturn[2];

  // 6. VÒNG TRONG: sai số tốc độ -> lệnh motor (PID rate bạn đã tune)
  ErrorRateRoll  = DesiredRateRoll  - RateRoll;
  ErrorRatePitch = DesiredRatePitch - RatePitch;
  ErrorRateYaw   = DesiredRateYaw   - RateYaw;

  pid_equation(ErrorRateRoll, PRateRoll, IRateRoll, DRateRoll,
               PrevErrorRateRoll, PrevItermRateRoll);
  InputRoll = PIDReturn[0];
  PrevErrorRateRoll = PIDReturn[1]; PrevItermRateRoll = PIDReturn[2];

  pid_equation(ErrorRatePitch, PRatePitch, IRatePitch, DRatePitch,
               PrevErrorRatePitch, PrevItermRatePitch);
  InputPitch = PIDReturn[0];
  PrevErrorRatePitch = PIDReturn[1]; PrevItermRatePitch = PIDReturn[2];

  pid_equation(ErrorRateYaw, PRateYaw, IRateYaw, DRateYaw,
               PrevErrorRateYaw, PrevItermRateYaw);
  InputYaw = PIDReturn[0];
  PrevErrorRateYaw = PIDReturn[1]; PrevItermRateYaw = PIDReturn[2];

  // 7. giới hạn ga + trộn motor
  if (InputThrottle > THROTTLE_MAX_CMD) InputThrottle = THROTTLE_MAX_CMD;
  MotorInput1 = (InputThrottle - InputRoll - InputPitch - InputYaw);
  MotorInput2 = (InputThrottle - InputRoll + InputPitch + InputYaw);
  MotorInput3 = (InputThrottle + InputRoll + InputPitch - InputYaw);
  MotorInput4 = (InputThrottle + InputRoll - InputPitch + InputYaw);

  if (MotorInput1 > 2000) MotorInput1 = 1999;
  if (MotorInput2 > 2000) MotorInput2 = 1999;
  if (MotorInput3 > 2000) MotorInput3 = 1999;
  if (MotorInput4 > 2000) MotorInput4 = 1999;
  if (MotorInput1 < THROTTLE_IDLE) MotorInput1 = THROTTLE_IDLE;
  if (MotorInput2 < THROTTLE_IDLE) MotorInput2 = THROTTLE_IDLE;
  if (MotorInput3 < THROTTLE_IDLE) MotorInput3 = THROTTLE_IDLE;
  if (MotorInput4 < THROTTLE_IDLE) MotorInput4 = THROTTLE_IDLE;

  if (rx[2] < 1050) {
    MotorInput1 = MotorInput2 = MotorInput3 = MotorInput4 = THROTTLE_CUT;
    reset_pid();

    // Khi ga về đáy (đã hạ cánh), gõ 'r' trên Serial để phân tích rung.
    #if VIBE_ANALYZE
    if (Serial.available() && (Serial.read()=='r')) analyzeVibration();
    #endif
  }

  setMotors((uint32_t)MotorInput1, (uint32_t)MotorInput2,
            (uint32_t)MotorInput3, (uint32_t)MotorInput4);

  /* ---------------------------------------------------------------
   *  DEBUG — MẶC ĐỊNH TẮT.  ĐỌC KỸ TRƯỚC KHI BẬT:
   *
   *  In Serial trong loop() làm CHẬM vòng lặp. Ở 57600 baud, 60 ký tự
   *  mất ~10ms, trong khi vòng lặp chỉ có 4ms -> bộ đệm UART đầy ->
   *  Serial.print CHẶN -> PWM ra ESC không đều -> ESC CHẬP CHỜN.
   *
   *  => KHI BAY: để DEBUG_EKF 0  (bắt buộc)
   *  => KHI TEST TRÊN BÀN (tháo cánh): đặt 1 để xem Bias hội tụ
   * --------------------------------------------------------------- */
  #define DEBUG_EKF 0

  #if DEBUG_EKF
  {
    static uint32_t dbgT = 0;
    if (millis() - dbgT > 500) {          // 500ms, thưa hơn cho đỡ chặn
      dbgT = millis();
      Serial.print(AltitudeKalman, 1); Serial.print(',');
      Serial.print(VelocityKalman, 1); Serial.print(',');
      Serial.print(AccelBiasEst, 1);   Serial.print(',');
      Serial.println(LoopMaxUs);            // thời gian vòng lặp dài nhất
      LoopMaxUs = 0;
    }
  }
  #endif

  // đo thời gian thực thi vòng lặp (không tốn gì, luôn chạy)
  uint32_t used = micros() - LoopTimer;
  if (used > LoopMaxUs) LoopMaxUs = used;

  #if TELEMETRY_ENABLE
  telemetryReceive();                    // nhận lệnh PID (mỗi vòng)
  {
    static uint32_t teleT = 0;
    if (millis() - teleT >= 50) {        // gửi 20 lần/giây
      teleT = millis();
      telemetrySend();
      // Nháy đèn ĐỎ mỗi lần gửi -> thấy đèn nhấp nháy = F405 đang gửi.
      // (chỉ để chẩn đoán telemetry, bỏ khi xong)
      digitalWrite(LED_RED, !digitalRead(LED_RED));
    }
  }
  #endif

  while (micros() - LoopTimer < 4000);
  LoopTimer = micros();
}
