/* =====================================================================
 *  TAB EKF — BỘ LỌC ĐỘ CAO 3 TRẠNG THÁI  [h, v, bias_accel]
 *
 *  Kalman 2 trạng thái cũ giả định gia tốc kế KHÔNG lệch. Thực tế nó
 *  luôn có bias, và bias TRÔI theo nhiệt độ (motor nóng, nắng...).
 *  Bias 0.01g = ~10 cm/s^2 -> tích phân vài chục giây là vận tốc sai
 *  hàng chục cm/s, baro phải liên tục "kéo lại" -> độ cao dập dềnh.
 *
 *  Bộ lọc này thêm BIAS làm trạng thái thứ 3 và TỰ HỌC nó từ baro.
 *  Đây là mánh cốt lõi trong EKF của ArduPilot/PX4.
 *
 *  Mô hình:   h'    = v
 *             v'    = (a_do - bias)
 *             bias' = 0  (+ random walk cham)
 *
 *  Fm = | 1  dt  -dt^2/2 |    do: z = h  ->  H = [1 0 0]
 *       | 0  1   -dt     |
 *       | 0  0    1      |
 *
 *  LƯU Ý ĐẶT TÊN BIẾN: KHÔNG dùng NP, NC, PA..PD — đó là macro của
 *  STM32 core (pinmap.h). Trình biên dịch sẽ thay thế và báo lỗi rất
 *  khó hiểu (biến NP bị đổi thành 0U).
 * =====================================================================
 */

void kalman_2d(){          // giữ tên hàm để phần còn lại không phải sửa
  const float dt = 0.004f;

  float h = EkfX[0], v = EkfX[1], b = EkfX[2];
  float acc = AccZInertial - b;        // gia tốc đã trừ bias ước lượng

  // ---- DỰ ĐOÁN trạng thái ----
  EkfX[0] = h + v*dt + 0.5f*dt*dt*acc;
  EkfX[1] = v + dt*acc;
  // EkfX[2] giữ nguyên (bias coi như hằng, chỉ trôi rất chậm)

  // ---- DỰ ĐOÁN hiệp phương sai: P = Fm*P*Fm' + Q ----
  float Fm[3][3] = {{1, dt, -0.5f*dt*dt},
                    {0, 1,  -dt},
                    {0, 0,   1}};
  float FP[3][3], Pnew[3][3];

  for (int i=0;i<3;i++) for (int j=0;j<3;j++){
    FP[i][j] = 0;
    for (int k=0;k<3;k++) FP[i][j] += Fm[i][k] * EkfP[k][j];
  }
  for (int i=0;i<3;i++) for (int j=0;j<3;j++){
    Pnew[i][j] = 0;
    for (int k=0;k<3;k++) Pnew[i][j] += FP[i][k] * Fm[j][k];   // Fm chuyen vi
  }

  float av = KAL2D_ACC_VAR;
  Pnew[0][0] += 0.25f*dt*dt*dt*dt*av;   Pnew[0][1] += 0.5f*dt*dt*dt*av;
  Pnew[1][0] += 0.5f*dt*dt*dt*av;       Pnew[1][1] += dt*dt*av;
  Pnew[2][2] += dt * EKF_BIAS_VAR;                  // random walk cua bias

  for (int i=0;i<3;i++) for (int j=0;j<3;j++) EkfP[i][j] = Pnew[i][j];

  // ---- SỬA bằng barometer: z = h, H = [1 0 0] ----
  float baroCm = (BaroAltitude - AltitudeStart) * 100.0f;
  float Sinn = EkfP[0][0] + KAL2D_BARO_R;
  float K0 = EkfP[0][0] / Sinn;
  float K1 = EkfP[1][0] / Sinn;
  float K2 = EkfP[2][0] / Sinn;                     // baro DAY luon ca bias
  float y  = baroCm - EkfX[0];
  EkfX[0] += K0*y;  EkfX[1] += K1*y;  EkfX[2] += K2*y;

  float Pupd[3][3];
  for (int j=0;j<3;j++){
    Pupd[0][j] = EkfP[0][j] - K0*EkfP[0][j];
    Pupd[1][j] = EkfP[1][j] - K1*EkfP[0][j];
    Pupd[2][j] = EkfP[2][j] - K2*EkfP[0][j];
  }
  for (int i=0;i<3;i++) for (int j=0;j<3;j++) EkfP[i][j] = Pupd[i][j];

  // chặn bias trong khoảng hợp lý (chống phân kỳ nếu baro lỗi)
  if (EkfX[2] >  EKF_BIAS_LIMIT) EkfX[2] =  EKF_BIAS_LIMIT;
  if (EkfX[2] < -EKF_BIAS_LIMIT) EkfX[2] = -EKF_BIAS_LIMIT;

  // xuất ra tên biến cũ để PID dùng như trước
  AltitudeKalman = EkfX[0];
  VelocityKalman = EkfX[1];
  AccelBiasEst   = EkfX[2];
}
