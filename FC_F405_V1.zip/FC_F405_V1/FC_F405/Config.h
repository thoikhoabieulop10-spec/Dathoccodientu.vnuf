#ifndef CONFIG_H
#define CONFIG_H


/* =====================================================================
 *  ############   CHỈNH THÔNG SỐ Ở ĐÂY   ############
 *  Tất cả thông số cần tinh chỉnh đều nằm trong khối này. Phần còn lại
 *  của code không cần sửa khi tune bình thường.
 * =====================================================================
 */

// ---- Offset cảm biến gia tốc (lấy từ accel_offset_calibration.ino) ----
#define ACC_OFFSET_X   (0.0093)
#define ACC_OFFSET_Y   (0.0319)
#define ACC_OFFSET_Z   (-0.0126)

/* ---- LỌC GYRO (biquad bậc 2 — thay cho EMA cũ) ----
 *
 * LOW-PASS nền. Dải hợp lý 40-80Hz cho drone 1.7kg.
 * Cao quá  -> còn nhiễu rung   Thấp quá -> trễ, PID dao động
 * (EMA alpha=0.15 cũ ≈ LPF 6Hz, trễ rất nhiều. 60Hz vừa sạch vừa nhanh.) */
#define GYRO_LPF_HZ        60.0f

/* NOTCH cắt đúng tần số rung motor.
 * Đặt 0 để TẮT, 1 để BẬT. Chỉ bật khi đã BIẾT tần số rung.
 *
 * CÁCH TÌM TẦN SỐ (chọn 1 trong 2):
 *  A. TÍNH:  f(Hz) = RPM/60,  RPM ≈ kV × điện_áp × %ga
 *     Motor 2312 800kV, 3S 12.6V, hover 50%:  ≈ 83 Hz
 *  B. ĐO (chính xác hơn): nạp gyro_spectrum.ino, cho drone chạy motor
 *     (tháo cánh), sketch in ra tần số đỉnh.
 *
 * Bề rộng: vòng tua drone đổi theo ga nên để RỘNG (25-40Hz). */
#define GYRO_NOTCH_ENABLE  0

// ---- Chế độ ĐO TẦN SỐ RUNG (để chỉnh notch) ----
// =1: firmware âm thầm ghi gyro thô khi bay. Hạ cánh (ga về đáy),
//     cắm USB, gõ 'r' trên Serial -> in tần số rung trội nhất.
// Đo xong đặt lại =0 để tiết kiệm RAM (buffer 2KB).
#define VIBE_ANALYZE       0

// ---- Telemetry BLE (DL-20 trên USART2 PA2/PA3) ----
// =1: gửi Roll/Pitch/Yaw + nhận lệnh đổi PID qua Bluetooth để tune
//     bằng web. Bay xong tune xong có thể để =1 luôn, rất nhẹ.
#define TELEMETRY_ENABLE   1

// =1: gương telemetry ra USB Serial (57600) để chẩn đoán khi web
// không nhận data. Xong thì đặt 0.
#define TELEMETRY_DEBUG_USB 1
#define GYRO_NOTCH_HZ      83.0f
#define GYRO_NOTCH_BW      30.0f

// EMA cũ — giữ lại để so sánh. Đặt 1 để quay về bộ lọc cũ.
#define USE_OLD_EMA_FILTER 0
#define GYRO_FILTER_ALPHA  0.15f

// ---- PID RATE (vòng trong điều khiển tốc độ quay -- số bạn đã tune) ----
float PRateRoll = 1.4,  PRatePitch = 1.4,  PRateYaw = 4.4;
float IRateRoll = 3.5,  IRatePitch = 3.5,  IRateYaw = 16.2;
float DRateRoll = 0.04, DRatePitch = 0.04, DRateYaw = 0.0;

// ---- PID ANGLE (vòng ngoài tự cân bằng ngang) ----
float PAngleRoll = 1.7, PAnglePitch = 1.7;
float IAngleRoll = 1.0, IAnglePitch = 0.5;
float DAngleRoll = 0.0, DAnglePitch = 0.0;

// ---- PID ALTITUDE (vòng ngoài giữ độ cao -- cascade) ----
// P cao quá = drone nảy quanh độ cao mục tiêu. Thấp quá = sửa chậm.
// I giúp khử trôi độ cao thường trực.
float PAltitude = 0.0;
float IAltitude = 0.0;
float DAltitude = 0.0;

// ---- PID VẬN TỐC ĐỨNG (vòng trong của giữ độ cao) ----
float PVelocityVertical = 3.0;
float IVelocityVertical = 0.005;
float DVelocityVertical = 0.08;

// ---- Ga / hover ----
#define THROTTLE_IDLE   1180     // motor không bao giờ tắt dưới mức này khi bay
float HoverThrottle = 1500;      // tự chụp lại khi bật giữ độ cao

// ---- Độ nhạy cần điều khiển ----
// ---- Độ nhạy cần điều khiển (ĐƯỜNG CONG EXPO) ----
//
//  VẤN ĐỀ với gain tuyến tính: phải chọn giữa
//    gain thấp  -> lái êm nhưng THIẾU LỰC PHANH khi sắp đâm
//    gain cao   -> đủ lực nhưng chạm nhẹ cần đã giật
//
//  EXPO giải quyết cả hai: gần giữa cần thì nhẹ, đẩy hết cần thì
//  toàn lực. Đây là cách mọi tay điều khiển RC chuyên nghiệp dùng.
//
//  MAX_ANGLE_DEG : góc nghiêng khi ĐẨY HẾT CẦN (lực phanh tối đa)
//  STICK_EXPO    : 0.0 = thẳng tuyến tính
//                  0.5 = cong vừa (khuyên dùng)
//                  0.8 = cong mạnh, giữa cần rất nhẹ
#define MAX_ANGLE_DEG      55.0   // hết cần = 55° (đủ phanh gấp)
#define STICK_EXPO         0.50   // độ cong

//  Bảng tham chiếu với MAX_ANGLE_DEG=55, EXPO=0.5:
//     1/4 cần ->  8°     (lái vi chỉnh, rất êm)
//     1/2 cần -> 17°     (bay thường)
//     3/4 cần -> 32°     (cơ động)
//     hết cần -> 55°     (PHANH GẤP)

#define STICK_YAW_GAIN     0.15   // tốc độ yaw (độ/giây) trên mỗi us

// Vùng chết quanh giữa cần (0..1). Khử rung tay và nhiễu cần.
// 0.03 = 3% hành trình. Tăng nếu drone tự trôi khi thả cần.
#define STICK_DEADBAND     0.03

// Chặn cứng góc nghiêng tối đa (độ). Lưới an toàn cuối cùng.
#define MAX_TILT_DEG       60.0
#define STICK_ALT_GAIN     0.0008 // tốc độ dời setpoint độ cao trên mỗi us

// ---- Nhiễu Kalman 2D (vận tốc nhiễu thì tăng ACC_VAR;
//      độ cao nhiễu thì tăng BARO_R) ----
#define KAL2D_ACC_VAR   (30.0*30.0)   // nhiễu quá trình (gia tốc kế)
#define KAL2D_BARO_R    (30.0*30.0)   // nhiễu đo (barometer)

// ---- EKF: tốc độ học BIAS gia tốc kế ----
// Nhỏ  = học chậm mà chắc, ít bị baro nhiễu làm lệch
// Lớn  = học nhanh, bám kịp khi nhiệt độ đổi, nhưng dễ nhiễu
// 0.1 .. 1.0 là dải hợp lý. Bắt đầu 0.3.
#define EKF_BIAS_VAR    (0.3f*0.3f)
// Chặn bias trong khoảng này (cm/s²) — chống phân kỳ nếu baro lỗi
#define EKF_BIAS_LIMIT  60.0f

/* =====================================================================
 *  ###################   HẾT PHẦN CHỈNH THÔNG SỐ   ###################
 * =====================================================================
 */

#endif
