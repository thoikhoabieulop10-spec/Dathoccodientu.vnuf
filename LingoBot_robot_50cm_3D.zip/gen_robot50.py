"""60 cm "Nhu Y" English-buddy robot, split into parts that fit a 220 x 220 x 250 mm printer.

Assembly coordinates: X = width, Y = depth (front of the robot is -Y), Z = up (floor = 0).
The 4.0" ST7796 display (MSP4021) is the FACE, mounted landscape (480 x 320) behind the visor.

Joins: the halves/quarters have small half-bosses with 2 mm holes on the cut faces.
Push pieces of 1.75 mm filament into the holes as alignment pins and glue (CA / epoxy).
"""
import manifold3d as mf
from manifold3d import Manifold, CrossSection
import numpy as np, os, sys, json

mf.set_circular_segments(72)
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)

K = 500.0 / 606.0    # overall scale: 60 cm design -> 50 cm robot
WALL = 3.2           # becomes ~2.6 mm after scaling
PIN_D = 2.0 / K      # stays 2.0 mm after scaling (1.75 mm filament pins)

# ---------------- helpers ----------------
def box(sx, sy, sz, x=0, y=0, z=0):
    return Manifold.cube([sx, sy, sz], True).translate([x, y, z])

def cyl(r, h, x=0, y=0, z=0, axis='z', r2=None):
    c = Manifold.cylinder(h, r, r if r2 is None else r2, 0, True)
    if axis == 'x':
        c = c.rotate([0, 90, 0])
    elif axis == 'y':
        c = c.rotate([90, 0, 0])
    return c.translate([x, y, z])

def rbox(sx, sy, sz, r, x=0, y=0, z=0):
    """Box with all edges rounded (hull of 8 spheres)."""
    s = Manifold.sphere(r, 48)
    pts = [(a * (sx / 2 - r), b * (sy / 2 - r), c * (sz / 2 - r)) for a in (-1, 1) for b in (-1, 1) for c in (-1, 1)]
    return Manifold.batch_hull([s.translate(p) for p in pts]).translate([x, y, z])

def hollow_rbox(sx, sy, sz, r, x, y, z, wall=WALL):
    return rbox(sx, sy, sz, r, x, y, z) - rbox(sx - 2 * wall, sy - 2 * wall, sz - 2 * wall, r - wall, x, y, z)

def rrect(w, h, r):
    r = min(r, w / 2 - 0.01, h / 2 - 0.01)
    c = CrossSection.circle(r)
    pts = [(w / 2 - r, h / 2 - r), (-w / 2 + r, h / 2 - r), (w / 2 - r, -h / 2 + r), (-w / 2 + r, -h / 2 + r)]
    return CrossSection.batch_hull([c.translate(p) for p in pts])

def plate_xz(w, h, r, t, x, y, z):
    """Rounded plate lying in the XZ plane (facing -Y), thickness t starting at y going +Y."""
    return Manifold.extrude(rrect(w, h, r), t).rotate([-90, 0, 0]).translate([x, y, z])

def pin_boss(x, y, z, axis):
    """Boss straddling a cut plane with a pin hole along `axis` (normal of the cut)."""
    b = box(11, 11, 11, x, y, z)
    return b, cyl(PIN_D / 2, 16, x, y, z, axis)

def split(m, normal, offset=0.0):
    """Returns (part on +normal side, part on -normal side)."""
    a = m.trim_by_plane(normal, offset)
    b = m.trim_by_plane([-n for n in normal], -offset)
    return a, b

# ---------------- dimensions ----------------
BASE_H, BASE_R0, BASE_R1 = 222.0, 128.0, 90.0
TORSO = dict(w=200.0, d=160.0, h=170.0, r=36.0, z=BASE_H + 85.0)       # 222..392
NECK_R, NECK_H = 34.0, 34.0
HEAD = dict(w=210.0, d=180.0, h=160.0, r=26.0, z=TORSO['z'] + 85 + 18 + 80)  # bottom ~ 410
HEAD_Z0 = HEAD['z'] - HEAD['h'] / 2
HEAD_Z1 = HEAD['z'] + HEAD['h'] / 2

# display (landscape): PCB 108.04 x 61.74, viewing area 85.22 x 56.88, holes 102.04 x 54.90
# real display sizes are divided by K so they come out at true size after scaling
PCB_W, PCB_H = 108.04 / K, 61.74 / K
VA_W, VA_H = (85.22 + 1.2) / K, (56.88 + 1.2) / K
HOLE_DX, HOLE_DZ = 102.04 / K, 54.90 / K
GLASS_T = 4.1 / K
VISOR_W, VISOR_H, VISOR_DEPTH = 150.0, 100.0, 2.4
FACE_Z = HEAD['z'] + 2.0

parts = {}
colors = {}

# ================= HEAD (front + back halves) =================
head = hollow_rbox(HEAD['w'], HEAD['d'], HEAD['h'], HEAD['r'], 0, 0, HEAD['z'])
yf = -HEAD['d'] / 2   # front surface plane
# visor recess (dark visor plate glues in here) + display window
head = head - plate_xz(VISOR_W + 0.6, VISOR_H + 0.6, 22, VISOR_DEPTH + 0.01, 0, yf - 0.01, FACE_Z)
head = head - box(VA_W, 30, VA_H, 0, yf, FACE_Z)
# display standoffs behind the window (front wall inner face at yf + WALL)
y_in = yf + WALL
for sx in (-1, 1):
    for sz in (-1, 1):
        px, pz = sx * HOLE_DX / 2, FACE_Z + sz * HOLE_DZ / 2
        head = head + cyl(3.2 / K, GLASS_T, px, y_in + GLASS_T / 2, pz, 'y') - cyl(1.25 / K, GLASS_T + 1, px, y_in + GLASS_T / 2, pz, 'y')
# side rails to centre the glass
for sz in (-1, 1):
    head = head + box(40, GLASS_T, 1.6, 0, y_in + GLASS_T / 2, FACE_Z + sz * (61.0 / 2 + 1.2) / K)
# microphone holes on top of the head (INMP441 under them)
for dx in (-4, 0, 4):
    head = head - cyl(1.1, 10, dx, -40, HEAD_Z1 - 2)
# neck opening
head = head - cyl(NECK_R + 0.6, 12, 0, 0, HEAD_Z0 + 1)
# ear sockets (pegs of the headphone cups go in here)
for sx in (-1, 1):
    head = head - cyl(6.2, 12, sx * HEAD['w'] / 2, 0, HEAD['z'], 'x')
# cap socket on top
head = head - cyl(6.2, 12, 0, 10, HEAD_Z1)
# pin bosses on the y = 0 cut
bosses, holes = [], []
for (x, z) in [(-HEAD['w'] / 2 + 9, HEAD['z']), (HEAD['w'] / 2 - 9, HEAD['z']), (0, HEAD_Z1 - 9),
               (-60, HEAD_Z0 + 9), (60, HEAD_Z0 + 9)]:
    b, h = pin_boss(x, 0, z, 'y'); bosses.append(b); holes.append(h)
head = (head + Manifold.batch_boolean(bosses, mf.OpType.Add)) - Manifold.batch_boolean(holes, mf.OpType.Add)
head_back, head_front = split(head, [0, 1, 0], 0.0)
parts['01_head_front'] = head_front; colors['01_head_front'] = 'white'
parts['02_head_back'] = head_back; colors['02_head_back'] = 'white'

# visor plate (print in black): sits in the recess, window for the display
visor = plate_xz(VISOR_W, VISOR_H, 22, VISOR_DEPTH, 0, yf, FACE_Z) - box(VA_W, 30, VA_H, 0, yf, FACE_Z)
parts['03_visor'] = visor; colors['03_visor'] = 'black'

# headphone ear cups (navy), with peg
for name, sx in (('04_ear_left', -1), ('05_ear_right', 1)):
    cup = cyl(40, 22, sx * (HEAD['w'] / 2 + 11), 0, HEAD['z'], 'x') + \
          cyl(28, 4, sx * (HEAD['w'] / 2 + 24), 0, HEAD['z'], 'x') + \
          cyl(5.8, 12, sx * (HEAD['w'] / 2 - 4), 0, HEAD['z'], 'x')
    cup = cup - cyl(20, 3, sx * (HEAD['w'] / 2 + 26), 0, HEAD['z'], 'x')   # light ring groove
    parts[name] = cup; colors[name] = 'navy'
# graduation cap (navy): skull cap + board + button
cap = cyl(55, 26, 0, 10, HEAD_Z1 + 13) + box(150, 150, 6, 0, 10, HEAD_Z1 + 29).rotate([0, 0, 0]) + \
      cyl(6, 4, 0, 10, HEAD_Z1 + 34) + cyl(5.8, 12, 0, 10, HEAD_Z1 - 3)
cap = cap - cyl(1.2, 10, 0, 10, HEAD_Z1 + 33)   # hole for a yellow yarn tassel
parts['07_grad_cap'] = cap; colors['07_grad_cap'] = 'navy'

# ================= TORSO (front + back halves) =================
T = TORSO
tz0, tz1 = T['z'] - T['h'] / 2, T['z'] + T['h'] / 2
torso = hollow_rbox(T['w'], T['d'], T['h'], T['r'], 0, 0, T['z'])
ty = -T['d'] / 2
# chest panel recess + speaker grille (panel plate printed in navy)
PANEL_W, PANEL_H = 118.0, 92.0
torso = torso - plate_xz(PANEL_W + 0.6, PANEL_H + 0.6, 14, 2.41, 0, ty - 0.01, T['z'] + 4)
grille = []
for j in range(-6, 7):
    for i in range(-6, 7):
        gx = i * 6.0 + (3.0 if j % 2 else 0); gz = j * 5.2
        if gx * gx + gz * gz <= 26 ** 2:
            grille.append(cyl(1.7, 20, gx, ty, T['z'] + 4 + gz, 'y'))
torso = torso - Manifold.batch_boolean(grille, mf.OpType.Add)
# speaker glue frame behind the grille
torso = torso + (box(46 / K, 8, 46 / K, 0, ty + WALL + 4, T['z'] + 4) - box(41 / K, 10, 41 / K, 0, ty + WALL + 4, T['z'] + 4))
# backpack bulge on the back
torso = torso + (rbox(140, 46, 124, 14, 0, T['d'] / 2 + 10, T['z'] - 4) - rbox(140 - 6.4, 46, 124 - 6.4, 11, 0, T['d'] / 2 + 6, T['z'] - 4))
torso = torso - box(120, 20, 100, 0, T['d'] / 2 - 2, T['z'] - 4)   # open the inside to the backpack
# USB cable hole at the bottom of the backpack
torso = torso - cyl(7 / K, 30, 0, T['d'] / 2 + 14, tz0 + 20, 'z')
# neck (part of the torso top)
torso = torso + (cyl(NECK_R, NECK_H, 0, 0, tz1 + NECK_H / 2 - 4) - cyl(NECK_R - 3.2, NECK_H + 2, 0, 0, tz1 + NECK_H / 2 - 4))
torso = torso - cyl(NECK_R - 3.2, 10, 0, 0, tz1)
# bottom opening + shoulder sockets
torso = torso - cyl(60.6, 10, 0, 0, tz0)
for sx in (-1, 1):
    torso = torso - cyl(8.2, 14, sx * T['w'] / 2, 0, tz1 - 40, 'x')
# pin bosses on the y = 0 cut
bosses, holes = [], []
for (x, z) in [(-T['w'] / 2 + 9, T['z'] - 30), (T['w'] / 2 - 9, T['z'] - 30), (-T['w'] / 2 + 9, T['z'] + 50),
               (T['w'] / 2 - 9, T['z'] + 50), (-70, tz0 + 9), (70, tz0 + 9), (-60, tz1 - 9), (60, tz1 - 9)]:
    b, h = pin_boss(x, 0, z, 'y'); bosses.append(b); holes.append(h)
torso = (torso + Manifold.batch_boolean(bosses, mf.OpType.Add)) - Manifold.batch_boolean(holes, mf.OpType.Add)
torso_back, torso_front = split(torso, [0, 1, 0], 0.0)
parts['08_torso_front'] = torso_front; colors['08_torso_front'] = 'white'
parts['09_torso_back'] = torso_back; colors['09_torso_back'] = 'white'

# chest panel plate (navy) with the same grille + a globe ring
panel = plate_xz(PANEL_W, PANEL_H, 14, 2.4, 0, ty, T['z'] + 4) - Manifold.batch_boolean(grille, mf.OpType.Add)
panel = panel - (cyl(33, 1.2, 0, ty + 0.5, T['z'] + 4, 'y') - cyl(31, 1.4, 0, ty + 0.5, T['z'] + 4, 'y'))
parts['10_chest_panel'] = panel; colors['10_chest_panel'] = 'navy'

# ================= ARMS (each split in two halves along X) =================
def make_arm(sx):
    sh = np.array([sx * (T['w'] / 2 + 18), 0, tz1 - 40])
    elbow = sh + np.array([sx * 18, -10, -80])
    hand = elbow + np.array([sx * 4, -40, -40])
    s1 = Manifold.sphere(24, 48).translate(list(sh))
    upper = Manifold.batch_hull([Manifold.sphere(21, 48).translate(list(sh)), Manifold.sphere(18, 48).translate(list(elbow))])
    fore = Manifold.batch_hull([Manifold.sphere(17, 48).translate(list(elbow)), Manifold.sphere(15, 48).translate(list(hand))])
    palm = rbox(36, 22, 40, 10, *hand)
    arm = s1 + upper + fore + palm + cyl(7.8, 18, sh[0] - sx * 18, 0, sh[2], 'x')   # peg into the shoulder socket
    # hollow a little to save plastic
    arm = arm - Manifold.batch_hull([Manifold.sphere(16, 32).translate(list(sh)), Manifold.sphere(12, 32).translate(list(elbow))])
    return arm.trim_by_plane([0, 0, 1], -1000)

for name, sx in (('11_arm_left', -1), ('12_arm_right', 1)):
    arm = make_arm(sx)
    parts[name] = arm; colors[name] = 'white'

# ================= BASE (bell skirt, 4 quarters) =================
prof = [(0, 0), (BASE_R0 + 4, 0), (BASE_R0 + 4, 26), (BASE_R0, 30), (BASE_R0 - 3, 36)]
N = 24
for k in range(N + 1):
    t = k / N
    z = 36 + t * (BASE_H - 36)
    r = (BASE_R0 - 3) - (BASE_R0 - 3 - BASE_R1) * (t ** 1.6)
    prof.append((r, z))
prof.append((0, BASE_H))
outer = Manifold.revolve(CrossSection([prof]), 96)
inner_prof = [(0, -1)] + [(max(r - WALL, 1), min(z, BASE_H - WALL)) for (r, z) in prof[1:-1]]
inner_prof[1] = (BASE_R0 + 4 - WALL, -1)
inner_prof.append((0, BASE_H - WALL))
inner = Manifold.revolve(CrossSection([inner_prof]), 96)
base = outer - inner
# light-strip groove (blue LED band look) around the wheel ring
base = base - (cyl(BASE_R0 + 5, 3, 0, 0, 14) - cyl(BASE_R0 + 2, 4, 0, 0, 14))
# top: collar that enters the torso bottom opening, wire hole
base = base + (cyl(60, 18, 0, 0, BASE_H + 5) - cyl(52, 22, 0, 0, BASE_H + 5))   # overlaps the top wall -> one solid
base = base - cyl(52, 10, 0, 0, BASE_H - 1)
# pin bosses on the x = 0 and y = 0 cuts
bosses, holes = [], []
for z in (60, 150):
    rr = (BASE_R0 - 3) - (BASE_R0 - 3 - BASE_R1) * (((z - 36) / (BASE_H - 36)) ** 1.6) - 8
    for ang in (0, 90, 180, 270):
        a = np.radians(ang)
        x, y = rr * np.cos(a), rr * np.sin(a)
        axis = 'y' if ang in (0, 180) else 'x'
        b, h = pin_boss(x, y, z, axis); bosses.append(b); holes.append(h)
base = (base + Manifold.batch_boolean(bosses, mf.OpType.Add)) - Manifold.batch_boolean(holes, mf.OpType.Add)
q = 0
for sx in (1, -1):
    for sy in (1, -1):
        piece = base ^ box(400, 400, 600, sx * 200, sy * 200, 250)
        q += 1
        parts[f'13_base_quarter_{q}'] = piece; colors[f'13_base_quarter_{q}'] = 'white'

# ---------------- export ----------------
from stl import mesh as stlmesh
info = {}
for name, m in parts.items():
    m = m.scale([K, K, K])
    parts[name] = m
    mesh = m.to_mesh()
    v = np.asarray(mesh.vert_properties)[:, :3].copy()
    f = np.asarray(mesh.tri_verts)
    s = stlmesh.Mesh(np.zeros(len(f), dtype=stlmesh.Mesh.dtype))
    s.vectors = v[f]
    s.save(os.path.join(OUT, name + '.stl'))
    lo, hi = v.min(0), v.max(0)
    size = sorted((hi - lo).round(1).tolist())
    info[name] = dict(size=(hi - lo).round(1).tolist(), color=colors[name], ok=m.status() == mf.Error.NoError)
    print(f"{name:22s} size {np.round(hi - lo, 1)}  fits={size[0] <= 255 and size[1] <= 255 and size[2] <= 295}  {colors[name]}")
json.dump(info, open(os.path.join(OUT, '_info.json'), 'w'), indent=1)
total = max(m.bounding_box()[5] for m in parts.values())
print("total height", round(total, 1))
