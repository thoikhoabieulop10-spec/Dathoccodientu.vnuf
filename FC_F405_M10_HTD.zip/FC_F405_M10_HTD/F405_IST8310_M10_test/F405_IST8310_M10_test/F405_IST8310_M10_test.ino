/*
  ============================================================================
  F405_IST8310_M10_test.ino
  ----------------------------------------------------------------------------
  Chuong trinh test cho GPS GEPRC GEP-M10 (u-blox M10) + la ban IST8310
  (module rieng) tren STM32F405 (core "STM32 MCU based boards" - STM32duino).
  Cau hinh GPS bang lenh CFG-VALSET / CFG-VALGET cua dong M10.

  Serial Monitor: 115200 baud, "New Line". Gui 1 ky tu de chon menu,
  gui 'q' de thoat bai test dang chay.

  THU TU LAM LA BAN (lam NGOAI TROI, xa sat thep)
    a -> quet I2C, xac nhan IST8310 (WHO_AM_I = 0x10)
    b -> kiem tra suc khoe chip (de YEN board)
    c -> xem so tho, xoay board: ca 3 truc phai doi
    d -> hieu chuan (khop ellipsoid, 30-90 giay)
    j -> kiem tra lai hieu chuan bang du lieu moi
    w -> tu do anh xa truc (nghieng ~45 do, KHONG nghieng qua 60 do)
    e -> nghiem thu heading: Bac 0, Dong 90, Nam 180, Tay 270
    t -> in toan bo macro cho Config.h muc [9]

  THU TU LAM GPS
    Cong GPS mac dinh 115200 (GEP-M10 xuat xuong). l chi can khi GPS im lang.
    v -> xac nhan chip M10 (phan cung 000A0000)
    x -> luu cau hinh bay: 115200bps, 10Hz, chi GGA+RMC, kieu bay
    u -> xem cau hinh dang chay (he ve tinh, toc do, baud)
    ra NGOAI TROI:  o (khao sat ve tinh),  h (toa do)
    n -> khoi phuc mac dinh nha may neu lo cau hinh sai.

  File nay KHONG dieu khien motor. Van nen thao canh quat.
  ============================================================================
*/

#include <Wire.h>
#include <math.h>

/* ===========================================================================
   1. CAU HINH CHAN
   =========================================================================*/

// I2C1 cho la ban IST8310 (module rieng)
#define PIN_I2C_SDA   PB7
#define PIN_I2C_SCL   PB6

// UART cho GPS: USART1 tren PA9/PA10 (truoc day dung PC10/PC11)
//   Day noi:  GPS TX -> PA10 (USART1_RX cua F405)
//             GPS RX -> PA9  (USART1_TX cua F405)
#define PIN_GPS_RX    PA10        // RX cua F405 <-- TX cua GEP-M10
#define PIN_GPS_TX    PA9         // TX cua F405 --> RX cua GEP-M10

#define MON_BAUD      115200
#define I2C_CLOCK     100000      // 400000 chi khi co keo len 4.7k ngoai

// Do lech tu thien Ha Noi (do, am = lech Tay)
#define MAG_DECLINATION   -1.74f

// IST8310: 0.3 uT moi LSB. Tu truong Ha Noi ~45 uT -> ban kinh ~150 LSB
#define IST_UT_PER_LSB    0.3f
#define IST_R_THEORY      150.0f

TwoWire        HWire(PIN_I2C_SDA, PIN_I2C_SCL);
HardwareSerial GpsSerial(PIN_GPS_RX, PIN_GPS_TX);
#define MON Serial

/* ===========================================================================
   2. BIEN TOAN CUC
   =========================================================================*/

uint8_t  ist_addr  = 0;           // 0 = khong tim thay
int16_t  compass_x, compass_y, compass_z;

float    mag_off[3]   = {0, 0, 0};
float    mag_W[3][3]  = { {1, 0, 0}, {0, 1, 0}, {0, 0, 1} };   // m_cal = W (m - off)
bool     mag_full_model = false;     // true = W co so hang cheo
float    mag_cal_radius = 0;         // |M| trung binh luc hieu chuan (menu d)
bool     compass_calibrated = false;

// Anh xa truc tu menu 'w': FWD = sgn[0]*m[map[0]], RIGHT = ..., DOWN = ...
uint8_t  ax_map[3] = {0, 1, 2};
int8_t   ax_sgn[3] = {1, 1, 1};
bool     axis_configured = false;

char     data = 0;

// GPS
char     nmea_buffer[100];
uint8_t  nmea_index = 0;
uint8_t  gps_fix_type = 0, gps_satellites = 0;
double   gps_latitude = 0, gps_longitude = 0;   // PHAI la double
float    gps_hdop = 0, gps_altitude = 0;

#define GPS_FILTER_ALPHA   0.15f
double   gps_lat_filt = 0, gps_lon_filt = 0;
float    gps_alt_filt = 0;
bool     gps_filter_ready = false;
/* Mac dinh 115200 (GEP-M10 xuat xuong o 115200). Luc khoi dong thu 115200
 * truoc, dung la dung luon; chi khi khong co gi moi do cac toc do khac. */
uint32_t gps_baudrate = 115200;
const uint32_t GPS_BAUD_LIST[5] = {115200, 38400, 57600, 9600, 4800};

uint32_t gps_bytes_seen = 0;

/* Ket qua goi UBX-NAV-PVT moi nhat (giong firmware bay FC_F405_M10_PVT) */
uint8_t  pvt_fix = 0, pvt_sats = 0;
bool     pvt_ok = false;              // gnssFixOK va fix 3D
float    pvt_hacc = 99, pvt_pdop = 99, pvt_alt = 0, pvt_vn = 0, pvt_ve = 0;
double   pvt_lat = 0, pvt_lon = 0;
uint32_t pvt_count = 0, pvt_last_ms = 0;
uint8_t  gf_last_cls = 0, gf_last_id = 0;     // goi UBX vua nhan (cho menu f)
uint16_t gf_last_len = 0;
#define PVT_MIN_SATS   8
#define PVT_MAX_HACC   2.5f           // = GPS_MAX_HACC_M trong Config.h
uint32_t gps_gga_seen   = 0;

/* Ket qua kiem tra chip bang MON-VER (tu dong luc khoi dong, menu v):
 *   0 = chua doc duoc, 1 = dung M10 (phan cung 000A0000), 2 = chip khac */
uint8_t  gps_chip = 0;

/* ===========================================================================
   3. SETUP / LOOP / MENU
   =========================================================================*/

void setup() {
  MON.begin(MON_BAUD);
  delay(1500);

  GpsSerial.begin(gps_baudrate);
  HWire.begin();
  HWire.setClock(I2C_CLOCK);
  delay(250);

  ist_detect();
  gps_baud_autodetect(false);
  gps_detect_model(false);
  print_intro();
}

void loop() {
  delay(10);
  if (MON.available() > 0) {
    data = MON.read();
    delay(100);
    while (MON.available() > 0) MON.read();

    switch (data) {
      case 'a': i2c_scanner();             break;
      case 'b': compass_self_test();       break;
      case 'c': compass_raw_stream();      break;
      case 'd': compass_calibrate();       break;
      case 'j': compass_check_calibration(); break;
      case 'w': compass_axis_wizard();     break;
      case 'e': compass_heading_stream();  break;
      case 't': print_nav_macros();        break;

      case 'f': gps_raw_dump();            break;
      case 'g': m10_configure_basic();     break;
      case 'h': gps_pvt_stream();          break;
      case 'l': gps_baud_autodetect(true); gps_detect_model(true); print_intro(); break;
      case 'x': m10_configure_full(115200); break;
      case 'u': m10_show_signals();        break;
      case 'v': gps_show_version();        break;
      case 'n': gps_factory_reset();       break;
      case 'o': gps_satellite_survey();    break;
      default:  print_intro();             break;
    }
    data = 0;
  }
}

void print_intro() {
  MON.println();
  MON.println(F("===================================================================="));
  MON.println(F("  STM32F405 - Test la ban IST8310 + GPS GEP-M10"));
  MON.println(F("===================================================================="));
  MON.print(F("La ban: "));
  if (ist_addr) {
    MON.print(F("IST8310 @ 0x")); MON.print(ist_addr, HEX);
    MON.print(compass_calibrated ? F("  [da hieu chuan]") : F("  [CHUA hieu chuan]"));
    MON.println(axis_configured ? F(" [da anh xa truc]") : F(" [CHUA anh xa truc]"));
  } else {
    MON.println(F("KHONG THAY IST8310 - kiem tra day SCL/SDA, chay menu a"));
  }
  MON.print(F("GPS UART: ")); MON.print(gps_baudrate); MON.print(F(" bps   chip: "));
  if      (gps_chip == 1) MON.println(F("u-blox M10 (GEP-M10)"));
  else if (gps_chip == 2) MON.println(F("KHONG PHAI M10 - bam v de xem"));
  else                    MON.println(F("chua doc duoc (bam v)"));
  MON.println();
  MON.println(F("  LA BAN IST8310"));
  MON.println(F("  a = Quet I2C + kiem tra IST8310"));
  MON.println(F("  b = Kiem tra suc khoe IST8310 (self-test)"));
  MON.println(F("  c = Doc gia tri tho X/Y/Z lien tuc"));
  MON.println(F("  d = Hieu chuan (xoay board 30-90 giay)"));
  MON.println(F("  j = Kiem tra chat luong hieu chuan"));
  MON.println(F("  w = Tu do anh xa truc (lam sau d)"));
  MON.println(F("  e = Hien heading 0-360 do (lam sau w)"));
  MON.println(F("  t = In macro cho Nav.h"));
  MON.println();
  MON.println(F("  GPS GEP-M10 (giao thuc UBX NAV-PVT)"));
  MON.println(F("  f = Xem du lieu tho (goi UBX / cau NMEA)"));
  MON.println(F("  g = Cau hinh THU: NAV-PVT 10Hz, tat NMEA, khong luu"));
  MON.println(F("  h = Doc NAV-PVT giong code bay (ve tinh, hAcc, van toc, do troi)"));
  MON.println(F("  l = Tu do baudrate (mac dinh 115200, chi can khi GPS im lang)"));
  MON.println(F("  v = Xem phien ban firmware, xac nhan chip M10"));
  MON.println(F("  o = KHAO SAT ve tinh theo tung he (GPS/BeiDou/Galileo/...)"));
  MON.println(F("  x = LUU cho bay: 115200bps, NAV-PVT 10Hz, tat NMEA, kieu bay"));
  MON.println(F("  u = Xem cau hinh dang chay (he ve tinh, toc do, baud)"));
  MON.println(F("  n = Khoi phuc mac dinh nha may"));
  MON.println();
  MON.println(F("  Gui 'q' de thoat bai test dang chay."));
  MON.println(F("===================================================================="));
}

/* ===========================================================================
   4. TIEN ICH
   =========================================================================*/

bool check_quit() {
  if (MON.available() > 0) {
    char c = MON.read();
    delay(50);
    while (MON.available() > 0) MON.read();
    if (c == 'q' || c == 'Q') return true;
  }
  return false;
}

void wait_for_key() {
  while (MON.available()) MON.read();
  while (!MON.available()) delay(10);
  delay(50);
  while (MON.available()) MON.read();
}

bool i2c_read_reg(uint8_t addr, uint8_t reg, uint8_t *val) {
  HWire.beginTransmission(addr);
  HWire.write(reg);
  if (HWire.endTransmission() != 0) return false;
  if (HWire.requestFrom(addr, (uint8_t)1) != 1) return false;
  *val = HWire.read();
  return true;
}

bool i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t val) {
  HWire.beginTransmission(addr);
  HWire.write(reg);
  HWire.write(val);
  return HWire.endTransmission() == 0;
}

void i2c_scanner() {
  MON.println();
  MON.println(F("--- Quet bus I2C (PB6=SCL, PB7=SDA) ---"));
  uint8_t found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    HWire.beginTransmission(addr);
    if (HWire.endTransmission() == 0) {
      MON.print(F("  0x"));
      if (addr < 16) MON.print('0');
      MON.print(addr, HEX);
      uint8_t id;
      if (addr >= 0x0C && addr <= 0x0F && i2c_read_reg(addr, 0x00, &id)) {
        MON.print(F("  WHO_AM_I=0x")); MON.print(id, HEX);
        MON.print(id == 0x10 ? F("  <- IST8310") : F("  (khong phai IST8310)"));
      } else {
        MON.print(F("  (khong dung trong sketch nay)"));
      }
      MON.println();
      found++;
    }
    delay(2);
  }
  if (found == 0) MON.println(F("  Khong thay thiet bi nao. Kiem tra SCL/SDA, nguon cum GPS."));

  ist_detect();
  MON.println(ist_addr ? F("  => IST8310 san sang.") : F("  => KHONG tim thay IST8310."));
  print_intro();
}

/* ===========================================================================
   5. DRIVER IST8310
   Thanh ghi: 0x00 WHO_AM_I (=0x10), 0x02 STAT1 (bit0 DRDY),
              0x03..0x08 X,Y,Z little-endian, 0x0A CNTL1 (1 = do don),
              0x0B CNTL2 (1 = soft reset), 0x41 AVGCNTL, 0x42 PDCNTL.
   IST8310 chi co che do DO DON: moi lan doc phai kich do truoc.
   =========================================================================*/

void ist_detect() {
  const uint32_t speeds[] = { I2C_CLOCK, 100000, 50000 };
  ist_addr = 0;
  for (uint8_t s = 0; s < 3 && !ist_addr; s++) {
    HWire.setClock(speeds[s]);
    delay(20);
    for (uint8_t a = 0x0C; a <= 0x0F; a++) {
      uint8_t id;
      if (i2c_read_reg(a, 0x00, &id) && id == 0x10) {
        ist_addr = a;
        if (s > 0) {
          MON.print(F("Luu y: phai ha bus xuong "));
          MON.print(speeds[s] / 1000);
          MON.println(F("kHz moi thay IST8310. Nen han keo len 4.7k."));
        }
        break;
      }
    }
  }
  if (!ist_addr) { HWire.setClock(I2C_CLOCK); return; }

  i2c_write_reg(ist_addr, 0x0B, 0x01);    // soft reset
  delay(20);
  i2c_write_reg(ist_addr, 0x41, 0x24);    // trung binh 16 lan X,Y,Z
  i2c_write_reg(ist_addr, 0x42, 0xC0);    // pulse duration normal
  delay(10);
}

// Doc 3 truc tho. Tra ve false neu mau khong dung duoc.
bool compass_read_raw() {
  if (!ist_addr) return false;

  if (!i2c_write_reg(ist_addr, 0x0A, 0x01)) return false;   // kich do don

  uint8_t st = 0;
  uint32_t t0 = millis();
  do {
    delay(2);
    if (!i2c_read_reg(ist_addr, 0x02, &st)) return false;
  } while (!(st & 0x01) && millis() - t0 < 30);
  if (!(st & 0x01)) return false;

  HWire.beginTransmission(ist_addr);
  HWire.write(0x03);
  if (HWire.endTransmission() != 0) return false;
  if (HWire.requestFrom(ist_addr, (uint8_t)6) != 6) return false;

  uint8_t lo, hi;
  int16_t v[3];
  for (uint8_t i = 0; i < 3; i++) {
    lo = HWire.read(); hi = HWire.read();
    v[i] = (int16_t)((hi << 8) | lo);
    if (v[i] > 5400 || v[i] < -5400) return false;   // ngoai dai +-1600 uT
  }
  compass_x = v[0]; compass_y = v[1]; compass_z = v[2];
  return true;
}

// Doc 1 mau da hieu chuan
bool compass_read_cal(float *m) {
  if (!compass_read_raw()) return false;
  float d[3] = { compass_x - mag_off[0], compass_y - mag_off[1], compass_z - mag_off[2] };
  for (uint8_t r = 0; r < 3; r++)
    m[r] = mag_W[r][0] * d[0] + mag_W[r][1] * d[1] + mag_W[r][2] * d[2];
  return true;
}

// Trung binh ~40 mau da hieu chuan, chi tinh mau doc thanh cong
bool compass_measure_avg(float *out) {
  float s[3] = {0, 0, 0}, m[3];
  uint8_t got = 0;
  for (uint8_t i = 0; i < 40; i++) {
    if (compass_read_cal(m)) {
      s[0] += m[0]; s[1] += m[1]; s[2] += m[2];
      got++;
    }
    delay(15);
  }
  if (got < 15) return false;
  for (uint8_t k = 0; k < 3; k++) out[k] = s[k] / got;
  return true;
}

bool need_compass() {
  if (ist_addr) return true;
  MON.println(F("Khong co IST8310. Chay menu a."));
  print_intro();
  return false;
}

bool need_calibration() {
  if (!need_compass()) return false;
  if (compass_calibrated) return true;
  MON.println(F("Chua hieu chuan. Chay menu d truoc."));
  print_intro();
  return false;
}

/* ===========================================================================
   6b. MENU b - KIEM TRA SUC KHOE IST8310
   5 buoc:
     1. WHO_AM_I phai = 0x10
     2. Doc 100 lan lien tiep, dem loi bus
     3. Do nhieu khi de yen (do lech chuan tung truc)
     4. SELF-TEST: bat bit 6 thanh ghi STR (0x0C), chip tu tao tu truong
        noi. So sanh voi luc tat -> moi truc phai thay doi RO RANG.
        Nguong o day la nguong THUC NGHIEM (khac biet phai lon hon nhieu
        lan nhieu), khong phai gioi han datasheet.
     5. Do lon tu truong tho co hop ly khong (chua hieu chuan nen chi
        canh bao, khong danh truot)
   =========================================================================*/

bool ist_avg_raw(uint8_t n, float *avg, float *sd) {
  float s[3] = {0, 0, 0}, s2[3] = {0, 0, 0};
  uint8_t got = 0;
  for (uint8_t i = 0; i < n; i++) {
    if (compass_read_raw()) {
      float v[3] = { (float)compass_x, (float)compass_y, (float)compass_z };
      for (uint8_t k = 0; k < 3; k++) { s[k] += v[k]; s2[k] += v[k] * v[k]; }
      got++;
    }
    delay(10);
  }
  if (got < n / 2) return false;
  for (uint8_t k = 0; k < 3; k++) {
    avg[k] = s[k] / got;
    if (sd) {
      float var = s2[k] / got - avg[k] * avg[k];
      sd[k] = (var > 0) ? sqrtf(var) : 0;
    }
  }
  return true;
}

void compass_self_test() {
  if (!need_compass()) return;
  MON.println();
  MON.println(F("--- Kiem tra suc khoe IST8310 ---"));
  MON.println(F("DE YEN board tren ban, khong cham vao. Bat dau sau 2 giay..."));
  delay(2000);
  const char *axn[3] = { "X", "Y", "Z" };
  uint8_t fails = 0;

  // 1. WHO_AM_I
  uint8_t id = 0;
  bool id_ok = i2c_read_reg(ist_addr, 0x00, &id) && id == 0x10;
  MON.print(F("1. WHO_AM_I = 0x")); MON.print(id, HEX);
  MON.println(id_ok ? F("   DAT") : F("   KHONG DAT (phai la 0x10)"));
  if (!id_ok) fails++;

  // 2. Loi bus
  uint8_t err = 0;
  for (uint8_t i = 0; i < 100; i++) { if (!compass_read_raw()) err++; delay(5); }
  MON.print(F("2. Loi doc: ")); MON.print(err); MON.print(F("/100"));
  if (err == 0)      MON.println(F("   DAT"));
  else if (err <= 2) MON.println(F("   TAM DUOC (nen han keo len 4.7k)"));
  else { MON.println(F("   KHONG DAT - day I2C dai/long, thieu keo len")); fails++; }

  // 3. Nhieu khi de yen
  float base[3], sd[3];
  if (!ist_avg_raw(50, base, sd)) {
    MON.println(F("3. Khong doc duoc du mau. Dung kiem tra."));
    print_intro();
    return;
  }
  MON.print(F("3. Nhieu (do lech chuan LSB):"));
  bool noise_ok = true;
  for (uint8_t k = 0; k < 3; k++) {
    MON.print(F("  ")); MON.print(axn[k]); MON.print('='); MON.print(sd[k], 2);
    if (sd[k] > 3.0f) noise_ok = false;
  }
  if (noise_ok) MON.println(F("   DAT"));
  else { MON.println(F("   CAO - board bi rung, hoac nhieu nguon/dong co gan do")); fails++; }

  // 4. Self-test
  float st[3];
  i2c_write_reg(ist_addr, 0x0C, 0x40);          // bat self-test
  delay(20);
  compass_read_raw();                            // bo mau chuyen tiep
  bool st_ok_read = ist_avg_raw(30, st, NULL);
  i2c_write_reg(ist_addr, 0x0C, 0x00);          // TAT self-test
  delay(20);
  compass_read_raw();

  uint8_t back = 0xFF;
  i2c_read_reg(ist_addr, 0x0C, &back);
  if (back != 0x00) {
    MON.println(F("   ! Khong tat duoc self-test - rut dien cap lai truoc khi dung."));
    fails++;
  }

  MON.println(F("4. Self-test (tat -> bat):"));
  if (!st_ok_read) {
    MON.println(F("   Doc loi trong che do self-test. KHONG DAT."));
    fails++;
  } else {
    // IST8310 o che do self-test cho ra tu truong DAO DAU (thuc nghiem:
    // 32 -> -30, 37 -> -37, -151 -> 139). Nen:
    //   - truc co tu truong du lon phai DOI DAU
    //   - (tat + bat)/2 = offset noi cua chip, phai nho
    // Truc co tu truong qua nho (<25 LSB) thi khong kiem duoc.
    uint8_t weak = 0, skipped = 0;
    for (uint8_t k = 0; k < 3; k++) {
      float mid = (st[k] + base[k]) / 2.0f;
      MON.print(F("   Truc ")); MON.print(axn[k]);
      MON.print(F(": ")); MON.print(base[k], 0);
      MON.print(F(" -> ")); MON.print(st[k], 0);
      MON.print(F("   offset noi ")); MON.print(mid, 1); MON.print(F(" LSB"));
      if (fabsf(base[k]) < 25.0f) {
        MON.println(F("   TU TRUONG QUA NHO, khong kiem duoc"));
        skipped++;
      } else if (base[k] * st[k] < 0 &&
                 fabsf(st[k]) > 0.6f * fabsf(base[k]) &&
                 fabsf(mid) < 30.0f) {
        MON.println(F("   DAT (doi dau dung)"));
      } else {
        MON.println(F("   KHONG DAT"));
        weak++;
      }
    }
    if (skipped)
      MON.println(F("   -> Nghieng board ~45 do roi chay lai b de kiem not truc con lai."));
    if (weak) {
      fails++;
      MON.println(F("   Truc khong doi dau = cam bien hong, HOAC chip nhai khong co"));
      MON.println(F("   self-test. Neu menu c van thay truc do doi khi xoay thi van dung duoc."));
    }
  }

  // 5. Do lon tu truong tho
  float b = IST_UT_PER_LSB * sqrtf(base[0] * base[0] + base[1] * base[1] + base[2] * base[2]);
  MON.print(F("5. |B| tho = ")); MON.print(b, 1); MON.print(F(" uT"));
  if (b > 20 && b < 100) MON.println(F("   HOP LY (chua hieu chuan, ~45 uT sau hieu chuan)"));
  else MON.println(F("   BAT THUONG - co sat tu/nam cham gan, hoac can hieu chuan (chi canh bao)"));

  MON.println();
  if (fails == 0) MON.println(F("==> DAT. IST8310 hoat dong binh thuong. Tiep theo: menu d."));
  else { MON.print(F("==> ")); MON.print(fails); MON.println(F(" muc KHONG DAT. Xem ghi chu tung dong o tren.")); }
  MON.println(F("Chay b 2-3 lan: ket qua phai giong nhau. Nhay lung tung = bus I2C kem."));

  delay(1500);
  print_intro();
}

/* ===========================================================================
   6. MENU c - SO THO
   =========================================================================*/

void compass_raw_stream() {
  if (!need_compass()) return;
  MON.println();
  MON.println(F("--- IST8310 tho (gui q de thoat) ---"));
  MON.println(F("Xoay board: ca 3 truc phai doi muot va doi dau."));
  MON.println(F("|B| la do lon tu truong, chua hieu chuan (~45 uT, lech la binh thuong)."));
  delay(1500);

  uint32_t errors = 0;
  while (true) {
    if (check_quit()) break;
    if (!compass_read_raw()) { errors++; delay(50); continue; }
    float b = IST_UT_PER_LSB * sqrtf((float)compass_x * compass_x +
                                     (float)compass_y * compass_y +
                                     (float)compass_z * compass_z);
    MON.print(F("X: "));   MON.print(compass_x);
    MON.print(F("\tY: ")); MON.print(compass_y);
    MON.print(F("\tZ: ")); MON.print(compass_z);
    MON.print(F("\t|B|=")); MON.print(b, 1);
    MON.print(F(" uT\tloi doc: ")); MON.println(errors);
    delay(200);
  }
  print_intro();
}

/* ===========================================================================
   7. MENU d - HIEU CHUAN BANG KHOP ELLIPSOID
   Thu mau khi xoay, roi khop 2 mo hinh tren TOAN BO mau:
     - Mo hinh CHEO (6 an): tam + 3 ban kinh doc theo truc.
       Dung truc tiep voi MAG_OFFSET / MAG_SCALE cua Nav.h hien tai.
     - Mo hinh DAY DU (9 an): them 3 so hang cheo -> bu ca nhieu sat mem
       khi ellipsoid bi XOAY. Can ma tran 3x3 trong firmware.
   In do sai lech cua ca hai de biet co can ma tran hay khong.

   DIEU KIEN DUNG: moi o trong 16 o huong phai co du CAL_BIN_TARGET mau
   (khong chi 1 mau nhu truoc), toi thieu 30 giay, toi da 90 giay.
   =========================================================================*/

#define CAL_MAX_SAMPLES   2000
#define CAL_MIN_SAMPLES   300
#define CAL_TIME_MS       90000
#define CAL_MIN_TIME_MS   30000
#define CAL_JUMP_MAX      80       // ban kinh IST ~150 -> buoc that < 40
#define CAL_JUMP_RESYNC   5
#define CAL_BINS          16
#define CAL_BIN_TARGET    25       // so mau can co trong MOI o

int16_t  cal_buf[CAL_MAX_SAMPLES][3];
uint16_t cal_n = 0;

const uint8_t cal_cnt[3]   = { 4, 8, 4 };
const uint8_t cal_start[3] = { 0, 4, 12 };
uint16_t cal_hit[CAL_BINS];

// Giai he n an (n <= 9) bang Gauss-Jordan, ma tran [n][n+1]
bool cal_solve_n(double M[9][10], uint8_t n, double *out) {
  for (uint8_t i = 0; i < n; i++) {
    uint8_t piv = i;
    for (uint8_t r = i + 1; r < n; r++)
      if (fabs(M[r][i]) > fabs(M[piv][i])) piv = r;
    if (fabs(M[piv][i]) < 1e-12) return false;
    if (piv != i)
      for (uint8_t c = 0; c <= n; c++) { double t = M[i][c]; M[i][c] = M[piv][c]; M[piv][c] = t; }
    for (uint8_t r = 0; r < n; r++) {
      if (r == i) continue;
      double f = M[r][i] / M[i][i];
      for (uint8_t c = i; c <= n; c++) M[r][c] -= f * M[i][c];
    }
  }
  for (uint8_t i = 0; i < n; i++) out[i] = M[i][n] / M[i][i];
  return true;
}

// Mo hinh CHEO: u^2 + A v^2 + B w^2 + C u + D v + E w + F = 0
bool cal_fit_diag(float c0[3], float R0, float c[3], float r[3]) {
  if (cal_n < CAL_MIN_SAMPLES || R0 < 1.0f) return false;
  double M[9][10];
  for (uint8_t a = 0; a < 6; a++) for (uint8_t b = 0; b < 7; b++) M[a][b] = 0;
  for (uint16_t i = 0; i < cal_n; i++) {
    double u = (cal_buf[i][0] - c0[0]) / R0;
    double v = (cal_buf[i][1] - c0[1]) / R0;
    double w = (cal_buf[i][2] - c0[2]) / R0;
    double row[6] = { v * v, w * w, u, v, w, 1.0 };
    double t = -(u * u);
    for (uint8_t a = 0; a < 6; a++) {
      for (uint8_t b = 0; b < 6; b++) M[a][b] += row[a] * row[b];
      M[a][6] += row[a] * t;
    }
  }
  double p[9];
  if (!cal_solve_n(M, 6, p)) return false;
  double A = p[0], B = p[1];
  if (A < 1e-6 || B < 1e-6) return false;
  double u0 = -p[2] / 2.0, v0 = -p[3] / (2.0 * A), w0 = -p[4] / (2.0 * B);
  double K  = u0 * u0 + A * v0 * v0 + B * w0 * w0 - p[5];
  if (K <= 1e-6) return false;
  c[0] = c0[0] + R0 * u0;  c[1] = c0[1] + R0 * v0;  c[2] = c0[2] + R0 * w0;
  r[0] = R0 * sqrt(K);     r[1] = R0 * sqrt(K / A); r[2] = R0 * sqrt(K / B);
  return true;
}

// Tri rieng / vector rieng ma tran doi xung 3x3 (Jacobi). Cot V = vector rieng.
void jacobi3(double A[3][3], double d[3], double V[3][3]) {
  double a[3][3];
  for (uint8_t i = 0; i < 3; i++)
    for (uint8_t j = 0; j < 3; j++) { a[i][j] = A[i][j]; V[i][j] = (i == j); }
  for (uint8_t sweep = 0; sweep < 30; sweep++) {
    double off = fabs(a[0][1]) + fabs(a[0][2]) + fabs(a[1][2]);
    if (off < 1e-15) break;
    for (uint8_t p = 0; p < 2; p++)
      for (uint8_t q = p + 1; q < 3; q++) {
        if (fabs(a[p][q]) < 1e-18) continue;
        double th = (a[q][q] - a[p][p]) / (2.0 * a[p][q]);
        double t  = (th >= 0 ? 1.0 : -1.0) / (fabs(th) + sqrt(th * th + 1.0));
        double cs = 1.0 / sqrt(t * t + 1.0), sn = t * cs;
        for (uint8_t k = 0; k < 3; k++) {          // A = A*J
          double akp = a[k][p], akq = a[k][q];
          a[k][p] = cs * akp - sn * akq;
          a[k][q] = sn * akp + cs * akq;
        }
        for (uint8_t k = 0; k < 3; k++) {          // A = J^T*A
          double apk = a[p][k], aqk = a[q][k];
          a[p][k] = cs * apk - sn * aqk;
          a[q][k] = sn * apk + cs * aqk;
        }
        for (uint8_t k = 0; k < 3; k++) {          // V = V*J
          double vkp = V[k][p], vkq = V[k][q];
          V[k][p] = cs * vkp - sn * vkq;
          V[k][q] = sn * vkp + cs * vkq;
        }
      }
  }
  for (uint8_t i = 0; i < 3; i++) d[i] = a[i][i];
}

// Mo hinh DAY DU: a u2 + b v2 + c w2 + 2d uv + 2e uw + 2f vw + 2g u + 2h v + 2i w = 1
// Ket qua: tam c[], ma tran W (m_cal = W (m - c)), ban kinh trung binh r_mean
bool cal_fit_full(float c0[3], float R0, float c[3], float W[3][3], float *r_mean,
                  float r_axes[3]) {
  if (cal_n < CAL_MIN_SAMPLES || R0 < 1.0f) return false;
  double M[9][10];
  for (uint8_t a = 0; a < 9; a++) for (uint8_t b = 0; b < 10; b++) M[a][b] = 0;
  for (uint16_t i = 0; i < cal_n; i++) {
    double u = (cal_buf[i][0] - c0[0]) / R0;
    double v = (cal_buf[i][1] - c0[1]) / R0;
    double w = (cal_buf[i][2] - c0[2]) / R0;
    double row[9] = { u * u, v * v, w * w, 2 * u * v, 2 * u * w, 2 * v * w, 2 * u, 2 * v, 2 * w };
    for (uint8_t a = 0; a < 9; a++) {
      for (uint8_t b = 0; b < 9; b++) M[a][b] += row[a] * row[b];
      M[a][9] += row[a];
    }
  }
  double p[9];
  if (!cal_solve_n(M, 9, p)) return false;

  double A[3][3] = { { p[0], p[3], p[4] }, { p[3], p[1], p[5] }, { p[4], p[5], p[2] } };
  double g[3] = { p[6], p[7], p[8] };

  // Tam: u0 = -A^-1 g  (nghich dao 3x3)
  double det = A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1])
             - A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0])
             + A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]);
  if (fabs(det) < 1e-12) return false;
  double I[3][3];
  I[0][0] =  (A[1][1] * A[2][2] - A[1][2] * A[2][1]) / det;
  I[0][1] = -(A[0][1] * A[2][2] - A[0][2] * A[2][1]) / det;
  I[0][2] =  (A[0][1] * A[1][2] - A[0][2] * A[1][1]) / det;
  I[1][0] = -(A[1][0] * A[2][2] - A[1][2] * A[2][0]) / det;
  I[1][1] =  (A[0][0] * A[2][2] - A[0][2] * A[2][0]) / det;
  I[1][2] = -(A[0][0] * A[1][2] - A[0][2] * A[1][0]) / det;
  I[2][0] =  (A[1][0] * A[2][1] - A[1][1] * A[2][0]) / det;
  I[2][1] = -(A[0][0] * A[2][1] - A[0][1] * A[2][0]) / det;
  I[2][2] =  (A[0][0] * A[1][1] - A[0][1] * A[1][0]) / det;
  double u0[3];
  for (uint8_t k = 0; k < 3; k++) u0[k] = -(I[k][0] * g[0] + I[k][1] * g[1] + I[k][2] * g[2]);

  // K = 1 + u0^T A u0 ;  A' = A / K
  double K = 1.0;
  for (uint8_t i = 0; i < 3; i++) for (uint8_t j = 0; j < 3; j++) K += u0[i] * A[i][j] * u0[j];
  if (K <= 1e-9) return false;
  for (uint8_t i = 0; i < 3; i++) for (uint8_t j = 0; j < 3; j++) A[i][j] /= K;

  double lam[3], V[3][3];
  jacobi3(A, lam, V);
  if (lam[0] <= 1e-9 || lam[1] <= 1e-9 || lam[2] <= 1e-9) return false;   // khong phai ellipsoid

  double rn = pow(lam[0] * lam[1] * lam[2], -1.0 / 6.0);   // ban kinh trung binh (chuan hoa)
  // W = rn * V diag(sqrt(lam)) V^T
  for (uint8_t i = 0; i < 3; i++)
    for (uint8_t j = 0; j < 3; j++) {
      double s = 0;
      for (uint8_t k = 0; k < 3; k++) s += V[i][k] * sqrt(lam[k]) * V[j][k];
      W[i][j] = (float)(rn * s);
    }
  for (uint8_t k = 0; k < 3; k++) {
    c[k] = c0[k] + R0 * (float)u0[k];
    r_axes[k] = R0 * (float)(1.0 / sqrt(lam[k]));   // ban kinh theo truc chinh
  }
  *r_mean = R0 * (float)rn;
  return true;
}

// Do sai lech |M| (max-min)/trung binh (%) cua mot bo hieu chuan tren cal_buf
float cal_spread(const float c[3], const float W[3][3], float *mmin_o, float *mmax_o) {
  float mmin = 1e9f, mmax = 0, msum = 0;
  for (uint16_t i = 0; i < cal_n; i++) {
    float d[3] = { cal_buf[i][0] - c[0], cal_buf[i][1] - c[1], cal_buf[i][2] - c[2] };
    float s2 = 0;
    for (uint8_t r = 0; r < 3; r++) {
      float q = W[r][0] * d[0] + W[r][1] * d[1] + W[r][2] * d[2];
      s2 += q * q;
    }
    float m = sqrtf(s2);
    if (m < mmin) mmin = m;
    if (m > mmax) mmax = m;
    msum += m;
  }
  if (mmin_o) *mmin_o = mmin;
  if (mmax_o) *mmax_o = mmax;
  float avg = msum / cal_n;
  return (avg > 1) ? (mmax - mmin) / avg * 100.0f : 999;
}

uint8_t cal_bin(float x, float y, float z) {
  float len = sqrtf(x * x + y * y + z * z);
  if (len < 30.0f) return 255;
  float el = asinf(z / len) * 57.29578f;
  uint8_t band = (el < -35.0f) ? 0 : (el > 35.0f ? 2 : 1);
  float az = atan2f(y, x) * 57.29578f;
  if (az < 0) az += 360.0f;
  uint8_t n  = cal_cnt[band];
  uint8_t ai = (uint8_t)(az / (360.0f / n));
  if (ai >= n) ai = n - 1;
  return cal_start[band] + ai;
}

// Tien do mot nhom o: tong so mau (toi da TARGET moi o)
uint16_t cal_band_fill(uint8_t b) {
  uint16_t f = 0;
  for (uint8_t i = 0; i < cal_cnt[b]; i++) {
    uint16_t h = cal_hit[cal_start[b] + i];
    f += (h > CAL_BIN_TARGET) ? CAL_BIN_TARGET : h;
  }
  return f;
}

uint16_t cal_total_fill() { return cal_band_fill(0) + cal_band_fill(1) + cal_band_fill(2); }

bool cal_all_full() {
  for (uint8_t i = 0; i < CAL_BINS; i++) if (cal_hit[i] < CAL_BIN_TARGET) return false;
  return true;
}

void cal_bar(uint16_t done, uint16_t total, uint8_t width) {
  uint8_t fill = (total > 0) ? (uint32_t)done * width / total : 0;
  MON.print('[');
  for (uint8_t i = 0; i < width; i++) MON.print(i < fill ? '#' : '.');
  MON.print(']');
}

/* Goi y dong tac con thieu - chon nhom o dang thieu nhieu nhat.
 * Nhom Ngang (tu truong gan mat phang chip): NAM NGANG quay tron.
 * Nhom Z- / Z+ (tu truong doc truc Z chip): DUNG board len quay tron. */
void cal_hint() {
  uint16_t need[3];
  for (uint8_t b = 0; b < 3; b++) {
    uint16_t full = (uint16_t)cal_cnt[b] * CAL_BIN_TARGET;
    need[b] = (full - cal_band_fill(b)) * 100 / full;       // % con thieu
  }
  // Nhom Z da gan du (>= 50%) ma van thieu -> dang dung sai canh:
  // khi dung board, hinh chieu tu truong chi quet quanh 1 phuong co dinh,
  // phai DOI CANH cham dat moi toi duoc cac o con lai.
  MON.print(F("  -> "));
  if (need[1] >= need[0] && need[1] >= need[2])
    MON.print(F("NAM NGANG, quay tron cham (ca mat ngua va mat up)"));
  else if (need[0] >= need[2]) {
    if (need[0] <= 50) MON.print(F("DOI CANH cham dat (xoay board 90 do), dung len quay tiep (Z-)"));
    else               MON.print(F("DUNG board len, quay tron cham (thieu phia Z-)"));
  } else {
    if (need[2] <= 50) MON.print(F("DOI CANH cham dat (xoay board 90 do), dung len quay tiep (Z+)"));
    else               MON.print(F("DUNG board len, LAT MAT kia roi quay (thieu phia Z+)"));
  }
}

void compass_calibrate() {
  if (!need_compass()) return;

  MON.println();
  MON.println(F("--- Hieu chuan IST8310 ---"));
  MON.println(F("Lam voi CA CUM DRONE da lap (pin, day nguon o dung vi tri bay)."));
  MON.println(F("Tranh xa ban sat, laptop, loa, dien thoai it nhat 1 met."));
  MON.println(F("Nguoi xoay KHONG deo dong ho, khong de dien thoai trong tui."));
  MON.println();
  MON.println(F("CACH QUAY - lam lan luot, moi dong tac 2-3 vong CHAM:"));
  MON.println(F("  1. NAM NGANG, quay tron nhu quay mam. Roi UP board, quay tiep."));
  MON.println(F("  2. DUNG board len, quay tron. Roi DOI CANH cham dat (xoay 90 do), quay tiep."));
  MON.println(F("  3. LON board ve phia truoc nhu banh xe, vua lon vua xoay nguoi."));
  MON.print(F("Moi o can du ")); MON.print(CAL_BIN_TARGET);
  MON.println(F(" mau. Tu dung khi du (30-90 giay)."));
  MON.println(F("Gui 'q' de DUNG SOM - van tinh ket qua tu mau da thu."));
  MON.println();
  MON.println(F("CACH DOC MAN HINH (moi giay 1 dong):"));
  MON.println(F("  Tong  = tien do chung, dat 100% la du du lieu"));
  MON.println(F("  Ngang = dong tac 1     Z-/Z+ = dong tac 2, 3"));
  MON.println(F("  Dong '->' cho biet dong tac CON THIEU. Lam theo no."));
  MON.println(F("  'QUAY CHAM LAI' = xoay qua nhanh, mau bi loai."));
  MON.println(F("  'DANG DUNG YEN' = chua xoay, khong thu them duoc gi."));
  MON.println();
  MON.println(F("Bat dau sau 3 giay..."));
  delay(3000);

  for (uint8_t i = 0; i < CAL_BINS; i++) cal_hit[i] = 0;
  cal_n = 0;

  int16_t mn[3] = { 32767, 32767, 32767 };
  int16_t mx[3] = { -32768, -32768, -32768 };
  int32_t prev[3] = { 0, 0, 0 };
  bool    prev_ok = false;
  uint8_t reject_run = 0;
  uint16_t store_every = 1, store_tick = 0;
  uint32_t rejected = 0, total = 0;
  bool aborted = false;
  bool enough  = false;   // dung vi da du du lieu (khong phai het gio)

  uint32_t start_time = millis();
  uint32_t last_print = 0;
  uint16_t sec_reject = 0;
  int16_t  sec_mn[3] = { 32767, 32767, 32767 };
  int16_t  sec_mx[3] = { -32768, -32768, -32768 };
  uint16_t last_fill = 0;
  uint16_t fill_full = (uint16_t)CAL_BINS * CAL_BIN_TARGET;

  // Giai doan 1 (2 giay): uoc luong tam tho, gieo mau "truoc do"
  while (millis() - start_time < 2000) {
    if (compass_read_raw()) {
      int16_t v[3] = { compass_x, compass_y, compass_z };
      for (uint8_t k = 0; k < 3; k++) {
        if (v[k] < mn[k]) mn[k] = v[k];
        if (v[k] > mx[k]) mx[k] = v[k];
        prev[k] = v[k];
      }
      prev_ok = true;
    }
    delay(20);
  }

  // Giai doan 2: quay tu do
  while (true) {
    if (check_quit()) { aborted = true; break; }
    uint32_t elapsed = millis() - start_time;
    if (elapsed > CAL_TIME_MS) break;
    delay(20);

    total++;
    if (!compass_read_raw()) { rejected++; continue; }
    int16_t v[3] = { compass_x, compass_y, compass_z };

    if (prev_ok) {
      int32_t d2 = 0;
      for (uint8_t k = 0; k < 3; k++) { int32_t d = v[k] - prev[k]; d2 += d * d; }
      if (d2 > (int32_t)CAL_JUMP_MAX * CAL_JUMP_MAX) {
        rejected++;
        sec_reject++;
        if (++reject_run < CAL_JUMP_RESYNC) continue;
      }
    }
    reject_run = 0;
    for (uint8_t k = 0; k < 3; k++) {
      prev[k] = v[k];
      if (v[k] < mn[k]) mn[k] = v[k];
      if (v[k] > mx[k]) mx[k] = v[k];
      if (v[k] < sec_mn[k]) sec_mn[k] = v[k];
      if (v[k] > sec_mx[k]) sec_mx[k] = v[k];
    }
    prev_ok = true;

    if (++store_tick >= store_every) {
      store_tick = 0;
      if (cal_n >= CAL_MAX_SAMPLES) {
        for (uint16_t i = 0; i < CAL_MAX_SAMPLES / 2; i++)
          for (uint8_t k = 0; k < 3; k++) cal_buf[i][k] = cal_buf[i * 2][k];
        cal_n = CAL_MAX_SAMPLES / 2;
        store_every *= 2;
      }
      for (uint8_t k = 0; k < 3; k++) cal_buf[cal_n][k] = v[k];
      cal_n++;
    }

    uint8_t b = cal_bin(v[0] - (mx[0] + mn[0]) / 2.0f,
                        v[1] - (mx[1] + mn[1]) / 2.0f,
                        v[2] - (mx[2] + mn[2]) / 2.0f);
    if (b != 255 && cal_hit[b] < 60000) cal_hit[b]++;

    if (elapsed - last_print >= 1000) {
      last_print = elapsed;
      uint16_t fill = cal_total_fill();
      uint8_t  pct  = (uint32_t)fill * 100 / fill_full;
      uint8_t  left = (CAL_TIME_MS - elapsed) / 1000;
      if (left < 10) MON.print(' ');
      MON.print(left);
      MON.print(F("s Tong "));
      cal_bar(fill, fill_full, 20);
      MON.print(' ');
      if (pct < 100) MON.print(' ');
      if (pct < 10)  MON.print(' ');
      MON.print(pct);
      MON.print(F("%  Ngang"));
      cal_bar(cal_band_fill(1), (uint16_t)cal_cnt[1] * CAL_BIN_TARGET, 8);
      MON.print(F(" Z-"));
      cal_bar(cal_band_fill(0), (uint16_t)cal_cnt[0] * CAL_BIN_TARGET, 4);
      MON.print(F(" Z+"));
      cal_bar(cal_band_fill(2), (uint16_t)cal_cnt[2] * CAL_BIN_TARGET, 4);
      if (fill > last_fill) MON.print(F("  +"));
      else                  MON.print(F("   "));

      int16_t span = 0;
      for (uint8_t k = 0; k < 3; k++) {
        int16_t sp = sec_mx[k] - sec_mn[k];
        if (sp > span) span = sp;
        sec_mn[k] = 32767; sec_mx[k] = -32768;
      }

      if (sec_reject > 3)      MON.print(F(" !! QUAY CHAM LAI"));
      else if (span < 15)      MON.print(F(" .. DANG DUNG YEN, hay xoay"));
      else if (!cal_all_full()) cal_hint();
      else                     MON.print(F(" ** DU 100% **"));
      MON.println();

      last_fill  = fill;
      sec_reject = 0;
    }
    if (cal_all_full() && elapsed > CAL_MIN_TIME_MS) {
      MON.println(F("  Moi o da du mau, dung."));
      enough = true;
      break;
    }
    // Du dung: sau 60s, tong >= 95% va khong o nao duoi 10 mau
    if (elapsed > 60000 && (uint32_t)cal_total_fill() * 100 >= (uint32_t)fill_full * 95) {
      bool ok = true;
      for (uint8_t i = 0; i < CAL_BINS; i++) if (cal_hit[i] < 10) { ok = false; break; }
      if (ok) { MON.println(F("  Du dung (>=95%, moi o >= 10 mau), dung.")); enough = true; break; }
    }
  }

  MON.println();
  if (aborted) MON.println(F("Dung som theo yeu cau - tinh tu mau da thu."));
  if (!aborted && !enough)
    MON.println(F("HET GIO nhung chua du mau o mot so huong - ket qua co the kem."));
  MON.print(F("Mau da luu: ")); MON.print(cal_n);
  MON.print(F("   Mau bi loai: ")); MON.print(rejected);
  if (total) { MON.print(F(" (")); MON.print(rejected * 100 / total); MON.print(F("%)")); }
  MON.println();
  if (total && rejected * 100 > total * 5)
    MON.println(F("  ! Ti le loai cao (>5%): bus I2C nhieu, hoac quay qua nhanh."));
  MON.println();

  float c0[3];
  for (uint8_t k = 0; k < 3; k++) c0[k] = (mx[k] + mn[k]) / 2.0f;
  float R0 = ((mx[0] - mn[0]) + (mx[1] - mn[1]) + (mx[2] - mn[2])) / 6.0f;

  // --- Mo hinh cheo ---
  float cd[3], rd[3], Wd[3][3] = { {1, 0, 0}, {0, 1, 0}, {0, 0, 1} };
  bool ok_d = cal_fit_diag(c0, R0, cd, rd);
  float rd_avg = 0, sp_d = 999, dmin = 0, dmax = 0;
  if (ok_d) {
    rd_avg = (rd[0] + rd[1] + rd[2]) / 3.0f;
    for (uint8_t k = 0; k < 3; k++) Wd[k][k] = rd_avg / rd[k];
    sp_d = cal_spread(cd, Wd, &dmin, &dmax);
  }

  // --- Mo hinh day du ---
  float cf[3], Wf[3][3], rf_mean = 0, rf_ax[3];
  bool ok_f = cal_fit_full(c0, R0, cf, Wf, &rf_mean, rf_ax);
  float sp_f = 999, fmin = 0, fmax = 0;
  if (ok_f) sp_f = cal_spread(cf, Wf, &fmin, &fmax);

  if (!ok_d && !ok_f) {
    MON.println(F("KHOP THAT BAI - du lieu chua du da dang."));
    MON.println(F("Chay lai va lam DU CA BA dong tac."));
    delay(3000);
    print_intro();
    return;
  }

  MON.println(F("--- KET QUA ---"));
  if (ok_d) {
    MON.println(F("Mo hinh CHEO (dung ngay voi Nav.h hien tai):"));
    MON.print(F("  Tam:      ")); MON.print(cd[0], 1); MON.print(F(" / "));
    MON.print(cd[1], 1); MON.print(F(" / ")); MON.println(cd[2], 1);
    MON.print(F("  Ban kinh: ")); MON.print(rd[0], 1); MON.print(F(" / "));
    MON.print(rd[1], 1); MON.print(F(" / ")); MON.print(rd[2], 1);
    MON.print(F("   tb ")); MON.print(rd_avg, 1);
    MON.print(F(" (= ")); MON.print(rd_avg * IST_UT_PER_LSB, 1); MON.println(F(" uT)"));
    MON.print(F("  Sai lech |M|: ")); MON.print(sp_d, 1);
    MON.print(F("%  (min ")); MON.print(dmin, 0); MON.print(F(" max ")); MON.print(dmax, 0);
    MON.println(')');
  }
  if (ok_f) {
    MON.println(F("Mo hinh DAY DU (co so hang cheo - can ma tran 3x3):"));
    MON.print(F("  Tam:      ")); MON.print(cf[0], 1); MON.print(F(" / "));
    MON.print(cf[1], 1); MON.print(F(" / ")); MON.println(cf[2], 1);
    MON.print(F("  Ban kinh truc chinh: ")); MON.print(rf_ax[0], 1); MON.print(F(" / "));
    MON.print(rf_ax[1], 1); MON.print(F(" / ")); MON.print(rf_ax[2], 1);
    MON.print(F("   tb ")); MON.println(rf_mean, 1);
    MON.print(F("  Sai lech |M|: ")); MON.print(sp_f, 1);
    MON.print(F("%  (min ")); MON.print(fmin, 0); MON.print(F(" max ")); MON.print(fmax, 0);
    MON.println(')');
  }
  MON.print(F("  Ly thuyet Ha Noi ~")); MON.print(IST_R_THEORY, 0);
  MON.println(F(" LSB (~45 uT)"));
  MON.println();

  // Chon mo hinh dung trong sketch
  bool use_full = ok_f && (!ok_d || sp_f < sp_d - 2.0f);
  const float *cc = use_full ? cf : cd;
  for (uint8_t k = 0; k < 3; k++) mag_off[k] = cc[k];
  for (uint8_t i = 0; i < 3; i++)
    for (uint8_t j = 0; j < 3; j++) mag_W[i][j] = use_full ? Wf[i][j] : Wd[i][j];
  mag_full_model = use_full;
  mag_cal_radius = use_full ? rf_mean : rd_avg;
  compass_calibrated = true;
  axis_configured = false;          // hieu chuan moi -> chay lai 'w'

  float sp = use_full ? sp_f : sp_d;
  MON.print(F("==> Dung mo hinh ")); MON.print(use_full ? F("DAY DU") : F("CHEO"));
  MON.print(F(", sai lech ")); MON.print(sp, 1); MON.print(F("%  -> "));
  if      (sp < 10) MON.println(F("TOT"));
  else if (sp < 15) MON.println(F("KHA"));
  else if (sp < 20) MON.println(F("TAM DUOC - nen lam lai o cho thoang hon"));
  else              MON.println(F("KEM - lam lai o cho khac"));
  if (use_full) {
    MON.println(F("  Mo hinh day du tot hon ro ret: ellipsoid bi XOAY (nhieu sat mem"));
    MON.println(F("  lech truc). Khi ghep vao code chinh can dung MA TRAN (menu t in ra)."));
  }
  MON.println(F("  Sai lech con lai phan lon do moi truong (ban, sat thep, laptop)"));
  MON.println(F("  va tay nguoi xoay - thu o ngoai troi se thap hon."));
  MON.println();
  MON.println(F("Buoc tiep theo: menu j de kiem tra doc lap, roi menu w."));

  delay(3000);
  print_intro();
}

/* ===========================================================================
   8. MENU j - KIEM TRA HIEU CHUAN BANG DU LIEU MOI
   =========================================================================*/

void compass_check_calibration() {
  if (!need_calibration()) return;
  MON.println();
  MON.println(F("--- Kiem tra hieu chuan (gui q de thoat) ---"));
  MON.println(F("Xoay board cham theo moi huong. |M| phai gan nhu KHONG DOI."));
  delay(2000);

  float mmin = 1e9f, mmax = 0, msum = 0, m[3];
  uint32_t n = 0, cnt = 0;
  while (true) {
    if (check_quit()) break;
    delay(20);
    if (!compass_read_cal(m)) continue;
    float mag = sqrtf(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
    if (mag < mmin) mmin = mag;
    if (mag > mmax) mmax = mag;
    msum += mag; n++;
    if (++cnt >= 15) {
      cnt = 0;
      float avg = msum / n;
      float sp  = (mmax - mmin) / avg * 100.0f;
      MON.print(F("|M| = ")); MON.print(mag, 0);
      MON.print(F("\tmin=")); MON.print(mmin, 0);
      MON.print(F("  max=")); MON.print(mmax, 0);
      MON.print(F("\tsai lech: ")); MON.print(sp, 1); MON.print(F("%  "));
      if      (sp < 10) MON.println(F("TOT"));
      else if (sp < 20) MON.println(F("tam duoc"));
      else              MON.println(F("KEM"));
    }
  }
  if (n > 0) {
    float avg = msum / n;
    MON.println();
    MON.print(F("Tong ket: |M| trung binh ")); MON.print(avg, 0);
    MON.print(F(", sai lech ")); MON.print((mmax - mmin) / avg * 100.0f, 1);
    MON.println('%');
    if (mag_cal_radius > 1) {
      float ratio = avg / mag_cal_radius;
      MON.print(F("Luc hieu chuan |M| = ")); MON.print(mag_cal_radius, 0);
      MON.print(F("  -> bay gio lech ")); MON.print((ratio - 1.0f) * 100.0f, 0);
      MON.println('%');
      if (ratio > 1.08f || ratio < 0.92f) {
        MON.println(F("  ! Tu truong O CHO NAY khac cho luc hieu chuan (sat thep, cot"));
        MON.println(F("    be tong, may tinh...). Hieu chuan van dung, nhung heading o"));
        MON.println(F("    day se lech. Lam menu w / e o cho co |M| gan luc hieu chuan."));
      }
    }
  }
  delay(1500);
  print_intro();
}

/* ===========================================================================
   9. MENU w - TU DO ANH XA TRUC
   Dua tren: o Ha Noi tu truong chuc XUONG ~30 do.
   Do 4 tu the, thu 24 phep quay hop le, cham diem theo 6 tieu chi.

   GOC NGHIENG: dung ~45 do. KHONG nghieng qua 60 do - khi mui huong Bac,
   nghieng qua ~2 lan do chuc (60 do) thi thanh phan FWD GIAM thay vi tang,
   tieu chi dau bi dao va thuat toan co the tra ve ket qua sai ma van
   bao "dang tin".
   =========================================================================*/

const uint8_t AX_PERM[6][3] = { {0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0} };
const int8_t  AX_PSIGN[6]   = { +1, -1, -1, +1, +1, -1 };   // dau cua hoan vi
bool ax_left_handed = false;    // true = he truc cam bien THUAN TAY TRAI
float AxPose[4][3];

const char *ax_name(uint8_t i) { return (i == 0) ? "mx" : (i == 1) ? "my" : "mz"; }

bool ax_capture(uint8_t idx, const __FlashStringHelper *msg) {
  MON.println();
  MON.println(msg);
  MON.println(F("  Giu yen roi bam phim bat ky."));
  wait_for_key();
  MON.println(F("  Dang do..."));
  if (!compass_measure_avg(AxPose[idx])) {
    MON.println(F("  Doc loi qua nhieu. Kiem tra bus I2C."));
    return false;
  }
  MON.print(F("  mx=")); MON.print(AxPose[idx][0], 0);
  MON.print(F("  my=")); MON.print(AxPose[idx][1], 0);
  MON.print(F("  mz=")); MON.println(AxPose[idx][2], 0);
  return true;
}

void print_axis_macros() {
  const char *nm[3] = { "MAG_FWD  ", "MAG_RIGHT", "MAG_DOWN " };
  for (uint8_t i = 0; i < 3; i++) {
    MON.print(F("#define ")); MON.print(nm[i]); MON.print(F("   ("));
    MON.print(ax_sgn[i] > 0 ? ' ' : '-'); MON.print(ax_name(ax_map[i]));
    MON.println(')');
  }
  MON.println(F("#define MAG_HEADING_OFFSET  0.0f"));
}

void compass_axis_wizard() {
  if (!need_calibration()) return;

  MON.println();
  MON.println(F("--- Tu do anh xa truc ---"));
  MON.println(F("Cam CA CON DRONE. Giu HUONG MUI khong doi trong ca 4 tu the."));
  MON.println(F("Nghieng KHOANG 45 DO - khong nghieng qua 60 do."));
  MON.println(F("Chac nhat khi mui huong DONG BAC / NAM / TAY BAC (tranh dung Dong, Tay)."));

  if (!ax_capture(0, F("TU THE 1/4: drone NAM NGANG."))                 ||
      !ax_capture(1, F("TU THE 2/4: CHUC MUI XUONG ~45 do."))          ||
      !ax_capture(2, F("TU THE 3/4: NGHIENG SUON PHAI XUONG ~45 do.")) ||
      !ax_capture(3, F("TU THE 4/4: LAT NGUA (bung len troi)."))) {
    print_intro();
    return;
  }

  float R = 0;
  for (uint8_t p = 0; p < 4; p++)
    R += sqrtf(AxPose[p][0] * AxPose[p][0] + AxPose[p][1] * AxPose[p][1] +
               AxPose[p][2] * AxPose[p][2]);
  R /= 4.0f;
  if (R < 20) {
    MON.println(F("Tu truong qua yeu. Kiem tra hieu chuan."));
    print_intro();
    return;
  }

  float best = -1e9f, second = -1e9f;
  uint8_t bP = 0; int8_t bS[3] = { 1, 1, 1 };

  // Xet CA 48 kha nang (24 phep quay + 24 phep quay kem lat guong).
  // IST8310 tren nhieu module co he truc THUAN TAY TRAI so voi than drone
  // (chip dan lat mat), luc do dap an dung nam trong 24 truong hop lat guong.
  for (uint8_t pi = 0; pi < 6; pi++)
    for (int8_t s0 = -1; s0 <= 1; s0 += 2)
      for (int8_t s1 = -1; s1 <= 1; s1 += 2)
        for (int8_t s2 = -1; s2 <= 1; s2 += 2) {
          float F[4], Rt[4], D[4];
          for (uint8_t p = 0; p < 4; p++) {
            F[p]  = s0 * AxPose[p][AX_PERM[pi][0]];
            Rt[p] = s1 * AxPose[p][AX_PERM[pi][1]];
            D[p]  = s2 * AxPose[p][AX_PERM[pi][2]];
          }
          float e  = fabsf(D[3] + D[0]);            // lat ngua: DOWN doi dau
          e += fabsf(Rt[1] - Rt[0]);                // chuc mui: RIGHT giu nguyen
          e += fabsf(F[2]  - F[0]);                 // nghieng phai: FWD giu nguyen
          e += 3.0f * fmaxf(0.0f, -D[0]);           // nam ngang: DOWN duong
          e += 3.0f * fmaxf(0.0f, F[0]  - F[1]);    // chuc mui: FWD tang
          e += 3.0f * fmaxf(0.0f, Rt[0] - Rt[2]);   // nghieng phai: RIGHT tang
          float score = -e / R;
          if (score > best) {
            second = best; best = score;
            bP = pi; bS[0] = s0; bS[1] = s1; bS[2] = s2;
          } else if (score > second) second = score;
        }

  float F[4], Rt[4], D[4];
  for (uint8_t p = 0; p < 4; p++) {
    F[p]  = bS[0] * AxPose[p][AX_PERM[bP][0]];
    Rt[p] = bS[1] * AxPose[p][AX_PERM[bP][1]];
    D[p]  = bS[2] * AxPose[p][AX_PERM[bP][2]];
  }
  float incl   = asinf(constrain(D[0] / R, -1.0f, 1.0f)) * 57.29578f;
  float margin = best - second;
  ax_left_handed = (AX_PSIGN[bP] * bS[0] * bS[1] * bS[2] != 1);

  // Kiem tra VAT LY - phai dung het, khong chi dua vao khoang cach diem
  uint8_t bad = 0;
  if (incl < 15.0f || incl > 50.0f)      bad++;   // do chuc Ha Noi ~30
  if (D[3] > -0.3f * R)                  bad++;   // lat ngua: DOWN phai am
  if (F[1]  <= F[0]  + 0.05f * R)        bad++;   // chuc mui: FWD phai tang
  if (Rt[2] <= Rt[0] + 0.05f * R)        bad++;   // nghieng phai: RIGHT phai tang
  if (fabsf(Rt[1] - Rt[0]) > 0.35f * R)  bad++;   // chuc mui: RIGHT gan nhu giu nguyen
  if (fabsf(F[2]  - F[0])  > 0.35f * R)  bad++;   // nghieng phai: FWD gan nhu giu nguyen

  MON.println();
  MON.println(F("--- KIEM CHUNG ---"));
  MON.print(F("  Nam ngang: DOWN = ")); MON.print(D[0], 0);
  MON.print(F("  -> do chuc ")); MON.print(incl, 1); MON.println(F(" do (Ha Noi ~+30)"));
  MON.print(F("  Lat ngua:  DOWN = ")); MON.print(D[3], 0); MON.println(F("  (phai AM)"));
  MON.print(F("  Chuc mui:  FWD ")); MON.print(F[0], 0);
  MON.print(F(" -> ")); MON.print(F[1], 0); MON.println(F("  (phai TANG)"));
  MON.print(F("  Nghieng phai: RIGHT ")); MON.print(Rt[0], 0);
  MON.print(F(" -> ")); MON.print(Rt[2], 0); MON.println(F("  (phai TANG)"));
  MON.print(F("  Sai so: ")); MON.print(-best, 3);
  MON.print(F("   ve nhi: ")); MON.print(-second, 3);
  MON.print(F("   khoang cach: ")); MON.println(margin, 3);
  MON.println();

  for (uint8_t i = 0; i < 3; i++) { ax_map[i] = AX_PERM[bP][i]; ax_sgn[i] = bS[i]; }

  if (margin >= 0.08f && bad == 0) {
    axis_configured = true;
    MON.println(F("  ==> DANG TIN. Da luu, menu e se dung ket qua nay."));
    if (ax_left_handed)
      MON.println(F("  (He truc cam bien thuan TAY TRAI - binh thuong voi IST8310.)"));
  } else {
    axis_configured = false;
    if (bad) {
      MON.print(F("  ! SAI VAT LY: ")); MON.print(bad);
      MON.println(F(" phep thu o tren khong dat - chua luu."));
    } else {
      MON.println(F("  ! CHUA PHAN BIET DUOC - chua luu."));
    }
    MON.println(F("    Lam lai va chu y:"));
    MON.println(F("    - GIU NGUYEN huong mui trong ca 4 tu the, chi nghieng"));
    MON.println(F("    - nghieng ~45 do (khong sau hon 60)"));
    MON.println(F("    - dung thu tu: nam ngang / chuc mui / nghieng suon PHAI / lat ngua"));
    MON.println(F("    - mui huong Dong Bac, Nam hoac Tay Bac; tranh dung Dong, Tay"));
    MON.println(F("    - ra cho thoang, xa sat thep"));
  }
  MON.println();
  MON.println(F("=== Macro de xem (CHUA chep neu chua dang tin) ==="));
  print_axis_macros();
  MON.println(F("=================================================="));
  MON.println(F("Nghiem thu: menu e, Bac 0 / Dong 90 / Nam 180 / Tay 270."));

  delay(4000);
  print_intro();
}

/* ===========================================================================
   10. MENU e - HEADING (dung dung cong thuc cua Nav.h)
       heading = atan2(-RIGHT, FWD) + DECLINATION
   Chua bu nghieng: giu drone NAM NGANG.
   =========================================================================*/

void compass_heading_stream() {
  if (!need_calibration()) return;
  MON.println();
  MON.println(F("--- Heading (gui q de thoat) ---"));
  if (!axis_configured)
    MON.println(F("CANH BAO: chua chay menu w - tam dung FWD=mx, RIGHT=my, co the SAI."));
  MON.println(F("Giu drone NAM NGANG. 0=Bac, 90=Dong, 180=Nam, 270=Tay."));
  delay(2000);

  float m[3];
  while (true) {
    if (check_quit()) break;
    if (!compass_read_cal(m)) { delay(20); continue; }

    float fwd   = ax_sgn[0] * m[ax_map[0]];
    float right = ax_sgn[1] * m[ax_map[1]];
    float down  = ax_sgn[2] * m[ax_map[2]];

    float heading = atan2f(-right, fwd) * 57.29578f + MAG_DECLINATION;
    while (heading < 0)    heading += 360;
    while (heading >= 360) heading -= 360;

    MON.print(F("Heading: ")); MON.print(heading, 1); MON.print(F(" do  ("));
    const char *dirs[8] = { "Bac", "Dong Bac", "Dong", "Dong Nam",
                            "Nam", "Tay Nam", "Tay", "Tay Bac" };
    MON.print(dirs[(uint8_t)((heading + 22.5f) / 45.0f) % 8]);
    MON.print(F(")   DOWN=")); MON.println(down, 0);
    delay(250);
  }
  print_intro();
}

/* ===========================================================================
   11. MENU t - IN MACRO CHO Config.h MUC [9]
   =========================================================================*/

void print_nav_macros() {
  if (!need_calibration()) return;
  MON.println();
  MON.println(F("=== CHEP DE VAO Config.h MUC [9] (la ban IST8310) ==="));
  const char *axn[3] = { "X", "Y", "Z" };
  for (uint8_t k = 0; k < 3; k++) {
    MON.print(F("#define MAG_OFFSET_")); MON.print(axn[k]); MON.print(F("    "));
    MON.print(mag_off[k], 1); MON.println('f');
  }
  if (!mag_full_model) {
    for (uint8_t k = 0; k < 3; k++) {
      MON.print(F("#define MAG_SCALE_")); MON.print(axn[k]); MON.print(F("     "));
      MON.print(mag_W[k][k], 4); MON.println('f');
    }
  } else {
    MON.println(F("// Mo hinh DAY DU: m_cal = SOFT * (m - OFFSET)"));
    for (uint8_t i = 0; i < 3; i++) {
      MON.print(F("#define MAG_SOFT_R")); MON.print(i); MON.print(F("   { "));
      for (uint8_t j = 0; j < 3; j++) {
        MON.print(mag_W[i][j], 5); MON.print('f');
        if (j < 2) MON.print(F(", "));
      }
      MON.println(F(" }"));
    }
  }
  MON.print(F("#define MAG_FIELD_NOMINAL   ")); MON.print(mag_cal_radius, 1); MON.println('f');
  if (axis_configured) print_axis_macros();
  else MON.println(F("// MAG_FWD/RIGHT/DOWN: CHUA CO - chay menu w"));
  MON.print(F("#define MAG_DECLINATION     ")); MON.print(MAG_DECLINATION, 2); MON.println('f');
  MON.println(F("================================================="));
  MON.println(F("LUU Y: gia tri bi mat khi rut dien. Chep ngay."));
  MON.println(F("Chep xong, dat  #define MAG_CAL_DONE 1  trong Config.h."));
  delay(2000);
  print_intro();
}
/* ===========================================================================
   12. GPS GEP-M10 (u-blox M10)
   =========================================================================*/

void gps_raw_dump() {
  MON.println();
  MON.println(F("--- Du lieu GPS tho (gui q de thoat) ---"));
  MON.print(F("Cong GPS dang o ")); MON.print(gps_baudrate); MON.println(F(" bps."));
  MON.println(F("Da cau hinh bay (g/x): thay 'UBX 01 07 len 92' (NAV-PVT) 10 lan/giay."));
  MON.println(F("Module moi reset: thay cau NMEA $GNGGA ... -> bam x de chuyen sang NAV-PVT."));
  MON.println(F("Khong thay gi -> sai baud (menu l) hoac dao day TX/RX."));
  MON.println();
  delay(1500);
  while (GpsSerial.available()) GpsSerial.read();
  gps_frame_reset();

  uint32_t bytes = 0, frames = 0, last = millis();
  while (true) {
    if (check_quit()) break;
    while (GpsSerial.available()) {
      bytes++;
      uint8_t r = gps_frame_feed(GpsSerial.read());
      if (!r) continue;
      frames++;
      if (r == 1) { MON.println(gps_last_nmea()); continue; }
      MON.print(F("UBX ")); if (gf_last_cls < 16) MON.print('0'); MON.print(gf_last_cls, HEX);
      MON.print(' ');       if (gf_last_id  < 16) MON.print('0'); MON.print(gf_last_id, HEX);
      MON.print(F(" len ")); MON.print(gf_last_len);
      if (r == 3) {
        MON.print(F("  NAV-PVT fix ")); MON.print(pvt_fix); MON.print(F(" sat ")); MON.print(pvt_sats);
        MON.print(F(" hAcc ")); MON.print(pvt_hacc, 2); MON.print('m');
      }
      MON.println();
    }
    if (millis() - last > 3000) {
      if (frames == 0) {
        MON.print(F("(3 giay: ")); MON.print(bytes);
        MON.println(bytes ? F(" byte nhung khong goi nao hop le -> SAI BAUD, menu l)") : F(" byte -> kiem tra day)"));
      }
      bytes = frames = 0; last = millis();
    }
  }
  print_intro();
}


/* ---------------------------------------------------------------------------
 * BO NHAN GOI CHUNG: nap tung byte, nhan ra ca cau NMEA (module moi reset)
 * lan goi UBX (da cau hinh). Tra ve 0 = chua, 1 = cau NMEA dung checksum,
 * 2 = goi UBX dung checksum, 3 = goi NAV-PVT (da phan tich vao pvt_*).
 * Offset NAV-PVT (92 byte): 20 fixType 21 flags 23 numSV 24 lon 28 lat
 * 36 hMSL 40 hAcc 48 velN 52 velE (mm, mm/s) 76 pDOP x0.01
 * -------------------------------------------------------------------------*/
static char     gf_line[100];
static uint8_t  gf_li = 0;
static uint8_t  gf_st = 0, gf_cls, gf_id, gf_a, gf_b, gf_arx;
static uint16_t gf_len, gf_idx;
static uint8_t  gf_pl[100];

static int32_t le_i4(const uint8_t *p) {
  return (int32_t)((uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24));
}

void pvt_parse(const uint8_t *p) {
  pvt_fix  = p[20];
  pvt_ok   = (p[21] & 0x01) && (pvt_fix == 3 || pvt_fix == 4);
  pvt_sats = p[23];
  pvt_lon  = le_i4(p + 24) * 1e-7;
  pvt_lat  = le_i4(p + 28) * 1e-7;
  pvt_alt  = le_i4(p + 36) * 0.001f;
  pvt_hacc = (uint32_t)le_i4(p + 40) * 0.001f;
  pvt_vn   = le_i4(p + 48) * 0.1f;          // mm/s -> cm/s
  pvt_ve   = le_i4(p + 52) * 0.1f;
  pvt_pdop = ((uint16_t)p[76] | ((uint16_t)p[77] << 8)) * 0.01f;
  pvt_count++; pvt_last_ms = millis();
  // cho menu o (khao sat) va man hinh chao
  gps_fix_type = pvt_ok ? pvt_fix : 0;
  gps_satellites = pvt_sats;
  gps_hdop = pvt_pdop;
}

bool pvt_healthy() { return pvt_ok && pvt_sats >= PVT_MIN_SATS && pvt_hacc < PVT_MAX_HACC; }

void gps_frame_reset() { gf_li = 0; gf_st = 0; }

uint8_t gps_frame_feed(uint8_t c) {
  uint8_t res = 0;
  // NMEA
  if (c == '$') { gf_li = 0; gf_line[gf_li++] = c; }
  else if (gf_li > 0) {
    if (c == '\r' || c == '\n') {
      gf_line[gf_li] = 0; gf_li = 0;
      if (nmea_checksum_ok(gf_line)) res = 1;
    } else if (gf_li < sizeof(gf_line) - 1) gf_line[gf_li++] = c;
    else gf_li = 0;
  }
  // UBX
  switch (gf_st) {
    case 0: if (c == 0xB5) gf_st = 1; break;
    case 1: gf_st = (c == 0x62) ? 2 : 0; break;
    case 2: gf_cls = c; gf_a = c; gf_b = gf_a; gf_st = 3; break;
    case 3: gf_id = c; gf_a += c; gf_b += gf_a; gf_st = 4; break;
    case 4: gf_len = c; gf_a += c; gf_b += gf_a; gf_st = 5; break;
    case 5:
      gf_len |= (uint16_t)c << 8; gf_a += c; gf_b += gf_a; gf_idx = 0;
      if (gf_len > 1024) { gf_st = 0; break; }
      gf_st = gf_len ? 6 : 7; break;
    case 6:
      if (gf_idx < sizeof(gf_pl)) gf_pl[gf_idx] = c;
      gf_idx++; gf_a += c; gf_b += gf_a;
      if (gf_idx >= gf_len) gf_st = 7;
      break;
    case 7: gf_arx = c; gf_st = 8; break;
    case 8:
      gf_st = 0;
      if (gf_arx == gf_a && c == gf_b) {
        gf_last_cls = gf_cls; gf_last_id = gf_id; gf_last_len = gf_len;
        res = 2;
        if (gf_cls == 0x01 && gf_id == 0x07 && gf_len == 92) { pvt_parse(gf_pl); res = 3; }
      }
      break;
  }
  return res;
}

const char *gps_last_nmea() { return gf_line; }

// ---------------------------------------------------------------------------
// Tu do baudrate cua module GPS.
// Voi moi toc do, mo cong roi dem so goi UBX / cau NMEA dung checksum
// trong ~1.2 giay. Baudrate dung se cho ra nhieu goi hop le.
// Dung khi: module dang o toc do khac 115200 (vd chip goc M10 xuat xuong 38400).
// ---------------------------------------------------------------------------
void gps_baud_autodetect(bool verbose) {
  if (verbose) {
    MON.println();
    MON.println(F("--- Tu do baudrate GPS ---"));
  } else {
    MON.println(F("Dang do baudrate GPS..."));
  }

  uint32_t best_baud = 0;
  uint16_t best_score = 0;

  for (uint8_t i = 0; i < 5; i++) {
    GpsSerial.begin(GPS_BAUD_LIST[i]);
    delay(120);
    while (GpsSerial.available()) GpsSerial.read();   // bo phan cau dang do dang

    /* Dem goi CO CHECKSUM DUNG (cau NMEA hoac goi UBX), khong dem ky tu:
     * doc sai toc do van ra rac, rac tinh co chua '$' / 0xB5 -> chon nham. */
    uint16_t dollars = 0, bytes = 0;
    gps_frame_reset();
    uint32_t t0 = millis();
    while (millis() - t0 < 1200) {
      while (GpsSerial.available()) {
        bytes++;
        if (gps_frame_feed(GpsSerial.read())) dollars++;
      }
    }

    if (verbose) {
      MON.print(F("  "));
      MON.print(GPS_BAUD_LIST[i]);
      MON.print(F(" bps -> "));
      MON.print(bytes);
      MON.print(F(" byte, "));
      MON.print(dollars);
      MON.println(F(" goi hop le (UBX/NMEA)"));
    }

    if (dollars > best_score) { best_score = dollars; best_baud = GPS_BAUD_LIST[i]; }
    if (!verbose && dollars >= 2) break;    // khoi dong: thay la dung, khong do tiep
  }

  if (best_baud == 0) {
    // Khong tim thay gi: giu 115200 va bao loi phan cung
    GpsSerial.begin(115200);
    gps_baudrate = 115200;
    MON.println(F("KHONG NHAN DUOC GOI UBX / CAU NMEA NAO o bat ky toc do nao!"));
    MON.println(F("  -> Kiem tra day: GPS TX phai vao PA10, GPS RX vao PA9 (de bi CHEO)"));
    MON.println(F("  -> Kiem tra nguon 5V va GND, den LED tren module co sang khong"));
    MON.println(F("  -> Neu PA9/PA10 bi board dung cho viec khac (USB VBUS...), doi UART khac"));
  } else {
    GpsSerial.begin(best_baud);
    gps_baudrate = best_baud;
    MON.print(F("Da chon "));
    MON.print(best_baud);
    MON.println(F(" bps."));
  }
  delay(200);
  while (GpsSerial.available()) GpsSerial.read();
  if (verbose) delay(1500);
}

// ---------------------------------------------------------------------------
// Khoi phuc module ve mac dinh nha may.
// Dung khi da lo cau hinh sai (vd luu nham 57600 hoac tat het GNSS).
// Gui lenh xoa o TAT CA cac baudrate vi khong biet module dang o dau.
// ---------------------------------------------------------------------------
void gps_factory_reset() {
  MON.println();
  MON.println(F("--- Khoi phuc GPS ve mac dinh nha may ---"));

  // CFG-CFG: clearMask = tat ca, loadMask = tat ca -> nap lai gia tri goc
  uint8_t reset_cfg[21] = {0xB5, 0x62, 0x06, 0x09, 0x0D, 0x00,
                           0xFF, 0xFF, 0x00, 0x00,   // clearMask = xoa het
                           0x00, 0x00, 0x00, 0x00,   // saveMask  = khong luu
                           0xFF, 0xFF, 0x00, 0x00,   // loadMask  = nap mac dinh
                           0x17,                     // BBR + FLASH + EEPROM
                           0x2F, 0xAE};

  for (uint8_t i = 0; i < 5; i++) {
    GpsSerial.begin(GPS_BAUD_LIST[i]);
    delay(150);
    GpsSerial.write(reset_cfg, 21);
    MON.print(F("  Da gui lenh xoa o "));
    MON.print(GPS_BAUD_LIST[i]);
    MON.println(F(" bps"));
    delay(400);
  }

  delay(1500);
  MON.println(F("Xong. Module ve toc do goc cua chip M10 (38400), bat lai he"));
  MON.println(F("ve tinh mac dinh, phat NMEA (CHUA co NAV-PVT). Dang do lai baud..."));
  gps_baud_autodetect(true);
  gps_detect_model(false);
  MON.println(F("Bam x de cai lai cau hinh bay (115200, NAV-PVT 10Hz)."));
  delay(1500);
  print_intro();
}

// ---------------------------------------------------------------------------
// TIEN ICH UBX: gui lenh (tu tinh checksum), doc khung tra loi, cho ACK.
// Trong luc doc, cac cau NMEA van duoc phan tich de cap nhat fix.
// ---------------------------------------------------------------------------

uint8_t  ubx_buf[1200];
uint16_t ubx_len = 0;
uint8_t  ubx_id  = 0;     // id cua khung vua doc

// Co ky tu tu Serial Monitor (khong lay ra) -> nguoi dung muon dung
bool check_quit_peek() { return MON.available() > 0; }

void ubx_send(uint8_t cls, uint8_t id, const uint8_t *payload, uint16_t len) {
  uint8_t hdr[6] = { 0xB5, 0x62, cls, id, (uint8_t)(len & 0xFF), (uint8_t)(len >> 8) };
  uint8_t ca = 0, cb = 0;
  for (uint8_t i = 2; i < 6; i++) { ca += hdr[i]; cb += ca; }
  for (uint16_t i = 0; i < len; i++) { ca += payload[i]; cb += ca; }
  GpsSerial.write(hdr, 6);
  if (len) GpsSerial.write((uint8_t *)payload, len);
  GpsSerial.write(ca);
  GpsSerial.write(cb);
}

// Gom tung byte thanh cau NMEA va phan tich GGA
void nmea_feed(char c) {
  if (c == '$') { nmea_index = 0; nmea_buffer[nmea_index++] = c; }
  else if (nmea_index > 0 && nmea_index < sizeof(nmea_buffer) - 1) {
    if (c == '\r' || c == '\n') {
      nmea_buffer[nmea_index] = 0;
      if (strncmp(nmea_buffer + 3, "GGA", 3) == 0) { gps_gga_seen++; parse_nmea(nmea_buffer); }
      nmea_index = 0;
    } else nmea_buffer[nmea_index++] = c;
  }
}

// Doc den khi gap khung UBX dung class/id (id = 0xFF: bat ky id nao).
// Ket qua nam trong ubx_buf, do dai ubx_len.
bool ubx_read(uint8_t cls, uint8_t id, uint32_t timeout_ms) {
  uint8_t  st = 0, c_cls = 0, c_id = 0, ca = 0, cb = 0;
  uint16_t len = 0, pos = 0;
  uint32_t t0 = millis();
  while (millis() - t0 < timeout_ms) {
    if (check_quit_peek()) return false;
    while (GpsSerial.available()) {
      uint8_t b = GpsSerial.read();
      gps_bytes_seen++;
      switch (st) {
        case 0: if (b == 0xB5) st = 1; else nmea_feed((char)b); break;
        case 1: st = (b == 0x62) ? 2 : 0; break;
        case 2: c_cls = b; ca = b; cb = ca; st = 3; break;
        case 3: c_id = b; ca += b; cb += ca; st = 4; break;
        case 4: len = b; ca += b; cb += ca; st = 5; break;
        case 5: len |= (uint16_t)b << 8; ca += b; cb += ca; pos = 0;
                st = (len > sizeof(ubx_buf)) ? 0 : (len ? 6 : 7); break;
        case 6: ubx_buf[pos++] = b; ca += b; cb += ca; if (pos >= len) st = 7; break;
        case 7: st = (b == ca) ? 8 : 0; break;
        case 8:
          st = 0;
          if (b == cb && c_cls == 0x01 && c_id == 0x07 && len == 92) pvt_parse(ubx_buf);
          if (b == cb && c_cls == cls && (id == 0xFF || c_id == id)) {
            ubx_len = len;
            ubx_id  = c_id;
            return true;
          }
          break;
      }
    }
  }
  return false;
}

// Cho ACK cua lenh cls/id. Tra ve 1 = ACK, 0 = NAK, -1 = khong tra loi
int8_t ubx_wait_ack(uint8_t cls, uint8_t id, uint32_t timeout_ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < timeout_ms) {
    if (!ubx_read(0x05, 0xFF, timeout_ms - (millis() - t0))) return -1;
    if (ubx_len >= 2 && ubx_buf[0] == cls && ubx_buf[1] == id)
      return (ubx_id == 0x01) ? 1 : 0;
  }
  return -1;
}


// ---------------------------------------------------------------------------
// Kiem checksum cau NMEA: XOR moi ky tu giua '$' va '*', so voi 2 chu so hex
// ---------------------------------------------------------------------------
int8_t hex_val(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

bool nmea_checksum_ok(const char *s) {
  if (s[0] != '$') return false;
  uint8_t sum = 0, i = 1;
  while (s[i] && s[i] != '*') { sum ^= (uint8_t)s[i]; if (++i >= 98) return false; }
  if (s[i] != '*') return false;
  int8_t hi = hex_val(s[i + 1]), lo = hex_val(s[i + 2]);
  if (hi < 0 || lo < 0) return false;
  return sum == (uint8_t)((hi << 4) | lo);
}

/* Nghe ms mili-giay: dem goi hop le (UBX + NMEA) va so goi NAV-PVT
 * (de tinh GPS dang ra bao nhieu vi tri moi giay). */
uint16_t gps_count_sentences(uint16_t ms, uint16_t *pvt) {
  uint16_t ok = 0; *pvt = 0;
  gps_frame_reset();
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    while (GpsSerial.available()) {
      uint8_t r = gps_frame_feed(GpsSerial.read());
      if (r) ok++;
      if (r == 3) (*pvt)++;
    }
  }
  return ok;
}

// ---------------------------------------------------------------------------
// Kiem tra chip GPS co phai u-blox M10 khong (MON-VER). Goi sau khi dung baud.
// ---------------------------------------------------------------------------
void gps_detect_model(bool verbose) {
  for (uint8_t attempt = 0; attempt < 2; attempt++) {
    while (GpsSerial.available()) GpsSerial.read();
    ubx_send(0x0A, 0x04, NULL, 0);
    if (ubx_read(0x0A, 0x04, 1500) && ubx_len >= 40) {
      gps_chip = (strncmp((const char *)ubx_buf + 30, "000A0000", 8) == 0) ? 1 : 2;
      if (verbose) {
        MON.print(F("Chip GPS: "));
        MON.println(gps_chip == 1 ? F("u-blox M10 (GEP-M10) - dung") : F("KHONG PHAI M10! Bam v de xem."));
      }
      return;
    }
  }
  gps_chip = 0;
  if (verbose) {
    MON.println(F("Khong doc duoc loai chip (module khong tra loi MON-VER)."));
    MON.println(F("  -> Kiem tra day PA9 (TX cua F405) -> RX cua GPS."));
  }
}

/* ===========================================================================
   u-blox M10: CAU HINH BANG CFG-VALSET / CFG-VALGET
   Moi thiet lap la mot cap (khoa 4 byte, gia tri). Do dai gia tri nam
   trong chinh ma khoa (bit 28-30): 1 = 1 bit, 2 = 1 byte, 3 = 2 byte,
   4 = 4 byte. Lop nho: 1 = RAM (co hieu luc ngay), 2 = BBR (giu nho bang
   tu farad), 4 = FLASH (giu nho han, neu module co chip flash).
   =========================================================================*/
#define M10_UART1_BAUD   0x40520001UL
#define M10_RATE_MEAS    0x30210001UL
#define M10_RATE_NAV     0x30210002UL
#define M10_DYNMODEL     0x20110021UL
#define M10_GGA_UART1    0x209100BBUL
#define M10_RMC_UART1    0x209100ACUL
#define M10_GSA_UART1    0x209100C0UL
#define M10_GSV_UART1    0x209100C5UL
#define M10_GLL_UART1    0x209100CAUL
#define M10_VTG_UART1    0x209100B1UL
#define M10_OUTPROT_UBX  0x10740001UL   // UART1 phat UBX
#define M10_OUTPROT_NMEA 0x10740002UL   // UART1 phat NMEA
#define M10_PVT_UART1    0x20910007UL   // CFG-MSGOUT-UBX_NAV_PVT_UART1
#define M10_SIG_GPS      0x1031001FUL
#define M10_SIG_SBAS     0x10310020UL
#define M10_SIG_GAL      0x10310021UL
#define M10_SIG_BDS      0x10310022UL
#define M10_SIG_QZSS     0x10310024UL
#define M10_SIG_GLO      0x10310025UL

#define M10_RATE_HZ      10
#define M10_DYN          7        // bay tren khong, gia toc duoi 2g

uint8_t m10_val_size(uint32_t key) {
  uint8_t s = (key >> 28) & 0x07;
  return (s == 3) ? 2 : (s == 4) ? 4 : (s == 5) ? 8 : 1;
}

// Gui CFG-VALSET, tra ve 1 = ACK, 0 = NAK, -1 = khong tra loi (wait = false: khong cho)
int8_t m10_valset(uint8_t layers, const uint32_t *keys, const uint32_t *vals, uint8_t n, bool wait) {
  uint8_t  p[4 + 16 * 8];
  uint16_t len = 4;
  p[0] = 0; p[1] = layers; p[2] = 0; p[3] = 0;
  for (uint8_t k = 0; k < n && len + 8 <= sizeof(p); k++) {
    for (uint8_t i = 0; i < 4; i++) p[len++] = (uint8_t)(keys[k] >> (8 * i));
    uint8_t nb = m10_val_size(keys[k]);
    for (uint8_t i = 0; i < nb; i++) p[len++] = (uint8_t)(vals[k] >> (8 * i));
  }
  while (GpsSerial.available()) GpsSerial.read();
  ubx_send(0x06, 0x8A, p, len);
  if (!wait) return -1;
  return ubx_wait_ack(0x06, 0x8A, 2500);
}

bool m10_cfg(const __FlashStringHelper *name, uint8_t layers,
             const uint32_t *keys, const uint32_t *vals, uint8_t n) {
  MON.print(F("  ")); MON.print(name); MON.print(F(" ... "));
  int8_t r = m10_valset(layers, keys, vals, n, true);
  if      (r == 1) MON.println(F("OK (ACK)"));
  else if (r == 0) MON.println(F("BI TU CHOI (NAK)"));
  else             MON.println(F("KHONG TRA LOI"));
  return r == 1;
}

// Bo thiet lap cho bay: UBX NAV-PVT 10Hz, tat het NMEA, kieu chuyen dong "bay"
const uint32_t M10_FLIGHT_KEYS[] = {
  M10_OUTPROT_UBX, M10_OUTPROT_NMEA, M10_PVT_UART1,
  M10_GGA_UART1, M10_RMC_UART1, M10_GSA_UART1, M10_GSV_UART1, M10_GLL_UART1, M10_VTG_UART1,
  M10_RATE_MEAS, M10_RATE_NAV, M10_DYNMODEL };
const uint32_t M10_FLIGHT_VALS[] = {
  1, 0, 1,
  0, 0, 0, 0, 0, 0,
  1000 / M10_RATE_HZ, 1, M10_DYN };
#define M10_FLIGHT_N  (sizeof(M10_FLIGHT_KEYS) / sizeof(M10_FLIGHT_KEYS[0]))

// Nghe 2 giay va in GPS dang ra bao nhieu lan moi giay
void m10_report_rate() {
  uint16_t gga;
  delay(300);
  while (GpsSerial.available()) GpsSerial.read();
  uint16_t ok = gps_count_sentences(2000, &gga);
  MON.print(F("  Kiem tra: ")); MON.print(ok); MON.print(F(" goi hop le trong 2 giay, "));
  MON.print(gga / 2); MON.println(F(" goi NAV-PVT moi giay (can ~10)."));
  if (ok == 0) MON.println(F("  -> Khong nhan duoc gi o toc do moi. Chay menu l de do lai."));
}

// Menu g (M10): NAV-PVT 10Hz, tat NMEA, giu nguyen baud, KHONG luu
void m10_configure_basic() {
  MON.println();
  MON.println(F("--- Cau hinh CO BAN cho M10 (giu nguyen baud, KHONG luu) ---"));
  MON.print(F("Cong: ")); MON.print(gps_baudrate); MON.println(F(" bps"));
  m10_cfg(F("NAV-PVT 10Hz, tat NMEA, kieu bay"), 0x01, M10_FLIGHT_KEYS, M10_FLIGHT_VALS, M10_FLIGHT_N);
  m10_report_rate();
  MON.println(F("Xong. Cau hinh nay mat khi cup nguon. Xem bang menu h. Muon giu: menu x."));
  delay(2000);
  print_intro();
}

// Menu x / m (M10): cau hinh cho bay + doi baud + LUU
void m10_configure_full(uint32_t new_baud) {
  MON.println();
  MON.println(F("--- CAU HINH CHO BAY (u-blox M10): NAV-PVT 10Hz, tat NMEA, LUU ---"));
  MON.print(F("Cong hien tai: ")); MON.print(gps_baudrate);
  MON.print(F(" bps  ->  sau khi luu: ")); MON.print(new_baud); MON.println(F(" bps"));
  MON.println(F("He ve tinh giu nguyen mac dinh M10: GPS+Galileo+BeiDou+QZSS+SBAS."));
  MON.println();

  uint32_t K[M10_FLIGHT_N + 1], V[M10_FLIGHT_N + 1];
  for (uint8_t i = 0; i < M10_FLIGHT_N; i++) { K[i] = M10_FLIGHT_KEYS[i]; V[i] = M10_FLIGHT_VALS[i]; }
  K[M10_FLIGHT_N] = M10_UART1_BAUD; V[M10_FLIGHT_N] = new_baud;
  uint8_t n = M10_FLIGHT_N + 1;

  /* 1. Ghi vao bo nho LUU truoc (BBR + flash). Chua doi gi dang chay nen
   *    cau tra loi ve on dinh o toc do hien tai. */
  bool flash = m10_cfg(F("Luu vao BBR + flash"), 0x06, K, V, n);
  bool bbr   = flash;
  if (!flash) bbr = m10_cfg(F("Luu vao BBR (module khong co flash)"), 0x02, K, V, n);

  /* 2. Ap dung ngay vao RAM. Baud doi ngay lap tuc nen cau tra loi co
   *    the bi lac - khong cho. */
  MON.print(F("  Ap dung ngay, doi cong sang ")); MON.print(new_baud); MON.println(F(" ..."));
  m10_valset(0x01, K, V, n, false);
  delay(150);
  GpsSerial.begin(new_baud);
  gps_baudrate = new_baud;
  m10_report_rate();

  MON.println();
  if (flash)
    MON.println(F("XONG. Da luu vao flash: rut dien cam lai van giu."));
  else if (bbr)
    MON.println(F("XONG. Chi luu duoc vao BBR: giu khi tu farad con dien (vai gio)."));
  else
    MON.println(F("Khong xac nhan duoc lenh luu. Cau hinh chi co hieu luc den khi rut dien."));
  MON.println(F("Firmware bay tu gui lai cau hinh moi lan khoi dong, nen du co mat"));
  MON.println(F("cung khong sao. Trong Config.h muc [11] can:"));
  MON.print  (F("    #define GPS_BAUD    ")); MON.println(new_baud);
  delay(2500);
  print_intro();
}

// Menu u (M10): doc cau hinh dang chay bang CFG-VALGET va in ra
void m10_show_signals() {
  MON.println();
  MON.println(F("--- Cau hinh dang chay cua M10 (doc bang CFG-VALGET) ---"));
  const uint32_t keys[] = { M10_SIG_GPS, M10_SIG_GAL, M10_SIG_BDS, M10_SIG_QZSS, M10_SIG_SBAS,
                            M10_SIG_GLO, M10_RATE_MEAS, M10_UART1_BAUD, M10_DYNMODEL,
                            M10_GSV_UART1 };
  uint8_t p[4 + sizeof(keys)];
  uint16_t len = 4;
  p[0] = 0; p[1] = 0; p[2] = 0; p[3] = 0;          // phien ban 0, lop RAM, vi tri 0
  for (uint8_t k = 0; k < sizeof(keys) / 4; k++)
    for (uint8_t i = 0; i < 4; i++) p[len++] = (uint8_t)(keys[k] >> (8 * i));

  bool got = false;
  for (uint8_t attempt = 0; attempt < 3 && !got; attempt++) {
    while (GpsSerial.available()) GpsSerial.read();
    ubx_send(0x06, 0x8B, p, len);
    got = ubx_read(0x06, 0x8B, 2000) && ubx_len >= 4;
  }
  if (!got) {
    MON.println(F("Module khong tra loi. Chay menu l va v truoc."));
    delay(2000); print_intro(); return;
  }

  uint16_t off = 4;
  while (off + 4 <= ubx_len) {
    uint32_t key = (uint32_t)ubx_buf[off] | ((uint32_t)ubx_buf[off + 1] << 8) |
                   ((uint32_t)ubx_buf[off + 2] << 16) | ((uint32_t)ubx_buf[off + 3] << 24);
    off += 4;
    uint8_t nb = m10_val_size(key);
    if (off + nb > ubx_len) break;
    uint32_t v = 0;
    for (uint8_t i = 0; i < nb && i < 4; i++) v |= (uint32_t)ubx_buf[off + i] << (8 * i);
    off += nb;

    MON.print(F("  "));
    switch (key) {
      case M10_SIG_GPS:    MON.print(F("GPS           : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_SIG_GAL:    MON.print(F("Galileo       : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_SIG_BDS:    MON.print(F("BeiDou        : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_SIG_QZSS:   MON.print(F("QZSS          : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_SIG_SBAS:   MON.print(F("SBAS          : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_SIG_GLO:    MON.print(F("GLONASS       : ")); MON.println(v ? F("BAT") : F("tat")); break;
      case M10_RATE_MEAS:  MON.print(F("Chu ky do     : ")); MON.print(v); MON.print(F(" ms = "));
                           MON.print(v ? 1000 / v : 0); MON.println(F(" lan/giay")); break;
      case M10_UART1_BAUD: MON.print(F("Toc do cong   : ")); MON.print(v); MON.println(F(" bps")); break;
      case M10_DYNMODEL:   MON.print(F("Kieu chuyen dong: ")); MON.print(v);
                           MON.println(v == 7 ? F(" (bay, <2g)") : v == 0 ? F(" (cam tay, mac dinh)") : F("")); break;
      case M10_GSV_UART1:  MON.print(F("Cau GSV       : ")); MON.println(v ? F("dang phat (ton bang thong)") : F("tat")); break;
      default: break;
    }
  }
  MON.println();
  MON.println(F("M10 mac dinh da thu GPS+Galileo+BeiDou+QZSS+SBAS, khong can doi."));
  MON.println(F("So ve tinh tung he: menu o (ngoai troi)."));
  delay(2500);
  print_intro();
}

// ---------------------------------------------------------------------------
// MENU v - Doc phien ban firmware (MON-VER).
// Dong "GNSS=..." cho biet module ho tro nhung he ve tinh nao.
// ---------------------------------------------------------------------------
void gps_show_version() {
  MON.println();
  MON.println(F("--- Phien ban module GPS (MON-VER) ---"));
  while (GpsSerial.available()) GpsSerial.read();
  ubx_send(0x0A, 0x04, NULL, 0);
  if (!ubx_read(0x0A, 0x04, 2500) || ubx_len < 40) {
    MON.println(F("Khong tra loi. Chay menu l (sai baud?) roi thu lai."));
    MON.println(F("Neu van khong tra loi: chan TX cua F405 (PA9) chua toi RX cua GPS,"));
    MON.println(F("hoac module khong phai u-blox that."));
    delay(1500);
    print_intro();
    return;
  }
  char s[31];
  memcpy(s, ubx_buf, 30); s[30] = 0;
  MON.print(F("  Phan mem: ")); MON.println(s);
  memcpy(s, ubx_buf + 30, 10); s[10] = 0;
  MON.print(F("  Phan cung: ")); MON.println(s);

  bool has_bds = false, has_gal = false;
  for (uint16_t off = 40; off + 30 <= ubx_len; off += 30) {
    memcpy(s, ubx_buf + off, 30); s[30] = 0;
    MON.print(F("  ")); MON.println(s);
    if (strstr(s, "BDS")) has_bds = true;
    if (strstr(s, "GAL")) has_gal = true;
  }
  MON.println();
  MON.print(F("  BeiDou : ")); MON.println(has_bds ? F("CO ho tro") : F("khong thay trong danh sach"));
  MON.print(F("  Galileo: ")); MON.println(has_gal ? F("CO ho tro") : F("khong thay trong danh sach"));
  gps_chip = (strncmp((const char *)ubx_buf + 30, "000A0000", 8) == 0) ? 1 : 2;
  MON.print(F("  ==> Chip: "));
  if (gps_chip == 1) {
    MON.println(F("u-blox M10. Dung menu x de luu cau hinh cho bay."));
    MON.println(F("      M10 thu GPS+Galileo+BeiDou+QZSS+SBAS san, khong can doi."));
  } else {
    MON.println(F("KHONG PHAI u-blox M10 (phan cung khac 000A0000)."));
    MON.println(F("      Sketch nay chi cau hinh duoc M10. Kiem tra lai module."));
  }
  delay(2000);
  print_intro();
}

// ---------------------------------------------------------------------------
// MENU o - KHAO SAT VE TINH THEO TUNG HE
// Hoi truc tiep module bang UBX NAV-SAT,
// nen thay chinh xac: moi he bao nhieu ve tinh, bao nhieu du manh, bao
// nhieu DANG DUNG de tinh vi tri. Khong phu thuoc cau GSV.
// ---------------------------------------------------------------------------
enum { SYS_GPS, SYS_SBAS, SYS_GAL, SYS_BDS, SYS_QZSS, SYS_GLO, SYS_N };
const char *SYS_NAME[SYS_N] = { "GPS    ", "SBAS   ", "Galileo", "BeiDou ", "QZSS   ", "GLONASS" };

void gps_satellite_survey() {
  MON.println();
  MON.println(F("--- KHAO SAT VE TINH THEO TUNG HE (gui q de thoat) ---"));
  MON.println(F("PHAI RA NGOAI TROI, nhin thay nhieu bau troi. Lan dau cho 1-3 phut."));
  MON.println(F("Nhin:  so ve tinh module thay"));
  MON.println(F("Manh:  CNO >= 30 dB-Hz (tin hieu tot)"));
  MON.println(F("Dung:  dang duoc dung de tinh vi tri"));
  MON.println();

  delay(1000);

  uint32_t t_start = millis();
  gps_bytes_seen = 0;

  while (true) {
    if (check_quit()) break;

    // Hoi module
    while (GpsSerial.available()) gps_frame_feed(GpsSerial.read());
    ubx_send(0x01, 0x35, NULL, 0);                 // UBX-NAV-SAT
    bool got = ubx_read(0x01, 0x35, 2500);

    if (!got) {
      if (gps_bytes_seen == 0)
        MON.println(F("Khong nhan duoc byte nao! Sai baud hoac day. Chay menu l."));
      else
        MON.println(F("Module khong tra loi lenh UBX. Kiem tra day PA9 -> RX cua GPS."));
      continue;
    }

    uint8_t seen[SYS_N] = {0}, strong[SYS_N] = {0}, used[SYS_N] = {0};
    uint8_t maxcno = 0;

    uint8_t n = ubx_buf[5];      // so ve tinh trong ban tin NAV-SAT
    for (uint8_t i = 0; i < n && 8 + (i + 1) * 12 <= ubx_len; i++) {
      uint8_t *r = ubx_buf + 8 + i * 12;
      uint8_t g = r[0], cno = r[2];
      int8_t  s = -1;
      if      (g == 0) s = SYS_GPS;   else if (g == 1) s = SYS_SBAS;
      else if (g == 2) s = SYS_GAL;   else if (g == 3) s = SYS_BDS;
      else if (g == 5) s = SYS_QZSS;  else if (g == 6) s = SYS_GLO;
      if (s < 0 || cno == 0) continue;
      seen[s]++;
      if (cno >= 30) strong[s]++;
      if (r[8] & 0x08) used[s]++;
      if (cno > maxcno) maxcno = cno;
    }

    uint16_t t_seen = 0, t_strong = 0, t_used = 0;
    MON.print(F("[")); MON.print((millis() - t_start) / 1000); MON.println(F("s]"));
    for (uint8_t s = 0; s < SYS_N; s++) {
      t_seen += seen[s]; t_strong += strong[s]; t_used += used[s];
      MON.print(F("  ")); MON.print(SYS_NAME[s]);
      MON.print(F("  nhin ")); if (seen[s] < 10) MON.print(' '); MON.print(seen[s]);
      MON.print(F("  manh ")); if (strong[s] < 10) MON.print(' '); MON.print(strong[s]);
      MON.print(F("  dung ")); if (used[s] < 10) MON.print(' '); MON.print(used[s]);
      MON.print(F("  "));
      for (uint8_t k = 0; k < used[s] && k < 20; k++) MON.print('#');
      MON.println();
    }
    MON.print(F("  TONG     nhin ")); MON.print(t_seen);
    MON.print(F("  manh ")); MON.print(t_strong);
    MON.print(F("  dung ")); MON.print(t_used);
    MON.print(F("   CNO max ")); MON.print(maxcno);
    MON.print(F("   Fix ")); MON.print(pvt_ok ? pvt_fix : 0);
    MON.print(F("  pDOP ")); MON.print(pvt_pdop, 1);
    MON.print(F("  hAcc ")); MON.print(pvt_hacc, 2); MON.println('m');

    if (t_seen == 0)
      MON.println(F("  -> Chua thay ve tinh. Anten bi che / trong nha / anten hong."));
    else if (maxcno < 25)
      MON.println(F("  -> Tin hieu qua yeu. Ra cho trong, xa mai ton, xa USB 3.0 / laptop."));
    else if (t_used < 5)
      MON.println(F("  -> Dang bat song, cho them."));
    else if (t_used < 12)
      MON.println(F("  -> Da dinh vi. Cho them de so ve tinh dung tang len."));
    else
      MON.println(F("  -> RAT TOT."));
    MON.println();

    // Nghi ~1.5s, van doc NMEA
    uint32_t w = millis();
    while (millis() - w < 1500) {
      while (GpsSerial.available()) gps_frame_feed(GpsSerial.read());
      if (MON.available()) break;
    }
  }

  print_intro();
}

bool nmea_field(const char *sentence, uint8_t index, char *out, uint8_t out_size) {
  uint8_t field = 0, j = 0;
  for (uint8_t i = 0; sentence[i]; i++) {
    if (sentence[i] == ',') {
      if (field == index) { out[j] = 0; return j > 0; }
      field++; j = 0;
      continue;
    }
    if (field == index && j < out_size - 1) out[j++] = sentence[i];
  }
  if (field == index) { out[j] = 0; return j > 0; }
  return false;
}

// Chuyen dinh dang NMEA ddmm.mmmm sang do thap phan
double nmea_to_degrees(const char *value, const char *hemisphere) {
  if (value[0] == 0) return 0;
  double raw = atof(value);
  int    deg = (int)(raw / 100);
  double min = raw - (deg * 100);
  double result = deg + min / 60.0;
  if (hemisphere[0] == 'S' || hemisphere[0] == 'W') result = -result;
  return result;
}

// Cap nhat bo loc EMA moi khi co du lieu GGA moi (goi sau parse_nmea).
// Bo qua khi chua co fix, de tranh keo bo loc ve 0.0/0.0 luc GPS chua bat duoc gi.
void gps_update_filter() {
  if (gps_fix_type == 0) return;

  if (!gps_filter_ready) {
    // lan dau co fix: nap thang gia tri tho, khong lam muot buoc nhay dau tien
    gps_lat_filt = gps_latitude;
    gps_lon_filt = gps_longitude;
    gps_alt_filt = gps_altitude;
    gps_filter_ready = true;
    return;
  }

  gps_lat_filt += GPS_FILTER_ALPHA * (gps_latitude  - gps_lat_filt);
  gps_lon_filt += GPS_FILTER_ALPHA * (gps_longitude - gps_lon_filt);
  gps_alt_filt += GPS_FILTER_ALPHA * (gps_altitude  - gps_alt_filt);
}

void parse_nmea(const char *sentence) {
  char field[16], hemi[4];

  // GGA: chat luong fix, so ve tinh, HDOP, do cao
  // Chi tim chuoi "GGA" nen nhan duoc ca $GPGGA lan $GNGGA (nhieu he
  // ve tinh - M10 phat loai nay).
  if (strstr(sentence, "GGA") != NULL) {
    if (nmea_field(sentence, 2, field, sizeof(field)) &&
        nmea_field(sentence, 3, hemi,  sizeof(hemi)))
      gps_latitude = nmea_to_degrees(field, hemi);

    if (nmea_field(sentence, 4, field, sizeof(field)) &&
        nmea_field(sentence, 5, hemi,  sizeof(hemi)))
      gps_longitude = nmea_to_degrees(field, hemi);

    if (nmea_field(sentence, 6, field, sizeof(field))) gps_fix_type   = atoi(field);
    else gps_fix_type = 0;
    if (nmea_field(sentence, 7, field, sizeof(field))) gps_satellites = atoi(field);
    if (nmea_field(sentence, 8, field, sizeof(field))) gps_hdop       = atof(field);
    if (nmea_field(sentence, 9, field, sizeof(field))) gps_altitude   = atof(field);
  }
}

/* =====================================================================
 *  MENU h: DOC UBX-NAV-PVT GIONG HET FIRMWARE BAY FC_F405_M10_PVT
 *  Neu module chua phat NAV-PVT (moi reset), gui cau hinh vao RAM.
 * ===================================================================== */
void gps_pvt_stream() {
  MON.println();
  MON.println(F("--- UBX NAV-PVT (giong code bay) - gui q de thoat ---"));
  uint16_t pv;
  while (GpsSerial.available()) GpsSerial.read();
  gps_count_sentences(1200, &pv);
  if (pv == 0) {
    MON.println(F("Module chua phat NAV-PVT -> bat tam (chi RAM). Bam x de luu han."));
    m10_cfg(F("NAV-PVT 10Hz, tat NMEA"), 0x01, M10_FLIGHT_KEYS, M10_FLIGHT_VALS, M10_FLIGHT_N);
  }
  MON.println(F("Dat drone DUNG YEN ngoai troi. 'Troi' = khoang cach toi diem fix tot dau tien."));
  MON.println(F("Bay? = OK khi fix 3D, >= 8 ve tinh, hAcc < 2.5m (dieu kien cua code bay)."));
  MON.println(F("Fix Sat  hAcc(m) pDOP   Lat          Lon           AltMSL  vN(cm/s) vE(cm/s)  Troi(m)  Bay?"));

  uint32_t last = 0, c0 = pvt_count, t0 = millis(), last_rx = millis();
  double lat0 = 0, lon0 = 0; bool have0 = false; float maxDrift = 0;
  gps_frame_reset();
  while (GpsSerial.available()) GpsSerial.read();

  while (true) {
    if (check_quit()) break;
    while (GpsSerial.available()) {
      if (gps_frame_feed(GpsSerial.read()) != 3) continue;
      last_rx = millis();
      if (millis() - last < 500) continue;          // in 2 lan / giay
      last = millis();

      bool healthy = pvt_healthy();
      float drift = 0;
      if (healthy) {
        if (!have0) { lat0 = pvt_lat; lon0 = pvt_lon; have0 = true; }
        float dn = (pvt_lat - lat0) * 111320.0;
        float de = (pvt_lon - lon0) * 111320.0 * cos(lat0 * 0.0174533);
        drift = sqrt(dn * dn + de * de);
        if (drift > maxDrift) maxDrift = drift;
      }
      MON.print(pvt_ok ? (pvt_fix == 4 ? F("3D+ ") : F("3D  ")) : (pvt_fix == 2 ? F("2D  ") : F("--  ")));
      if (pvt_sats < 10) MON.print(' ');
      MON.print(pvt_sats); MON.print(F("   "));
      MON.print(pvt_hacc, 2); MON.print(F("    "));
      MON.print(pvt_pdop, 2); MON.print(F("  "));
      MON.print(pvt_lat, 7); MON.print(F("  "));
      MON.print(pvt_lon, 7); MON.print(F("  "));
      MON.print(pvt_alt, 1); MON.print(F("    "));
      MON.print(pvt_vn, 1); MON.print(F("    "));
      MON.print(pvt_ve, 1); MON.print(F("    "));
      MON.print(drift, 2); MON.print(F("    "));
      MON.println(healthy ? F("OK") : (!pvt_ok ? F("chua fix") : pvt_sats < PVT_MIN_SATS ? F("it ve tinh") : F("hAcc lon")));
    }
    if (millis() - last_rx > 3000) {
      MON.println(F("Khong nhan duoc NAV-PVT 3 giay. Bam g hoac x, kiem tra baud (l) / day TX-RX."));
      last_rx = millis();
    }
  }

  float sec = (millis() - t0) / 1000.0f;
  MON.println();
  MON.print(F("Tan so NAV-PVT: ")); MON.print((pvt_count - c0) / (sec > 0 ? sec : 1), 1); MON.println(F(" Hz (can ~10)"));
  MON.print(F("Troi lon nhat khi dung yen: ")); MON.print(maxDrift, 2);
  MON.println(maxDrift < 1.5f ? F(" m -> tot") : maxDrift < 3.0f ? F(" m -> tam duoc, doi them vai phut") : F(" m -> qua lon, cho GPS on dinh / tranh vat can"));
  delay(1500);
  print_intro();
}
