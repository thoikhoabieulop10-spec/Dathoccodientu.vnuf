/*
  ============================================================================
  F405_drone_test.ino
  ----------------------------------------------------------------------------
  Chuong trinh TEST TOAN BO DRONE cho mach FC_F405 (STM32F405, STM32duino).
  Kiem tra tung bo phan bang menu phim, giong code test la ban / GPS:

    IMU ICM-20602, baro BMP388, la ban IST8310, GPS GEP-M10,
    may thu ELRS (CRSF), 3 den LED, 4 ESC + motor.

  Serial Monitor: 115200 baud, "New Line". Gui 1 ky tu de chon menu.
  Dang chay mot bai test: gui PHIM BAT KY de dung.

  !!! AN TOAN DONG CO !!!
    - THAO HET CANH QUAT truoc khi test motor (tru khi bai test hoi rieng
      va drone da duoc BUOC CHAT xuong dat).
    - Motor CHI quay khi: may thu co song + cong tac ARM (CH5) BAT +
      can ga o DUOI CUNG luc bat dau. Tat cong tac ARM, mat song, hoac
      bam phim bat ky -> motor DUNG NGAY.
    - Muon test motor khi khong co may thu: dat MOTOR_NEED_RADIO 0
      (KHONG khuyen khich).

  THU TU TEST GOI Y
    s  -> kiem tra nhanh tat ca (bang DAT / LOI)
    i, p -> IMU;   b, h -> baro;   c, n -> la ban
    r  -> may thu;  g -> GPS;  l -> den
    THAO CANH:  1 2 3 4 (vi tri + chieu quay tung motor),
                v (do rung),  x (anh huong motor len la ban)

  Cac so trong muc 1 CHEP TU Config.h cua code bay. Doi Config.h thi
  chep lai sang day cho khop.
  ============================================================================
*/

#include <SPI.h>
#include <Wire.h>
#include <HardwareTimer.h>
#include <math.h>

/* ===========================================================================
   1. CAU HINH (giong Config.h cua code bay)
   =========================================================================*/

// ---- Chan cam ----
#define PIN_CS          PA4       // chip select ICM-20602 (SPI1)
#define BMP_CS          PA3       // chip select BMP388   (SPI1)
#define M1_PIN          PC6       // ESC 1..4 (TIM3 CH1..CH4)
#define M2_PIN          PC7
#define M3_PIN          PC8
#define M4_PIN          PC9
#define LED_GREEN       PB3
#define LED_RED         PB4
#define LED_GPS         PB5
#define CRSF_PIN_RX     PA1       // ELRS TX -> PA1
#define CRSF_PIN_TX     PA0       // ELRS RX -> PA0
#define PIN_GPS_RX      PA10      // GPS TX  -> PA10
#define PIN_GPS_TX      PA9       // GPS RX  -> PA9
#define PIN_MAG_SCL     PB6
#define PIN_MAG_SDA     PB7

// ---- May thu ----
#define CRSF_BAUD       420000
#define ARM_CHANNEL     4         // CH5 (dem tu 0)
#define ARM_THRESHOLD   1500
#define MODE_CHANNEL    6         // CH7
#define MODE_THR_ALT    1250
#define MODE_THR_POS    1750
#define THR_LOW_MAX     1050      // ga phai duoi muc nay moi cho bat motor

// ---- GPS ----
#define GPS_BAUD        115200

// ---- ESC ----
#define ESC_PERIOD_US   4000      // 250Hz, giong code bay
#define MOTOR_TEST_US   1150      // muc ga khi quay tung motor
#define MOTOR_FOLLOW_MAX 1700     // menu m: ga toi da cho phep (THAO CANH)
#define MOTOR_NEED_RADIO 1        // 1 = bat buoc co song + cong tac ARM

// ---- IMU (Config.h muc [5]) ----
// Truc IMU: X = MUI, Y = TRAI, Z = LEN. Lay tu truc chip nao (0/1/2), dau +-1.
// Module cu: 0 +1 / 1 +1 / 2 +1. Doi module -> menu y.
#define IMU_X_AXIS      0
#define IMU_X_SIGN      (+1)
#define IMU_Y_AXIS      1
#define IMU_Y_SIGN      (+1)
#define IMU_Z_AXIS      2
#define IMU_Z_SIGN      (+1)
#define ACC_OFFSET_X   (0.0209)
#define ACC_OFFSET_Y   (0.0015)
#define ACC_OFFSET_Z   (-0.0090)

// ---- La ban (Config.h muc [9], calib lai 30/09/2026 sau khi roi) ----
#define MAG_OFFSET_X    19.7f
#define MAG_OFFSET_Y    -27.3f
#define MAG_OFFSET_Z    15.8f
/* Lan calib 30/09 ra mo hinh CHEO (MAG_SCALE_X/Y/Z) -> dat len duong
 * cheo cua ma tran, cac so hang ngoai = 0.                             */
#define MAG_SOFT_R0   {  0.99323f, -0.00120f,  0.01351f }
#define MAG_SOFT_R1   { -0.00120f,  1.01046f,  0.02522f }
#define MAG_SOFT_R2   {  0.01351f,  0.02522f,  0.99720f }
#define MAG_FIELD_NOMINAL   150.5f    // |M| tu menu d/j khung moi (16/10)
#define MAG_FWD         ( mx)
#define MAG_RIGHT       ( my)
#define MAG_DOWN        (-mz)
#define MAG_DECLINATION     (-1.74f)
#define MAG_HEADING_OFFSET  0.0f
#define MAG_ROLL_SIGN       (+1)
#define MAG_PITCH_SIGN      (-1)      // 01/10: do bang menu n (+1 lech 19.7 do, -1 lech 2.6 do)

#define IST_UT_PER_LSB  0.3f
#define MON             Serial
#define MON_BAUD        115200

/* ===========================================================================
   2. THANH GHI CHIP (khong can doi)
   =========================================================================*/
#define REG_SMPLRT_DIV     0x19
#define REG_CONFIG         0x1A
#define REG_GYRO_CONFIG    0x1B
#define REG_ACCEL_CONFIG   0x1C
#define REG_ACCEL_CONFIG_2 0x1D
#define REG_ACCEL_XOUT_H   0x3B
#define REG_SIGPATH_RESET  0x68
#define REG_USER_CTRL      0x6A
#define REG_PWR_MGMT_1     0x6B
#define REG_PWR_MGMT_2     0x6C
#define REG_WHO_AM_I       0x75
#define ICM_WHOAMI         0x12

#define BMP_CHIP_ID   0x00
#define BMP_DATA_0    0x04
#define BMP_PWR_CTRL  0x1B
#define BMP_OSR       0x1C
#define BMP_ODR       0x1D
#define BMP_CONFIG    0x1F
#define BMP_CAL_DATA  0x31
#define BMP_CMD       0x7E
#define BMP388_ID     0x50

static SPISettings SPI_SLOW(1000000, MSBFIRST, SPI_MODE3);
static SPISettings SPI_FAST(8000000, MSBFIRST, SPI_MODE3);
static SPISettings BMP_SPI (8000000, MSBFIRST, SPI_MODE0);

HardwareSerial CrsfSerial(CRSF_PIN_RX, CRSF_PIN_TX);
HardwareSerial GpsSerial(PIN_GPS_RX, PIN_GPS_TX);
TwoWire        MagWire(PIN_MAG_SDA, PIN_MAG_SCL);
HardwareTimer *MotorTimer;

/* ===========================================================================
   3. BIEN TOAN CUC
   =========================================================================*/

// IMU
bool    imu_ok = false;
int16_t imu_chip[7];                // so tho theo truc CHIP: ax ay az temp gx gy gz
int16_t imu_raw[7];                 // da doi sang truc DRONE (X mui, Y trai, Z len)
uint8_t imu_map[3] = { IMU_X_AXIS, IMU_Y_AXIS, IMU_Z_AXIS };
int8_t  imu_sgn[3] = { IMU_X_SIGN, IMU_Y_SIGN, IMU_Z_SIGN };
float   acc_x, acc_y, acc_z;        // g, da cong ACC_OFFSET
float   gyr_r, gyr_p, gyr_y;        // do/giay (chua tru lech)
float   gyro_bias[3] = {0, 0, 0};
float   angle_roll, angle_pitch;    // do, tinh tu gia toc ke (giong code bay)

// Baro
bool  baro_ok = false;
struct { float t1,t2,t3,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11; } bcal;
float t_lin_b = 0, baro_press = 0, baro_alt = 0;

// La ban
uint8_t mag_addr = 0;
int16_t mag_raw[3];
static const float MagSoft[3][3] = { MAG_SOFT_R0, MAG_SOFT_R1, MAG_SOFT_R2 };

// CRSF
#define RX_CH 16
float    rc[RX_CH];
uint8_t  crsf_buf[64];
uint8_t  crsf_idx = 0, crsf_len = 0;
uint32_t crsf_last_rc_ms = 0, crsf_rc_frames = 0, crsf_crc_err = 0, crsf_bytes = 0;
uint8_t  link_rssi1 = 0, link_rssi2 = 0, link_lq = 0, link_rfmode = 0;
int8_t   link_snr = 0;
bool     link_seen = false;

// GPS
char     gps_line[100];
uint8_t  gps_li = 0;
uint32_t gps_bytes = 0, gps_valid = 0, gps_nmea_seen = 0;
uint8_t  gps_fix = 0, gps_sats = 0;
float    gps_hdop = 99, gps_alt = 0, gps_hacc = 99, gps_vn = 0, gps_ve = 0;  // hdop = pDOP
double   gps_lat = 0, gps_lon = 0;
uint32_t gps_last_gga_ms = 0;            // lan cuoi nhan NAV-PVT
uint8_t  gps_ust = 0, gps_ucls, gps_uid, gps_ua, gps_ub, gps_uarx;
uint16_t gps_ulen, gps_uidx;
uint8_t  gps_upl[100];

// Motor
uint16_t motor_us[4] = {1000, 1000, 1000, 1000};
const char *MOTOR_POS[4] = { "TRUOC - PHAI", "SAU - PHAI", "SAU - TRAI", "TRUOC - TRAI" };
const char *MOTOR_DIR[4] = { "NGUOC chieu kim dong ho", "THUAN chieu kim dong ho",
                             "NGUOC chieu kim dong ho", "THUAN chieu kim dong ho" };

char data = 0;

// Kieu du lieu dung chung (dat o dau file de Arduino IDE sinh khai bao ham dung)
struct MagPose { float m[3]; float roll, pitch; };               // menu n
struct Vibe    { float g[3]; float a; float peak_hz; float peak_amp; };   // menu v

/* ===========================================================================
   4. TIEN ICH CHUNG
   =========================================================================*/

void crsf_poll();
void gps_poll();
void print_intro();

// Phuc vu nen: doc may thu + GPS. Goi thuong xuyen trong moi vong cho.
void service() {
  crsf_poll();
  gps_poll();
}

// Co phim tu Serial Monitor? Lay het ra, tra ve true.
bool key_pressed() {
  if (MON.available() > 0) {
    delay(30);
    while (MON.available() > 0) MON.read();
    return true;
  }
  return false;
}

// Cho ms mili-giay, van phuc vu nen. Tra ve false neu co phim (muon dung).
bool wait_ms(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    service();
    if (key_pressed()) return false;
  }
  return true;
}

// Cho mot phim, tra ve ky tu (chu thuong)
char wait_key() {
  while (MON.available()) MON.read();
  while (!MON.available()) service();
  char c = MON.read();
  delay(30);
  while (MON.available()) MON.read();
  if (c >= 'A' && c <= 'Z') c += 32;
  return c;
}

void print_ok(bool ok) { MON.println(ok ? F("DAT") : F("LOI")); }

float stddev(float sum, float sum2, uint32_t n) {
  if (n < 2) return 0;
  float m = sum / n;
  float v = sum2 / n - m * m;
  return v > 0 ? sqrtf(v) : 0;
}

/* ===========================================================================
   5. IMU ICM-20602 (SPI) - giong IMU.ino cua code bay
   =========================================================================*/

static void icm_write(uint8_t reg, uint8_t val) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg & 0x7F); SPI.transfer(val);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  delayMicroseconds(20);
}
static uint8_t icm_read(uint8_t reg) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  uint8_t v = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  return v;
}
static void icm_burst(uint8_t reg, uint8_t *buf, uint8_t len) {
  SPI.beginTransaction(SPI_FAST);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  for (uint8_t i = 0; i < len; i++) buf[i] = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
}

// Bo loc giong HET code bay: con quay 10Hz, gia toc 10Hz
void imu_config_flight() {
  icm_write(REG_SMPLRT_DIV, 0x00);
  icm_write(REG_CONFIG, 0x05);
  icm_write(REG_GYRO_CONFIG, 0x08);        // +-500 do/s  -> 65.5 LSB/(do/s)
  icm_write(REG_ACCEL_CONFIG, 0x10);       // +-8g        -> 4096 LSB/g
  icm_write(REG_ACCEL_CONFIG_2, 0x05);
  delay(20);
}

// Bo loc RONG de thay rung that: con quay 176Hz, gia toc 218Hz, 1kHz
void imu_config_wide() {
  icm_write(REG_SMPLRT_DIV, 0x00);
  icm_write(REG_CONFIG, 0x01);
  icm_write(REG_ACCEL_CONFIG_2, 0x01);
  delay(20);
}

bool imu_init() {
  pinMode(PIN_CS, OUTPUT); digitalWrite(PIN_CS, HIGH);
  icm_write(REG_PWR_MGMT_1, 0x80); delay(100);
  icm_write(REG_SIGPATH_RESET, 0x03); delay(100);
  icm_write(REG_USER_CTRL, 0x10);           // tat I2C, chi SPI
  icm_write(REG_PWR_MGMT_1, 0x01);
  icm_write(REG_PWR_MGMT_2, 0x00); delay(20);
  if (icm_read(REG_WHO_AM_I) != ICM_WHOAMI) return false;
  imu_config_flight();
  return true;
}

void imu_read() {
  uint8_t b[14];
  icm_burst(REG_ACCEL_XOUT_H, b, 14);
  for (uint8_t i = 0; i < 7; i++) imu_chip[i] = (int16_t)((b[2 * i] << 8) | b[2 * i + 1]);
  for (uint8_t k = 0; k < 3; k++) {
    int32_t a = imu_sgn[k] * (int32_t)imu_chip[imu_map[k]];
    int32_t g = imu_sgn[k] * (int32_t)imu_chip[4 + imu_map[k]];
    imu_raw[k]     = (int16_t)constrain(a, -32767, 32767);
    imu_raw[4 + k] = (int16_t)constrain(g, -32767, 32767);
  }
  imu_raw[3] = imu_chip[3];
  acc_x = imu_raw[0] / 4096.0f + ACC_OFFSET_X;
  acc_y = imu_raw[1] / 4096.0f + ACC_OFFSET_Y;
  acc_z = imu_raw[2] / 4096.0f + ACC_OFFSET_Z;
  gyr_r = imu_raw[4] / 65.5f;
  gyr_p = imu_raw[5] / 65.5f;
  gyr_y = imu_raw[6] / 65.5f;
  angle_roll  =  atanf(acc_y / sqrtf(acc_x * acc_x + acc_z * acc_z)) * 57.2958f;
  angle_pitch = -atanf(acc_x / sqrtf(acc_y * acc_y + acc_z * acc_z)) * 57.2958f;
}

float imu_temp_c() { return imu_raw[3] / 326.8f + 25.0f; }

// Trung binh goc nghieng trong ms mili-giay (de yen)
void imu_avg_angles(uint16_t ms, float *roll, float *pitch) {
  float sr = 0, sp = 0; uint16_t n = 0;
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    imu_read(); sr += angle_roll; sp += angle_pitch; n++;
    service(); delay(2);
  }
  *roll = n ? sr / n : 0; *pitch = n ? sp / n : 0;
}

void imu_measure_bias(uint16_t n) {
  float s[3] = {0, 0, 0};
  for (uint16_t i = 0; i < n; i++) {
    imu_read(); s[0] += gyr_r; s[1] += gyr_p; s[2] += gyr_y;
    service(); delay(2);
  }
  for (uint8_t k = 0; k < 3; k++) gyro_bias[k] = s[k] / n;
}

bool need_imu() {
  if (imu_ok) return true;
  MON.println(F("IMU khong tra loi (WHO_AM_I sai). Kiem tra SPI / chan PA4."));
  return false;
}

/* ===========================================================================
   6. BARO BMP388 (SPI) - giong Baro.ino cua code bay
   =========================================================================*/

static void bmp_write(uint8_t r, uint8_t v) {
  SPI.beginTransaction(BMP_SPI); digitalWrite(BMP_CS, LOW);
  SPI.transfer(r & 0x7F); SPI.transfer(v);
  digitalWrite(BMP_CS, HIGH); SPI.endTransaction();
}
static void bmp_read(uint8_t r, uint8_t *b, uint8_t n) {
  SPI.beginTransaction(BMP_SPI); digitalWrite(BMP_CS, LOW);
  SPI.transfer(r | 0x80); SPI.transfer(0);            // 1 byte gia (dummy)
  for (uint8_t i = 0; i < n; i++) b[i] = SPI.transfer(0);
  digitalWrite(BMP_CS, HIGH); SPI.endTransaction();
}
static uint8_t bmp_read8(uint8_t r) { uint8_t v; bmp_read(r, &v, 1); return v; }

void bmp_cal() {
  uint8_t d[21]; bmp_read(BMP_CAL_DATA, d, 21);
  uint16_t t1 = (d[1] << 8 | d[0]), t2 = (d[3] << 8 | d[2]); int8_t t3 = d[4];
  int16_t p1 = (d[6] << 8 | d[5]), p2 = (d[8] << 8 | d[7]); int8_t p3 = d[9], p4 = d[10];
  uint16_t p5 = (d[12] << 8 | d[11]), p6 = (d[14] << 8 | d[13]); int8_t p7 = d[15], p8 = d[16];
  int16_t p9 = (d[18] << 8 | d[17]); int8_t p10 = d[19], p11 = d[20];
  bcal.t1 = (float)t1 / 0.00390625f; bcal.t2 = (float)t2 / 1073741824.0f; bcal.t3 = (float)t3 / 281474976710656.0f;
  bcal.p1 = ((float)p1 - 16384.0f) / 1048576.0f; bcal.p2 = ((float)p2 - 16384.0f) / 536870912.0f;
  bcal.p3 = (float)p3 / 4294967296.0f; bcal.p4 = (float)p4 / 137438953472.0f;
  bcal.p5 = (float)p5 / 0.125f; bcal.p6 = (float)p6 / 64.0f; bcal.p7 = (float)p7 / 256.0f;
  bcal.p8 = (float)p8 / 32768.0f; bcal.p9 = (float)p9 / 281474976710656.0f;
  bcal.p10 = (float)p10 / 281474976710656.0f; bcal.p11 = (float)p11 / 36893488147419103232.0f;
}

float bmp_temp(uint32_t raw) {
  float d1 = (float)raw - bcal.t1, d2 = d1 * bcal.t2;
  t_lin_b = d2 + d1 * d1 * bcal.t3;
  return t_lin_b;
}
float bmp_press(uint32_t raw) {
  float d1, d2, d3, o1, o2, pp;
  d1 = bcal.p6 * t_lin_b; d2 = bcal.p7 * t_lin_b * t_lin_b; d3 = bcal.p8 * t_lin_b * t_lin_b * t_lin_b;
  o1 = bcal.p5 + d1 + d2 + d3;
  d1 = bcal.p2 * t_lin_b; d2 = bcal.p3 * t_lin_b * t_lin_b; d3 = bcal.p4 * t_lin_b * t_lin_b * t_lin_b;
  o2 = (float)raw * (bcal.p1 + d1 + d2 + d3);
  d1 = (float)raw * (float)raw; d2 = bcal.p9 + bcal.p10 * t_lin_b; d3 = d1 * d2;
  pp = d3 + (float)raw * (float)raw * (float)raw * bcal.p11;
  return o1 + o2 + pp;
}

bool baro_init() {
  pinMode(BMP_CS, OUTPUT); digitalWrite(BMP_CS, HIGH); delay(10);
  bmp_write(BMP_CMD, 0xB6); delay(10);
  bmp_read8(BMP_CHIP_ID);
  if (bmp_read8(BMP_CHIP_ID) != BMP388_ID) return false;
  bmp_cal();
  bmp_write(BMP_OSR, 0x03); bmp_write(BMP_ODR, 0x02);
  bmp_write(BMP_CONFIG, 0x02 << 1); bmp_write(BMP_PWR_CTRL, 0x33);
  delay(50);
  return true;
}

void baro_read() {
  uint8_t d[6]; bmp_read(BMP_DATA_0, d, 6);
  uint32_t rp = (uint32_t)d[2] << 16 | (uint32_t)d[1] << 8 | d[0];
  uint32_t rt = (uint32_t)d[5] << 16 | (uint32_t)d[4] << 8 | d[3];
  bmp_temp(rt);
  baro_press = bmp_press(rp) / 100.0f;                    // hPa
  baro_alt = 44330.0f * (1.0f - powf(baro_press / 1013.25f, 0.1903f));
}

bool need_baro() {
  if (baro_ok) return true;
  MON.println(F("BMP388 khong tra loi (ID sai). Kiem tra SPI / chan PA3."));
  return false;
}

/* ===========================================================================
   7. LA BAN IST8310 (I2C1 PB6/PB7)
   =========================================================================*/

bool i2c_read_reg(uint8_t addr, uint8_t reg, uint8_t *val) {
  MagWire.beginTransmission(addr);
  MagWire.write(reg);
  if (MagWire.endTransmission() != 0) return false;
  if (MagWire.requestFrom(addr, (uint8_t)1) != 1) return false;
  *val = MagWire.read();
  return true;
}
bool i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t val) {
  MagWire.beginTransmission(addr);
  MagWire.write(reg); MagWire.write(val);
  return MagWire.endTransmission() == 0;
}

void mag_detect() {
  mag_addr = 0;
  for (uint8_t a = 0x0C; a <= 0x0F; a++) {
    uint8_t id;
    if (i2c_read_reg(a, 0x00, &id) && id == 0x10) { mag_addr = a; break; }
  }
  if (!mag_addr) return;
  i2c_write_reg(mag_addr, 0x0B, 0x01); delay(20);   // soft reset
  i2c_write_reg(mag_addr, 0x41, 0x24);              // trung binh 16 lan
  i2c_write_reg(mag_addr, 0x42, 0xC0);
  delay(10);
}

// Do don: kich, cho xong (van phuc vu nen), doc 6 byte
bool mag_read_raw() {
  if (!mag_addr) return false;
  if (!i2c_write_reg(mag_addr, 0x0A, 0x01)) return false;
  uint8_t st = 0;
  uint32_t t0 = millis();
  do {
    uint32_t w = micros();
    while (micros() - w < 2000) service();
    if (!i2c_read_reg(mag_addr, 0x02, &st)) return false;
  } while (!(st & 0x01) && millis() - t0 < 30);
  if (!(st & 0x01)) return false;
  MagWire.beginTransmission(mag_addr);
  MagWire.write(0x03);
  if (MagWire.endTransmission() != 0) return false;
  if (MagWire.requestFrom(mag_addr, (uint8_t)6) != 6) return false;
  for (uint8_t i = 0; i < 3; i++) {
    uint8_t lo = MagWire.read(), hi = MagWire.read();
    mag_raw[i] = (int16_t)((hi << 8) | lo);
    if (mag_raw[i] > 5400 || mag_raw[i] < -5400) return false;
  }
  return true;
}

// Ap so calib (giong Compass.ino): ra 3 truc cam bien da hieu chuan
void mag_apply_cal(float *m) {
  float dx = mag_raw[0] - MAG_OFFSET_X;
  float dy = mag_raw[1] - MAG_OFFSET_Y;
  float dz = mag_raw[2] - MAG_OFFSET_Z;
  for (uint8_t r = 0; r < 3; r++)
    m[r] = MagSoft[r][0] * dx + MagSoft[r][1] * dy + MagSoft[r][2] * dz;
}

/* Huong mui giong code bay: doi sang truc drone, bu nghieng AN4248.
 * rs, ps = dau bu nghieng (de menu n thu ca hai chieu). */
float mag_heading(const float *m, float roll_deg, float pitch_deg, int8_t rs, int8_t ps) {
  float mx = m[0], my = m[1], mz = m[2];
  float f = MAG_FWD, r = MAG_RIGHT, d = MAG_DOWN;
  float roll = rs * roll_deg * 0.0174533f, pitch = ps * pitch_deg * 0.0174533f;
  float sr = sinf(roll), cr = cosf(roll), sp = sinf(pitch), cp = cosf(pitch);
  float hf = f * cp + r * sr * sp + d * cr * sp;
  float hr = r * cr - d * sr;
  float h = atan2f(-hr, hf) * 57.29578f + MAG_DECLINATION + MAG_HEADING_OFFSET;
  while (h < 0) h += 360.0f;
  while (h >= 360) h -= 360.0f;
  return h;
}

float ang_diff(float a, float b) {
  float e = a - b;
  while (e > 180) e -= 360;
  while (e < -180) e += 360;
  return e;
}

/* Trung binh n mau la ban (da calib) theo VECTO, kem goc nghieng.
 * Tra ve false neu doc loi qua nhieu. */
bool mag_avg(uint8_t n, float *m, float *roll, float *pitch) {
  float s[3] = {0, 0, 0}, sr = 0, sp = 0, c[3];
  uint8_t got = 0;
  for (uint8_t i = 0; i < n; i++) {
    if (!mag_read_raw()) continue;
    mag_apply_cal(c);
    if (imu_ok) { imu_read(); sr += angle_roll; sp += angle_pitch; }
    for (uint8_t k = 0; k < 3; k++) s[k] += c[k];
    got++;
  }
  if (got < n / 2) return false;
  for (uint8_t k = 0; k < 3; k++) m[k] = s[k] / got;
  *roll = sr / got; *pitch = sp / got;
  return true;
}

bool need_mag() {
  if (mag_addr) return true;
  mag_detect();
  if (mag_addr) return true;
  MON.println(F("Khong thay IST8310 (0x0C-0x0F). Kiem tra day SCL=PB6, SDA=PB7, nguon."));
  return false;
}

/* ===========================================================================
   8. MAY THU ELRS - CRSF (UART4 PA1/PA0)
   =========================================================================*/

static uint8_t crsf_crc8(const uint8_t *p, uint8_t len) {
  uint8_t crc = 0;
  for (uint8_t i = 0; i < len; i++) {
    crc ^= p[i];
    for (uint8_t b = 0; b < 8; b++)
      crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0xD5) : (uint8_t)(crc << 1);
  }
  return crc;
}

static void crsf_unpack(const uint8_t *p) {
  uint32_t bits = 0; uint8_t nbits = 0, ch = 0;
  for (uint8_t i = 0; i < 22 && ch < RX_CH; i++) {
    bits |= (uint32_t)p[i] << nbits; nbits += 8;
    while (nbits >= 11 && ch < RX_CH) {
      uint16_t v = bits & 0x7FF; bits >>= 11; nbits -= 11;
      if (v < 172) v = 172; if (v > 1811) v = 1811;
      rc[ch++] = 1000.0f + ((float)v - 172.0f) * 1000.0f / 1639.0f;
    }
  }
}

void crsf_poll() {
  uint8_t n = 0;
  while (CrsfSerial.available() && n < 128) {
    uint8_t c = CrsfSerial.read(); n++; crsf_bytes++;
    if (crsf_idx == 0) { if (c != 0xC8) continue; crsf_buf[crsf_idx++] = c; }
    else if (crsf_idx == 1) {
      if (c < 2 || c > 62) { crsf_idx = 0; continue; }
      crsf_len = c; crsf_buf[crsf_idx++] = c;
    } else {
      crsf_buf[crsf_idx++] = c;
      if (crsf_idx == (uint8_t)(crsf_len + 2)) {
        if (crsf_crc8(&crsf_buf[2], crsf_len - 1) == crsf_buf[crsf_len + 1]) {
          uint8_t type = crsf_buf[2];
          if (type == 0x16) { crsf_unpack(&crsf_buf[3]); crsf_last_rc_ms = millis(); crsf_rc_frames++; }
          else if (type == 0x14 && crsf_len >= 11) {          // LINK_STATISTICS
            link_rssi1 = crsf_buf[3]; link_rssi2 = crsf_buf[4];
            link_lq = crsf_buf[5]; link_snr = (int8_t)crsf_buf[6];
            link_rfmode = crsf_buf[8]; link_seen = true;
          }
        } else crsf_crc_err++;
        crsf_idx = 0;
      }
    }
  }
}

bool radio_ok()  { return crsf_last_rc_ms != 0 && millis() - crsf_last_rc_ms < 300; }
bool arm_on()    { return rc[ARM_CHANNEL] > ARM_THRESHOLD; }
bool thr_low()   { return rc[2] < THR_LOW_MAX; }

// Dem so goi kenh moi giay trong ms mili-giay
float crsf_measure_rate(uint16_t ms) {
  uint32_t f0 = crsf_rc_frames;
  uint32_t t0 = millis();
  while (millis() - t0 < ms) service();
  return (crsf_rc_frames - f0) * 1000.0f / ms;
}

/* ===========================================================================
   9. GPS (USART1 PA10/PA9) - doc UBX NAV-PVT giong code bay
   =========================================================================*/

static int8_t hexv(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}
bool nmea_ok(const char *s) {
  if (s[0] != '$') return false;
  uint8_t sum = 0, i = 1;
  while (s[i] && s[i] != '*') { sum ^= (uint8_t)s[i]; if (++i >= 98) return false; }
  if (s[i] != '*') return false;
  int8_t hi = hexv(s[i + 1]), lo = hexv(s[i + 2]);
  return hi >= 0 && lo >= 0 && sum == (uint8_t)((hi << 4) | lo);
}
bool nmea_field(const char *s, uint8_t idx, char *out, uint8_t sz) {
  uint8_t f = 0, o = 0;
  for (uint8_t i = 0; s[i] && s[i] != '*'; i++) {
    if (s[i] == ',') { f++; if (f > idx) break; continue; }
    if (f == idx && o < sz - 1) out[o++] = s[i];
  }
  out[o] = 0;
  return o > 0;
}
double nmea_deg(const char *v, const char *h) {
  double x = atof(v);
  int d = (int)(x / 100);
  double r = d + (x - d * 100) / 60.0;
  if (h[0] == 'S' || h[0] == 'W') r = -r;
  return r;
}
static int32_t gps_i4(uint8_t o) {
  return (int32_t)((uint32_t)gps_upl[o] | ((uint32_t)gps_upl[o+1] << 8) |
                   ((uint32_t)gps_upl[o+2] << 16) | ((uint32_t)gps_upl[o+3] << 24));
}
/* UBX-NAV-PVT, giong GPS.ino cua code bay. Offset: 20 fixType 21 flags
 * 23 numSV 24 lon 28 lat 36 hMSL 40 hAcc 48 velN 52 velE 76 pDOP */
void gps_parse_pvt() {
  uint8_t ft = gps_upl[20];
  gps_fix  = ((gps_upl[21] & 1) && (ft == 3 || ft == 4)) ? ft : 0;
  gps_sats = gps_upl[23];
  gps_lon  = gps_i4(24) * 1e-7;
  gps_lat  = gps_i4(28) * 1e-7;
  gps_alt  = gps_i4(36) * 0.001f;
  gps_hacc = (uint32_t)gps_i4(40) * 0.001f;
  gps_vn   = gps_i4(48) * 0.1f;
  gps_ve   = gps_i4(52) * 0.1f;
  gps_hdop = ((uint16_t)gps_upl[76] | ((uint16_t)gps_upl[77] << 8)) * 0.01f;
  gps_last_gga_ms = millis();
}

// Nap 1 byte: dem cau NMEA / goi UBX hop le, phan tich NAV-PVT
void gps_feed(uint8_t c) {
  if (c == '$') { gps_li = 0; gps_line[gps_li++] = c; }
  else if (gps_li > 0) {
    if (c == '\r' || c == '\n') {
      gps_line[gps_li] = 0; gps_li = 0;
      if (nmea_ok(gps_line)) { gps_valid++; gps_nmea_seen++; }
    } else if (gps_li < sizeof(gps_line) - 1) gps_line[gps_li++] = c;
    else gps_li = 0;
  }
  switch (gps_ust) {
    case 0: if (c == 0xB5) gps_ust = 1; break;
    case 1: gps_ust = (c == 0x62) ? 2 : 0; break;
    case 2: gps_ucls = c; gps_ua = c; gps_ub = gps_ua; gps_ust = 3; break;
    case 3: gps_uid = c; gps_ua += c; gps_ub += gps_ua; gps_ust = 4; break;
    case 4: gps_ulen = c; gps_ua += c; gps_ub += gps_ua; gps_ust = 5; break;
    case 5: gps_ulen |= (uint16_t)c << 8; gps_ua += c; gps_ub += gps_ua; gps_uidx = 0;
            if (gps_ulen > 1024) { gps_ust = 0; break; }
            gps_ust = gps_ulen ? 6 : 7; break;
    case 6: if (gps_uidx < sizeof(gps_upl)) gps_upl[gps_uidx] = c;
            gps_uidx++; gps_ua += c; gps_ub += gps_ua;
            if (gps_uidx >= gps_ulen) gps_ust = 7; break;
    case 7: gps_uarx = c; gps_ust = 8; break;
    case 8: gps_ust = 0;
            if (gps_uarx == gps_ua && c == gps_ub) {
              gps_valid++;
              if (gps_ucls == 0x01 && gps_uid == 0x07 && gps_ulen == 92) gps_parse_pvt();
            }
            break;
  }
}

void gps_poll() {
  uint8_t n = 0;
  while (GpsSerial.available() && n < 96) { gps_feed(GpsSerial.read()); n++; gps_bytes++; }
}

/* Bat NAV-PVT 10Hz, tat NMEA, kieu bay - CHI RAM (giong code bay).
 * Module da luu cau hinh bang menu x cua code test M10 thi lenh nay thua, vo hai. */
void gps_config_pvt() {
  const uint32_t K[] = { 0x10740001UL, 0x10740002UL, 0x20910007UL, 0x30210001UL, 0x30210002UL, 0x20110021UL };
  const uint32_t V[] = { 1, 0, 1, 100, 1, 7 };
  uint8_t p[4 + 6 * 8]; uint16_t len = 4;
  p[0] = 0; p[1] = 0x01; p[2] = 0; p[3] = 0;
  for (uint8_t k = 0; k < 6; k++) {
    for (uint8_t i = 0; i < 4; i++) p[len++] = (uint8_t)(K[k] >> (8 * i));
    uint8_t sz = (K[k] >> 28) & 7, nb = (sz == 3) ? 2 : (sz == 4) ? 4 : 1;
    for (uint8_t i = 0; i < nb; i++) p[len++] = (uint8_t)(V[k] >> (8 * i));
  }
  uint8_t h[6] = { 0xB5, 0x62, 0x06, 0x8A, (uint8_t)len, 0 }, a = 0, b = 0;
  for (uint8_t i = 2; i < 6; i++) { a += h[i]; b += a; }
  for (uint16_t i = 0; i < len; i++) { a += p[i]; b += a; }
  GpsSerial.write(h, 6); GpsSerial.write(p, len); GpsSerial.write(a); GpsSerial.write(b);
  GpsSerial.flush();
}

/* ===========================================================================
   10. MOTOR / ESC (TIM3, PWM 250Hz, 1000-2000us) - giong Motors.ino
   =========================================================================*/

void motors_write() {
  for (uint8_t i = 0; i < 4; i++)
    MotorTimer->setCaptureCompare(i + 1, constrain(motor_us[i], 1000, 2000));
}
void motors_set_all(uint16_t us) { for (uint8_t i = 0; i < 4; i++) motor_us[i] = us; motors_write(); }
void motors_off() { motors_set_all(1000); }

void motor_init() {
  MotorTimer = new HardwareTimer(TIM3);
  MotorTimer->setMode(1, TIMER_OUTPUT_COMPARE_PWM1, M1_PIN);
  MotorTimer->setMode(2, TIMER_OUTPUT_COMPARE_PWM1, M2_PIN);
  MotorTimer->setMode(3, TIMER_OUTPUT_COMPARE_PWM1, M3_PIN);
  MotorTimer->setMode(4, TIMER_OUTPUT_COMPARE_PWM1, M4_PIN);
  MotorTimer->setPrescaleFactor(MotorTimer->getTimerClkFreq() / 1000000);
  MotorTimer->setOverflow(ESC_PERIOD_US);
  motors_off();
  MotorTimer->resume();
}

/* Ly do phai dung motor NGAY (0 = van an toan). Goi lien tuc khi motor quay. */
uint8_t motor_stop_reason() {
  service();
  if (key_pressed()) return 1;
#if MOTOR_NEED_RADIO
  if (!radio_ok()) return 2;
  if (!arm_on())   return 3;
#endif
  return 0;
}
void print_stop_reason(uint8_t r) {
  motors_off();
  if      (r == 1) MON.println(F(">> DUNG: da bam phim."));
  else if (r == 2) MON.println(F(">> DUNG KHAN: MAT SONG may thu."));
  else if (r == 3) MON.println(F(">> DUNG KHAN: cong tac ARM da TAT."));
}

/* Hoi xac nhan + kiem tra dieu kien truoc khi cho motor quay.
 * props = true neu bai test cho phep lap canh (drone da buoc chat). */
bool motor_prepare(bool allow_props, bool *with_props) {
  motors_off();
  MON.println();
  MON.println(F("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
  MON.println(F("  CANH BAO: MOTOR SAP QUAY. Cam pin cho ESC."));
  if (allow_props) {
    MON.println(F("  n = KHONG canh (khuyen dung)"));
    MON.println(F("  c = CO canh - drone DA BUOC CHAT xuong dat, khong ai dung gan"));
    MON.println(F("  phim khac = huy"));
  } else {
    MON.println(F("  PHAI THAO HET CANH QUAT. Gui 'y' khi da thao, phim khac = huy."));
  }
  MON.println(F("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
  char k = wait_key();
  if (allow_props) {
    if (k == 'n') *with_props = false;
    else if (k == 'c') *with_props = true;
    else { MON.println(F("Da huy.")); return false; }
  } else {
    if (k != 'y') { MON.println(F("Da huy.")); return false; }
    if (with_props) *with_props = false;
  }

#if MOTOR_NEED_RADIO
  MON.println(F("Bat tay cam. Kenh ga (CH3) xuong DUOI CUNG, roi gat cong tac ARM (CH5) LEN."));
  MON.println(F("(bam phim bat ky de huy)"));
  uint32_t last = 0;
  while (true) {
    service();
    if (key_pressed()) { MON.println(F("Da huy.")); return false; }
    bool ok = radio_ok() && arm_on() && thr_low();
    if (ok) break;
    if (millis() - last > 1000) {
      last = millis();
      MON.print(F("  Song: ")); MON.print(radio_ok() ? F("CO") : F("KHONG"));
      MON.print(F("   ARM: ")); MON.print(arm_on() ? F("BAT") : F("tat"));
      MON.print(F("   Ga: ")); MON.print((int)rc[2]);
      MON.println(thr_low() ? F(" (thap, ok)") : F(" (HA GA XUONG)"));
    }
  }
  MON.println(F("OK. Tat cong tac ARM bat ky luc nao de DUNG KHAN."));
#else
  MON.println(F("MOTOR_NEED_RADIO = 0: khong co cong tac an toan, bam phim de dung."));
#endif
  delay(300);
  return true;
}

// Tang ga tu tu len us (0.5s) cho motor idx (0-3) hoac ca 4 (idx = 255)
uint8_t motor_ramp(uint8_t idx, uint16_t from, uint16_t to, uint16_t ms) {
  uint32_t t0 = millis();
  while (true) {
    uint32_t t = millis() - t0;
    if (t > ms) t = ms;
    uint16_t us = from + (int32_t)(to - from) * (int32_t)t / ms;
    if (idx == 255) motors_set_all(us);
    else { motor_us[idx] = us; motors_write(); }
    uint8_t r = motor_stop_reason();
    if (r) return r;
    if (t >= ms) return 0;
  }
}

// Giu nguyen ga trong ms, van canh chung. Tra ve ly do dung (0 = het gio)
uint8_t motor_hold(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    uint8_t r = motor_stop_reason();
    if (r) return r;
  }
  return 0;
}

/* ===========================================================================
   11. SETUP / LOOP / MENU
   =========================================================================*/

void setup() {
  // ESC nhan 1000us NGAY tu dau (de ESC khong tu hieu chuan / quay)
  motor_init();

  pinMode(LED_GREEN, OUTPUT); pinMode(LED_RED, OUTPUT); pinMode(LED_GPS, OUTPUT);
  digitalWrite(LED_GREEN, LOW); digitalWrite(LED_RED, HIGH); digitalWrite(LED_GPS, LOW);

  pinMode(PIN_CS, OUTPUT); digitalWrite(PIN_CS, HIGH);
  pinMode(BMP_CS, OUTPUT); digitalWrite(BMP_CS, HIGH);

  MON.begin(MON_BAUD);
  CrsfSerial.begin(CRSF_BAUD);
  GpsSerial.begin(GPS_BAUD);
  for (uint8_t i = 0; i < RX_CH; i++) rc[i] = 1500;
  rc[2] = 1000; rc[ARM_CHANNEL] = 1000;

  uint32_t t0 = millis();
  while (millis() - t0 < 300) service();
  gps_config_pvt();                         // GPS phat NAV-PVT giong code bay
  t0 = millis();
  while (millis() - t0 < 1200) service();

  SPI.begin();
  delay(100);
  imu_ok  = imu_init();
  baro_ok = baro_init();
  MagWire.begin();
  MagWire.setClock(100000);
  delay(50);
  mag_detect();

  digitalWrite(LED_RED, LOW);
  print_intro();
}

void run_menu(char c);

void loop() {
  service();
  motors_off();
  if (MON.available() > 0) {
    data = MON.read();
    delay(50);
    while (MON.available() > 0) MON.read();
    if (data >= 'A' && data <= 'Z') data += 32;
    run_menu(data);
    motors_off();
    print_intro();
  }
}

void print_intro() {
  MON.println();
  MON.println(F("===================================================================="));
  MON.println(F("  F405 - TEST TOAN BO DRONE"));
  MON.println(F("===================================================================="));
  MON.print(F("IMU ICM-20602: ")); MON.print(imu_ok ? F("co") : F("KHONG"));
  MON.print(F("   Baro BMP388: ")); MON.print(baro_ok ? F("co") : F("KHONG"));
  MON.print(F("   La ban: "));
  if (mag_addr) { MON.print(F("0x")); MON.println(mag_addr, HEX); } else MON.println(F("KHONG"));
  MON.print(F("May thu: ")); MON.print(radio_ok() ? F("co song") : F("chua co song"));
  MON.print(F("   GPS: ")); MON.print(gps_valid ? F("co du lieu") : F("chua co du lieu"));
  MON.println();
  MON.println();
  MON.println(F("  HE THONG"));
  MON.println(F("  s = Kiem tra nhanh TAT CA (bang DAT / LOI)"));
  MON.println(F("  k = Do thoi gian doc tung cam bien (us)"));
  MON.println(F("  l = Test 3 den LED"));
  MON.println(F("  IMU ICM-20602"));
  MON.println(F("  i = Kiem tra IMU (nhieu, lech con quay, 1g)"));
  MON.println(F("  p = Xem goc nghieng + toc do quay (kiem chieu truc)"));
  MON.println(F("  y = TU DO TRUC IMU (doi module / doi cach gan IMU)"));
  MON.println(F("  z = Do offset gia toc ke -> ACC_OFFSET cho Config.h [5] (lam SAU y)"));
  MON.println(F("  BARO BMP388"));
  MON.println(F("  b = Kiem tra baro (ap suat, nhiet do, nhieu)"));
  MON.println(F("  h = Xem do cao truc tiep"));
  MON.println(F("  LA BAN IST8310"));
  MON.println(F("  c = Xem huong mui (dung so calib trong file nay)"));
  MON.println(F("  n = Tim dau bu nghieng MAG_ROLL_SIGN / MAG_PITCH_SIGN"));
  MON.println(F("  MAY THU ELRS"));
  MON.println(F("  r = Xem kenh, so goi/giay, LQ, RSSI"));
  MON.println(F("  GPS GEP-M10"));
  MON.println(F("  g = Xem fix, ve tinh, HDOP, toa do"));
  MON.println(F("  DONG CO  (THAO CANH QUAT!)"));
  MON.println(F("  1 2 3 4 = Quay TUNG motor theo can ga (dang quay bam so khac de doi)"));
  MON.println(F("  m = Ca 4 motor theo can ga (kiem ESC dong bo)"));
  MON.println(F("  v = Do RUNG theo muc ga + tim motor rung nhat"));
  MON.println(F("  x = Anh huong dong dien motor len la ban"));
  MON.println(F("  e = Hieu chuan hanh trinh ga ESC (1000-2000us)"));
  MON.println(F("===================================================================="));
}

/* ===========================================================================
   12. MENU s - KIEM TRA NHANH TAT CA
   =========================================================================*/

void test_quick_all() {
  MON.println();
  MON.println(F("--- KIEM TRA NHANH TAT CA (de drone yen tren ban, bat tay cam) ---"));
  uint8_t pass = 0, total = 0;

  // 1. IMU
  total++;
  MON.print(F("1. IMU ICM-20602 ............ "));
  if (!imu_ok) imu_ok = imu_init();
  if (!imu_ok) {
    MON.print(F("LOI  WHO_AM_I = 0x")); MON.print(icm_read(REG_WHO_AM_I), HEX);
    MON.println(F(" (phai 0x12). Kiem tra SPI PA5/PA6/PA7, CS PA4."));
  } else {
    float s = 0;
    for (uint8_t i = 0; i < 100; i++) {
      imu_read(); s += sqrtf(acc_x * acc_x + acc_y * acc_y + acc_z * acc_z); delay(2);
    }
    float a = s / 100;
    bool ok = a > 0.9f && a < 1.1f;
    MON.print(ok ? F("DAT") : F("LOI")); MON.print(F("  |gia toc| = ")); MON.print(a, 3);
    MON.println(ok ? F(" g") : F(" g (phai ~1.00 khi de yen)"));
    if (ok) pass++;
  }

  // 2. Baro
  total++;
  MON.print(F("2. Baro BMP388 .............. "));
  if (!baro_ok) baro_ok = baro_init();
  if (!baro_ok) {
    MON.println(F("LOI  chip ID sai (phai 0x50). Kiem tra SPI, CS PA3."));
  } else {
    float s = 0;
    for (uint8_t i = 0; i < 10; i++) { baro_read(); s += baro_press; delay(20); }
    float p = s / 10;
    bool ok = p > 900 && p < 1100;
    MON.print(ok ? F("DAT") : F("LOI")); MON.print(F("  ")); MON.print(p, 1);
    MON.print(F(" hPa, ")); MON.print(t_lin_b, 1); MON.println(F(" do C"));
    if (ok) pass++;
  }

  // 3. La ban
  total++;
  MON.print(F("3. La ban IST8310 ........... "));
  if (!mag_addr) mag_detect();
  if (!mag_addr) {
    MON.println(F("LOI  khong thay o 0x0C-0x0F. Kiem tra SCL PB6, SDA PB7, nguon."));
  } else {
    uint8_t got = 0; float b = 0;
    for (uint8_t i = 0; i < 5; i++)
      if (mag_read_raw()) {
        got++;
        b += IST_UT_PER_LSB * sqrtf((float)mag_raw[0] * mag_raw[0] +
                                    (float)mag_raw[1] * mag_raw[1] + (float)mag_raw[2] * mag_raw[2]);
      }
    bool ok = got >= 4 && (b / got) > 20 && (b / got) < 80;
    MON.print(ok ? F("DAT") : F("LOI")); MON.print(F("  dia chi 0x")); MON.print(mag_addr, HEX);
    MON.print(F(", tu truong ")); MON.print(got ? b / got : 0, 1);
    MON.println(ok ? F(" uT") : F(" uT (phai 25-65, hoac doc loi)"));
    if (ok) pass++;
  }

  // 4 + 5. GPS va may thu: nghe 1.5 giay
  uint32_t gb0 = gps_bytes, gv0 = gps_valid, cb0 = crsf_bytes, cf0 = crsf_rc_frames;
  uint32_t t0 = millis();
  while (millis() - t0 < 1500) service();
  uint32_t gb = gps_bytes - gb0, gv = gps_valid - gv0;
  uint32_t cb = crsf_bytes - cb0, cf = crsf_rc_frames - cf0;

  total++;
  MON.print(F("4. GPS (115200) ............. "));
  if (gv > 0) {
    pass++;
    MON.print(F("DAT  ")); MON.print(gv * 2 / 3); MON.print(F(" goi/giay, "));
    if (gps_fix) { MON.print(F("co fix, ")); MON.print(gps_sats); MON.print(F(" ve tinh, hAcc ")); MON.print(gps_hacc, 2); MON.println('m'); }
    else MON.println(F("CHUA fix (ra ngoai troi)"));
  } else if (gb > 0) MON.println(F("LOI  co byte nhung khong dung checksum -> sai baud (dung code test M10, menu l)"));
  else MON.println(F("LOI  khong nhan byte nao. GPS TX -> PA10, nguon 5V."));

  total++;
  MON.print(F("5. May thu ELRS ............. "));
  if (cf > 0) {
    pass++;
    MON.print(F("DAT  ")); MON.print(cf * 2 / 3); MON.print(F(" goi kenh/giay"));
    if (link_seen) { MON.print(F(", LQ ")); MON.print(link_lq); MON.print('%'); }
    MON.println();
  } else if (cb > 0) MON.println(F("LOI  co byte nhung khong co goi hop le -> sai baud hoac chan may thu chua dat SERIAL"));
  else MON.println(F("LOI  khong nhan byte nao. Bat tay cam; ELRS TX -> PA1, nguon 5V."));

  MON.println(F("6. Den LED .................. xem bang menu l"));
  MON.println(F("7. Motor / ESC .............. xem bang menu 1 2 3 4 (THAO CANH)"));
  MON.println();
  MON.print(F("==> DAT ")); MON.print(pass); MON.print('/'); MON.print(total);
  MON.println(pass == total ? F("  - tat ca cam bien deu tra loi.") : F("  - xem dong LOI o tren."));
  MON.println(F("Bam phim bat ky de ve menu."));
  wait_key();
}

/* ===========================================================================
   13. MENU k - DO THOI GIAN DOC TUNG CAM BIEN
   Vong lap code bay chi co 4000us. Moi vong doc: IMU + baro + GPS + may
   thu, cu 5 vong mot lan cham vao la ban. Phan con lai la tinh toan.
   =========================================================================*/

void time_report(const __FlashStringHelper *name, uint32_t sum, uint32_t mx, uint16_t n) {
  MON.print(F("  ")); MON.print(name);
  MON.print(F("  tb ")); MON.print(n ? sum / n : 0);
  MON.print(F(" us   lau nhat ")); MON.print(mx);
  MON.print(F(" us   (")); MON.print(mx * 100.0f / 4000.0f, 1); MON.println(F("% vong 4ms)"));
}

void test_timing() {
  MON.println();
  MON.println(F("--- THOI GIAN DOC CAM BIEN (vong lap code bay = 4000 us) ---"));
  uint32_t sum, mx, t;
  uint32_t worst = 0;

  if (imu_ok) {
    sum = mx = 0;
    for (uint16_t i = 0; i < 500; i++) {
      t = micros(); imu_read(); t = micros() - t;
      sum += t; if (t > mx) mx = t; service();
    }
    time_report(F("IMU (14 byte SPI + tinh goc) "), sum, mx, 500); worst += mx;
  }
  if (baro_ok) {
    sum = mx = 0;
    for (uint16_t i = 0; i < 200; i++) {
      t = micros(); baro_read(); t = micros() - t;
      sum += t; if (t > mx) mx = t; service();
    }
    time_report(F("Baro (6 byte SPI + pow)      "), sum, mx, 200); worst += mx;
  }
  uint32_t mag_worst = 0;
  if (mag_addr) {
    uint32_t s1 = 0, m1 = 0, s2 = 0, m2 = 0;
    uint8_t st;
    for (uint8_t i = 0; i < 40; i++) {
      t = micros(); i2c_write_reg(mag_addr, 0x0A, 0x01); t = micros() - t;
      s1 += t; if (t > m1) m1 = t;
      uint32_t w = millis(); while (millis() - w < 12) service();
      t = micros();
      i2c_read_reg(mag_addr, 0x02, &st);
      MagWire.beginTransmission(mag_addr); MagWire.write(0x03); MagWire.endTransmission();
      MagWire.requestFrom(mag_addr, (uint8_t)6);
      while (MagWire.available()) MagWire.read();
      t = micros() - t;
      s2 += t; if (t > m2) m2 = t;
    }
    time_report(F("La ban: lenh kich do (I2C)   "), s1, m1, 40);
    time_report(F("La ban: doc 6 byte (I2C)     "), s2, m2, 40);
    mag_worst = m1 > m2 ? m1 : m2;
  }
  {
    uint32_t sg = 0, mg = 0, sc = 0, mc = 0, n = 0;
    uint32_t t0 = millis();
    while (millis() - t0 < 2000) {
      t = micros(); gps_poll();  t = micros() - t; sg += t; if (t > mg) mg = t;
      t = micros(); crsf_poll(); t = micros() - t; sc += t; if (t > mc) mc = t;
      n++;
      delayMicroseconds(3000);          // gia lap mot vong 4ms
    }
    time_report(F("GPS: doc + phan tich NAV-PVT "), sg, mg, n);
    time_report(F("May thu: doc + giai goi CRSF "), sc, mc, n);
    worst += mg + mc;
  }
  MON.println();
  MON.print(F("  Tong phan DOC trong vong xau nhat: ~")); MON.print(worst + mag_worst);
  MON.println(F(" us (tinh ca la ban)."));
  MON.println(F("  Con lai la PID, bo loc, Kalman, telemetry. Tong THAT cua code bay"));
  MON.println(F("  hien tren tay cam: cam bien FM, so sau chu L (phai duoi 4.0 ms)."));
  if (worst + mag_worst > 2500)
    MON.println(F("  CANH BAO: rieng phan doc da qua 2.5 ms -> de tre vong lap."));
  MON.println(F("Bam phim bat ky de ve menu."));
  wait_key();
}

/* ===========================================================================
   14. MENU l - TEST DEN LED
   =========================================================================*/

void test_leds() {
  MON.println();
  MON.println(F("--- TEST DEN (bam phim bat ky de dung) ---"));
  const uint8_t pins[3] = { LED_GREEN, LED_RED, LED_GPS };
  const char *names[3] = { "XANH  (PB3) - co song",
                           "DO    (PB4) - mat song / failsafe",
                           "GPS   (PB5) - GPS san sang" };
  for (uint8_t k = 0; k < 3; k++) {
    for (uint8_t j = 0; j < 3; j++) digitalWrite(pins[j], LOW);
    digitalWrite(pins[k], HIGH);
    MON.print(F("  Dang sang: den ")); MON.println(names[k]);
    if (!wait_ms(1500)) break;
  }
  MON.println(F("  Ca 3 den nhay cung luc 3 lan..."));
  for (uint8_t n = 0; n < 3; n++) {
    for (uint8_t j = 0; j < 3; j++) digitalWrite(pins[j], HIGH);
    if (!wait_ms(300)) break;
    for (uint8_t j = 0; j < 3; j++) digitalWrite(pins[j], LOW);
    if (!wait_ms(300)) break;
  }
  for (uint8_t j = 0; j < 3; j++) digitalWrite(pins[j], LOW);
  MON.println(F("Den nao KHONG sang: kiem tra chieu LED, dien tro, day ve GND."));
}

/* ===========================================================================
   15. MENU i - KIEM TRA IMU
   =========================================================================*/

void test_imu() {
  MON.println();
  MON.println(F("--- KIEM TRA IMU ICM-20602 (de drone YEN tren ban) ---"));
  if (!imu_ok) imu_ok = imu_init();
  if (!need_imu()) { wait_key(); return; }
  MON.println(F("1. WHO_AM_I = 0x12   DAT"));
  MON.println(F("Dang do 2 giay, khong cham vao drone..."));
  wait_ms(800);

  imu_config_flight();
  float sg[3] = {0}, sg2[3] = {0}, sa[3] = {0}, sT = 0;
  const uint16_t N = 1000;
  for (uint16_t i = 0; i < N; i++) {
    imu_read();
    float g[3] = { gyr_r, gyr_p, gyr_y };
    for (uint8_t k = 0; k < 3; k++) { sg[k] += g[k]; sg2[k] += g[k] * g[k]; }
    sa[0] += acc_x; sa[1] += acc_y; sa[2] += acc_z; sT += imu_temp_c();
    service(); delay(2);
  }
  const char *ax[3] = { "Roll ", "Pitch", "Yaw  " };
  MON.println(F("2. Con quay (bo loc giong code bay):"));
  bool gyro_ok = true;
  for (uint8_t k = 0; k < 3; k++) {
    float m = sg[k] / N, sd = stddev(sg[k], sg2[k], N);
    MON.print(F("   ")); MON.print(ax[k]);
    MON.print(F("  lech ")); MON.print(m, 2); MON.print(F(" do/s   nhieu ")); MON.print(sd, 3); MON.print(F(" do/s   "));
    bool ok = fabsf(m) < 5.0f && sd < 0.5f;
    if (!ok) gyro_ok = false;
    MON.println(ok ? F("DAT") : F("KEM"));
  }
  if (!gyro_ok) MON.println(F("   Lech > 5 do/s hoac nhieu > 0.5: chip loi hoac drone bi rung / cham vao."));
  else MON.println(F("   (Lech nho la binh thuong: code bay tu tru lech moi lan arm.)"));

  float ax_ = sa[0] / N, ay_ = sa[1] / N, az_ = sa[2] / N;
  float amag = sqrtf(ax_ * ax_ + ay_ * ay_ + az_ * az_);
  MON.print(F("3. Gia toc ke: X ")); MON.print(ax_, 3); MON.print(F("  Y ")); MON.print(ay_, 3);
  MON.print(F("  Z ")); MON.print(az_, 3); MON.print(F("   |a| = ")); MON.print(amag, 3);
  bool acc_ok = amag > 0.95f && amag < 1.05f && az_ > 0.8f;
  MON.println(acc_ok ? F(" g   DAT") : F(" g   KEM"));
  if (az_ < 0.8f) MON.println(F("   Z phai ~ +1 khi drone nam ngang, mach up len tren. Mach lap nguoc?"));

  float r = atanf(ay_ / sqrtf(ax_ * ax_ + az_ * az_)) * 57.2958f;
  float p = -atanf(ax_ / sqrtf(ay_ * ay_ + az_ * az_)) * 57.2958f;
  MON.print(F("4. Goc khi de yen: Roll ")); MON.print(r, 2); MON.print(F(" do   Pitch ")); MON.print(p, 2);
  MON.println(F(" do"));
  if (fabsf(r) > 1.5f || fabsf(p) > 1.5f)
    MON.println(F("   Lech > 1.5 do: ban khong phang, hoac can do lai offset (menu z tren mat phang)."));
  MON.print(F("5. Nhiet do chip: ")); MON.print(sT / N, 1); MON.println(F(" do C"));

  // Nhieu that cua chip, bo loc rong
  imu_config_wide();
  float s1[3] = {0}, s2[3] = {0};
  for (uint16_t i = 0; i < N; i++) {
    imu_read();
    float g[3] = { gyr_r, gyr_p, gyr_y };
    for (uint8_t k = 0; k < 3; k++) { s1[k] += g[k]; s2[k] += g[k] * g[k]; }
    delayMicroseconds(1000); service();
  }
  imu_config_flight();
  MON.print(F("6. Nhieu con quay voi bo loc RONG (176Hz): R "));
  MON.print(stddev(s1[0], s2[0], N), 2); MON.print(F("  P ")); MON.print(stddev(s1[1], s2[1], N), 2);
  MON.print(F("  Y ")); MON.print(stddev(s1[2], s2[2], N), 2); MON.println(F(" do/s (thuong 0.05-0.3)"));
  MON.println();
  MON.println(gyro_ok && acc_ok ? F("==> IMU DAT.") : F("==> IMU CO VAN DE, xem dong KEM."));
  MON.println(F("Tiep theo: menu p de kiem chieu truc. Bam phim bat ky de ve menu."));
  wait_key();
}

/* ===========================================================================
   16. MENU p - XEM GOC NGHIENG VA TOC DO QUAY
   Dau DUNG theo bo tron motor cua code bay:
     nghieng suon PHAI xuong -> Roll DUONG
     CHUC mui xuong          -> Pitch DUONG
     xoay mui sang PHAI      -> toc do Yaw AM
   =========================================================================*/

void stream_attitude() {
  if (!need_imu()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- GOC NGHIENG + TOC DO QUAY (bam phim bat ky de thoat) ---"));
  MON.println(F("De yen 1 giay de do lech con quay..."));
  imu_measure_bias(500);
  MON.println(F("Kiem tra dau (theo bo tron motor cua code bay):"));
  MON.println(F("  Nghieng suon PHAI xuong   -> Roll DUONG,  toc do Roll DUONG luc dang nghieng"));
  MON.println(F("  CHUC mui xuong            -> Pitch DUONG, toc do Pitch DUONG luc dang chuc"));
  MON.println(F("  Xoay mui sang PHAI (thuan chieu kim dong ho, nhin tu tren) -> toc do Yaw AM"));
  MON.println(F("Sai dau nao thi drone se lat ngay khi cat canh - dung bay, bao lai."));
  MON.println();
  wait_ms(1500);

  float sr = 0, sp = 0, sy = 0; uint16_t n = 0;
  uint32_t last = millis();
  while (true) {
    imu_read();
    sr += gyr_r - gyro_bias[0]; sp += gyr_p - gyro_bias[1]; sy += gyr_y - gyro_bias[2]; n++;
    if (millis() - last >= 150) {
      last = millis();
      MON.print(F("Roll ")); MON.print(angle_roll, 1);
      MON.print(F("   Pitch ")); MON.print(angle_pitch, 1);
      MON.print(F("   | toc do quay (do/s)  Roll ")); MON.print(sr / n, 0);
      MON.print(F("  Pitch ")); MON.print(sp / n, 0);
      MON.print(F("  Yaw ")); MON.println(sy / n, 0);
      sr = sp = sy = 0; n = 0;
    }
    service();
    if (key_pressed()) break;
    delay(2);
  }
}

/* ===========================================================================
   16b. MENU y - TU DO TRUC IMU (sau khi doi module / doi cach gan)
   Code can: X = MUI, Y = TRAI, Z = LEN. Gia toc ke do "luc nang" nguoc
   chieu trong luc, nen khi drone nam ngang truc LEN doc +1g.
     Nam ngang         -> truc nao ~ +-1g  la Z (dau sao cho ra +1)
     Chuc mui xuong    -> truc doi nhieu nhat la X; X (mui) chuc xuong thi
                          doc AM (code bay: pitch = -atan(AccX..) phai DUONG)
     Nghieng suon PHAI -> truc con lai la Y (trai); trai nang len thi doc DUONG
   =========================================================================*/

bool imu_pose(const __FlashStringHelper *msg, float *a) {
  MON.print(F("  -> ")); MON.println(msg);
  MON.println(F("     Giu YEN roi bam phim bat ky (q = huy)."));
  if (wait_key() == 'q') return false;
  float s[3] = {0, 0, 0};
  for (uint16_t i = 0; i < 300; i++) {
    imu_read();
    for (uint8_t k = 0; k < 3; k++) s[k] += imu_chip[k] / 4096.0f;
    service(); delay(2);
  }
  for (uint8_t k = 0; k < 3; k++) a[k] = s[k] / 300;
  MON.print(F("     chip X ")); MON.print(a[0], 2); MON.print(F("  Y ")); MON.print(a[1], 2);
  MON.print(F("  Z ")); MON.print(a[2], 2); MON.println(F("  (g)"));
  return true;
}

void imu_axis_wizard() {
  if (!need_imu()) { wait_key(); return; }
  imu_config_flight();
  MON.println();
  MON.println(F("--- TU DO TRUC IMU ---"));
  MON.println(F("Cam CA CON DRONE (khong canh). Nghieng ~40 do, khong qua 60 do."));
  MON.println(F("Biet ro dau la MUI drone truoc khi lam."));
  float A0[3], A1[3], A2[3];
  if (!imu_pose(F("Tu the 1/3: NAM NGANG tren mat phang"), A0)) return;
  if (!imu_pose(F("Tu the 2/3: CHUC MUI XUONG ~40 do"), A1)) return;
  if (!imu_pose(F("Tu the 3/3: NGHIENG SUON PHAI XUONG ~40 do"), A2)) return;

  const char *cn[3] = { "X", "Y", "Z" };
  uint8_t zA = 0;
  for (uint8_t k = 1; k < 3; k++) if (fabsf(A0[k]) > fabsf(A0[zA])) zA = k;
  int8_t zS = A0[zA] > 0 ? 1 : -1;
  uint8_t xA = 255; float best = 0;
  for (uint8_t k = 0; k < 3; k++) if (k != zA && fabsf(A1[k] - A0[k]) > best) { best = fabsf(A1[k] - A0[k]); xA = k; }
  int8_t xS = A1[xA] < 0 ? 1 : -1;               // code X (mui) phai AM khi chuc mui
  uint8_t yA = 3 - zA - xA;
  int8_t yS = A2[yA] > 0 ? 1 : -1;               // code Y (trai) phai DUONG khi nghieng phai

  // Kiem tra
  bool ok = true;
  MON.println();
  MON.println(F("--- KIEM TRA ---"));
  MON.print(F("  Nam ngang: chip ")); MON.print(cn[zA]); MON.print(F(" = ")); MON.print(A0[zA], 2);
  if (fabsf(A0[zA]) < 0.85f) { MON.println(F(" g  <- phai ~1g: chua nam yen / chua phang")); ok = false; }
  else MON.println(F(" g  DAT"));
  float d1 = A1[xA] - A0[xA], d2 = A2[yA] - A0[yA];
  MON.print(F("  Chuc mui: chip ")); MON.print(cn[xA]); MON.print(F(" doi ")); MON.print(d1, 2);
  if (fabsf(d1) < 0.35f) { MON.println(F(" g  <- qua it: nghieng nhieu hon")); ok = false; } else MON.println(F(" g  DAT"));
  MON.print(F("  Nghieng phai: chip ")); MON.print(cn[yA]); MON.print(F(" doi ")); MON.print(d2, 2);
  if (fabsf(d2) < 0.35f) { MON.println(F(" g  <- qua it, hoac nghieng nham huong")); ok = false; } else MON.println(F(" g  DAT"));
  float cross = fabsf(A2[xA] - A0[xA]);
  if (cross > 0.3f) { MON.println(F("  CANH BAO: luc nghieng phai, truc mui cung doi nhieu -> nghieng bi xien.")); ok = false; }
  // Dinh thuc phep doi truc phai = +1 (chip that chi xoay, khong soi guong)
  int8_t M[3][3] = {{0}};
  M[0][xA] = xS; M[1][yA] = yS; M[2][zA] = zS;
  int det = M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1]) - M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])
          + M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0]);
  if (det != 1) {
    MON.println(F("  LOI: ket qua la anh SOI GUONG - khong the voi chip that."));
    MON.println(F("       Thuong do nham MUI / nham suon PHAI. Lam lai."));
    ok = false;
  }

  // Ap dung tam de kiem tra con quay
  uint8_t om[3]; int8_t os[3];
  for (uint8_t k = 0; k < 3; k++) { om[k] = imu_map[k]; os[k] = imu_sgn[k]; }
  imu_map[0] = xA; imu_sgn[0] = xS; imu_map[1] = yA; imu_sgn[1] = yS; imu_map[2] = zA; imu_sgn[2] = zS;

  if (ok) {
    MON.println();
    MON.println(F("Kiem tra con quay: dat drone NAM NGANG, bam phim, roi trong 3 giay"));
    MON.println(F("XOAY MUI SANG PHAI khoang 90 do (thuan chieu kim dong ho nhin tu tren)."));
    wait_key();
    imu_measure_bias(300);
    float yaw = 0; uint32_t t0 = millis(), tl = micros();
    while (millis() - t0 < 3000) {
      imu_read();
      uint32_t now = micros(); float dt = (now - tl) * 1e-6f; tl = now;
      yaw += (gyr_y - gyro_bias[2]) * dt;
      service();
    }
    MON.print(F("  Goc yaw do duoc: ")); MON.print(yaw, 0); MON.print(F(" do  "));
    if (yaw < -40) MON.println(F("DAT (xoay phai -> AM, dung voi code bay)"));
    else if (yaw > 40) { MON.println(F("<- DUONG: SAI. Kiem tra lai dau MUI va lam lai.")); ok = false; }
    else { MON.println(F("<- qua nho: chua xoay du / xoay qua cham.")); ok = false; }
  }

  MON.println();
  MON.println(F("=== CHEP DE VAO Config.h MUC [5] (va muc 1 file nay) ==="));
  MON.print(F("#define IMU_X_AXIS      ")); MON.println(xA);
  MON.print(F("#define IMU_X_SIGN      (")); MON.print(xS > 0 ? "+1" : "-1"); MON.println(')');
  MON.print(F("#define IMU_Y_AXIS      ")); MON.println(yA);
  MON.print(F("#define IMU_Y_SIGN      (")); MON.print(yS > 0 ? "+1" : "-1"); MON.println(')');
  MON.print(F("#define IMU_Z_AXIS      ")); MON.println(zA);
  MON.print(F("#define IMU_Z_SIGN      (")); MON.print(zS > 0 ? "+1" : "-1"); MON.println(')');
  MON.println(F("========================================================"));
  if (ok) {
    MON.println(F("==> DANG TIN. Da ap dung tam: menu p de xem, menu z de do lai offset."));
  } else {
    for (uint8_t k = 0; k < 3; k++) { imu_map[k] = om[k]; imu_sgn[k] = os[k]; }
    MON.println(F("==> CHUA DANG TIN, chua ap dung. Lam lai menu y."));
  }
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   17. MENU z - DO OFFSET GIA TOC KE
   Code bay: AccX = raw/4096 + ACC_OFFSET_X ... nen offset = -(trung binh),
   rieng Z = 1 - trung binh (nam ngang thi Z phai dung 1g).
   =========================================================================*/

void calib_acc_offset() {
  if (!need_imu()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- DO OFFSET GIA TOC KE ---"));
  MON.println(F("Dat drone len MAT PHANG THAT (kiem bang thuoc thuy / app dien thoai),"));
  MON.println(F("dung chan dap nhu luc dat xuong dat truoc khi bay. Khong cham vao."));
  MON.println(F("Bam phim bat ky khi san sang..."));
  wait_key();
  MON.println(F("Dang do 3 giay..."));
  wait_ms(500);
  imu_config_flight();
  float s[3] = {0, 0, 0}; const uint16_t N = 1500;
  for (uint16_t i = 0; i < N; i++) {
    imu_read();
    s[0] += imu_raw[0] / 4096.0f; s[1] += imu_raw[1] / 4096.0f; s[2] += imu_raw[2] / 4096.0f;
    service(); delay(2);
  }
  float mx = s[0] / N, my = s[1] / N, mz = s[2] / N;
  float ox = -mx, oy = -my, oz = 1.0f - mz;
  MON.print(F("Truc dang dung: X<-chip ")); MON.print(imu_map[0]); MON.print(F("  Y<-chip "));
  MON.print(imu_map[1]); MON.print(F("  Z<-chip ")); MON.println(imu_map[2]);
  MON.print(F("Trung binh (truc drone): X ")); MON.print(mx, 4); MON.print(F("  Y ")); MON.print(my, 4);
  MON.print(F("  Z ")); MON.println(mz, 4);
  MON.println();
  MON.println(F("=== CHEP DE VAO Config.h MUC [5] ==="));
  MON.print(F("#define ACC_OFFSET_X   (")); MON.print(ox, 4); MON.println(')');
  MON.print(F("#define ACC_OFFSET_Y   (")); MON.print(oy, 4); MON.println(')');
  MON.print(F("#define ACC_OFFSET_Z   (")); MON.print(oz, 4); MON.println(')');
  MON.println(F("===================================="));
  MON.print(F("(Dang dung trong Config.h: X ")); MON.print(ACC_OFFSET_X, 4);
  MON.print(F("  Y ")); MON.print(ACC_OFFSET_Y, 4); MON.print(F("  Z ")); MON.print(ACC_OFFSET_Z, 4); MON.println(')');
  if (fabsf(ox) > 0.1f || fabsf(oy) > 0.1f)
    MON.println(F("Offset > 0.1g (~6 do): mat phang co that phang khong? Mach co lap nghieng?"));
  MON.println(F("Chep ca vao muc 1 cua file nay de menu i / p dung so moi. Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   18. MENU b / h - BARO
   =========================================================================*/

void test_baro() {
  MON.println();
  MON.println(F("--- KIEM TRA BARO BMP388 (de yen, tranh gio / quat) ---"));
  if (!baro_ok) baro_ok = baro_init();
  if (!need_baro()) { wait_key(); return; }
  MON.println(F("1. Chip ID = 0x50   DAT"));
  float sp = 0, sa = 0, sa2 = 0, st = 0; const uint16_t N = 150;
  for (uint16_t i = 0; i < N; i++) {
    baro_read(); sp += baro_press; sa += baro_alt; sa2 += baro_alt * baro_alt; st += t_lin_b;
    if (!wait_ms(20)) break;
  }
  float p = sp / N, sd = stddev(sa, sa2, N), t = st / N;
  MON.print(F("2. Ap suat: ")); MON.print(p, 2); MON.print(F(" hPa   "));
  print_ok(p > 950 && p < 1050);
  MON.print(F("3. Nhiet do: ")); MON.print(t, 1); MON.print(F(" do C   "));
  print_ok(t > -10 && t < 70);
  MON.print(F("4. Nhieu do cao (do lech chuan): ")); MON.print(sd * 100, 1); MON.print(F(" cm   "));
  if (sd < 0.15f) MON.println(F("TOT"));
  else if (sd < 0.35f) MON.println(F("TAM DUOC"));
  else MON.println(F("KEM - che baro bang mut xop den, tranh gio canh / anh nang truc tiep"));
  MON.println(F("Tiep theo: menu h, nang drone len 1 m xem do cao. Bam phim de ve menu."));
  wait_key();
}

void stream_altitude() {
  if (!need_baro()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- DO CAO BARO (bam phim bat ky de thoat) ---"));
  MON.println(F("Dat drone xuong, cho lay diem 0..."));
  float s = 0;
  for (uint8_t i = 0; i < 50; i++) { baro_read(); s += baro_alt; wait_ms(20); }
  float zero = s / 50, filt = 0;
  MON.println(F("Nang drone len dung 1 m: so phai len ~ +1.00 (sai 10-20 cm la binh thuong)."));
  uint32_t last = millis();
  while (true) {
    baro_read();
    filt += 0.15f * ((baro_alt - zero) - filt);
    if (millis() - last >= 250) {
      last = millis();
      MON.print(F("Do cao: ")); if (filt >= 0) MON.print('+'); MON.print(filt, 2);
      MON.print(F(" m    ap suat ")); MON.print(baro_press, 2); MON.println(F(" hPa"));
    }
    if (!wait_ms(25)) break;
  }
}

/* ===========================================================================
   19. MENU c - HUONG MUI (dung so calib trong muc 1)
   =========================================================================*/

void stream_heading() {
  if (!need_mag()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- HUONG MUI (bam phim bat ky de thoat) ---"));
  MON.println(F("Dung so calib chep tu Config.h (30/09). Neu da di chuyen la ban -> calib"));
  MON.println(F("lai bang code test F405_IST8310_M10_test. 0=Bac 90=Dong 180=Nam 270=Tay."));
  wait_ms(1200);
  const char *dirs[8] = { "Bac", "Dong Bac", "Dong", "Dong Nam", "Nam", "Tay Nam", "Tay", "Tay Bac" };
  while (true) {
    float m[3], r, p;
    if (mag_avg(4, m, &r, &p)) {
      float h = mag_heading(m, r, p, MAG_ROLL_SIGN, MAG_PITCH_SIGN);
      float fm = sqrtf(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
      float dev = (fm - MAG_FIELD_NOMINAL) * 100.0f / MAG_FIELD_NOMINAL;
      MON.print(F("Huong ")); MON.print(h, 1); MON.print(F(" do ("));
      MON.print(dirs[(uint8_t)((h + 22.5f) / 45.0f) % 8]);
      MON.print(F(")   |M| ")); MON.print(fm, 0); MON.print(F(" (")); if (dev >= 0) MON.print('+');
      MON.print(dev, 0); MON.print(F("%)"));
      if (fabsf(dev) > 25) MON.print(F(" <- code bay se BO mau nay (sat thep gan?)"));
      MON.print(F("   Roll ")); MON.print(r, 0); MON.print(F(" Pitch ")); MON.println(p, 0);
    } else MON.println(F("Doc la ban loi."));
    if (!wait_ms(150)) break;
  }
}

/* ===========================================================================
   20. MENU n - TIM DAU BU NGHIENG CUA LA BAN
   Bu nghieng dung dau thi nghieng drone ma huong mui GAN NHU KHONG DOI.
   Sai dau PITCH lech nhieu nhat khi mui quay DONG / TAY.
   Sai dau ROLL  lech nhieu nhat khi mui quay BAC / NAM.
   =========================================================================*/

bool capture_pose(MagPose *ps, const __FlashStringHelper *msg) {
  MON.print(F("  -> ")); MON.println(msg);
  MON.println(F("     Giu YEN roi bam phim bat ky (q = huy)."));
  char k = wait_key();
  if (k == 'q') return false;
  MON.print(F("     Dang do... "));
  if (!mag_avg(24, ps->m, &ps->roll, &ps->pitch)) { MON.println(F("doc la ban loi.")); return false; }
  MON.print(F("Roll ")); MON.print(ps->roll, 0); MON.print(F("  Pitch ")); MON.println(ps->pitch, 0);
  return true;
}

// Lech lon nhat cua 2 tu the nghieng so voi tu the nam ngang
float pose_spread(const MagPose *P, int8_t rs, int8_t ps) {
  float h0 = mag_heading(P[0].m, P[0].roll, P[0].pitch, rs, ps);
  float a = fabsf(ang_diff(mag_heading(P[1].m, P[1].roll, P[1].pitch, rs, ps), h0));
  float b = fabsf(ang_diff(mag_heading(P[2].m, P[2].roll, P[2].pitch, rs, ps), h0));
  return a > b ? a : b;
}

void mag_tilt_sign_wizard() {
  if (!need_mag() || !need_imu()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- TIM DAU BU NGHIENG LA BAN ---"));
  MON.println(F("Cam CA CON DRONE, dung ngoai troi xa sat thep. Moi tu the nghieng ~30 do,"));
  MON.println(F("GIU NGUYEN huong mui trong ca 3 tu the cua moi phan."));
  MON.println();

  // Phan A: dau PITCH, mui quay Dong hoac Tay
  MagPose A[3];
  MON.println(F("PHAN A (dau PITCH): quay mui drone ve DONG hoac TAY."));
  if (!capture_pose(&A[0], F("Tu the 1/3: NAM NGANG"))) return;
  float hA = mag_heading(A[0].m, A[0].roll, A[0].pitch, MAG_ROLL_SIGN, MAG_PITCH_SIGN);
  MON.print(F("     Huong mui: ")); MON.print(hA, 0); MON.println(F(" do"));
  if (fabsf(ang_diff(hA, 90)) > 35 && fabsf(ang_diff(hA, 270)) > 35)
    MON.println(F("     LUU Y: mui chua quay Dong/Tay -> ket qua phan A kem ro rang."));
  if (!capture_pose(&A[1], F("Tu the 2/3: CHUC MUI XUONG ~30 do"))) return;
  if (!capture_pose(&A[2], F("Tu the 3/3: NGOC MUI LEN ~30 do"))) return;
  if (fabsf(A[1].pitch) < 15 || fabsf(A[2].pitch) < 15)
    MON.println(F("     LUU Y: nghieng chua du 15 do -> ket qua co the chua ro."));

  float pa_pos = pose_spread(A, MAG_ROLL_SIGN, +1), pa_neg = pose_spread(A, MAG_ROLL_SIGN, -1);
  int8_t best_ps = pa_pos <= pa_neg ? +1 : -1;

  // Phan B: dau ROLL, mui quay Bac hoac Nam
  MagPose B[3];
  MON.println();
  MON.println(F("PHAN B (dau ROLL): quay mui drone ve BAC hoac NAM."));
  if (!capture_pose(&B[0], F("Tu the 1/3: NAM NGANG"))) return;
  float hB = mag_heading(B[0].m, B[0].roll, B[0].pitch, MAG_ROLL_SIGN, best_ps);
  MON.print(F("     Huong mui: ")); MON.print(hB, 0); MON.println(F(" do"));
  if (fabsf(ang_diff(hB, 0)) > 35 && fabsf(ang_diff(hB, 180)) > 35)
    MON.println(F("     LUU Y: mui chua quay Bac/Nam -> ket qua phan B kem ro rang."));
  if (!capture_pose(&B[1], F("Tu the 2/3: NGHIENG SUON PHAI XUONG ~30 do"))) return;
  if (!capture_pose(&B[2], F("Tu the 3/3: NGHIENG SUON TRAI XUONG ~30 do"))) return;
  if (fabsf(B[1].roll) < 15 || fabsf(B[2].roll) < 15)
    MON.println(F("     LUU Y: nghieng chua du 15 do -> ket qua co the chua ro."));

  float rb_pos = pose_spread(B, +1, best_ps), rb_neg = pose_spread(B, -1, best_ps);
  int8_t best_rs = rb_pos <= rb_neg ? +1 : -1;

  MON.println();
  MON.println(F("--- KET QUA: huong mui lech toi da khi nghieng ---"));
  MON.print(F("  PITCH dau +1: ")); MON.print(pa_pos, 1); MON.print(F(" do     dau -1: "));
  MON.print(pa_neg, 1); MON.println(F(" do"));
  MON.print(F("  ROLL  dau +1: ")); MON.print(rb_pos, 1); MON.print(F(" do     dau -1: "));
  MON.print(rb_neg, 1); MON.println(F(" do"));
  MON.println();
  bool clear_p = fabsf(pa_pos - pa_neg) > 3.0f, clear_r = fabsf(rb_pos - rb_neg) > 3.0f;
  MON.println(F("=== CHEP DE VAO Config.h MUC [9] ==="));
  MON.print(F("#define MAG_ROLL_SIGN       (")); MON.print(best_rs > 0 ? "+1" : "-1"); MON.println(')');
  MON.print(F("#define MAG_PITCH_SIGN      (")); MON.print(best_ps > 0 ? "+1" : "-1"); MON.println(')');
  MON.println(F("===================================="));
  if (!clear_p || !clear_r)
    MON.println(F("Hai dau cho ket qua gan bang nhau (<3 do): quay mui dung huong, nghieng nhieu hon, lam lai."));
  float best = (best_ps > 0 ? pa_pos : pa_neg);
  float bestr = (best_rs > 0 ? rb_pos : rb_neg);
  if (best > 8 || bestr > 8)
    MON.println(F("Ca dau dung van lech > 8 do: nen calib lai la ban (code test M10, menu d w)."));
  if (best_ps != MAG_PITCH_SIGN || best_rs != MAG_ROLL_SIGN)
    MON.println(F("KHAC voi Config.h hien tai -> sua Config.h (va muc 1 file nay) roi nap lai code bay."));
  else MON.println(F("Trung voi Config.h hien tai -> khong can sua."));
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   21. MENU r - MAY THU ELRS
   =========================================================================*/

void stream_receiver() {
  MON.println();
  MON.println(F("--- MAY THU ELRS (bam phim bat ky de thoat) ---"));
  MON.println(F("Kiem thu tu kenh AETR:"));
  MON.println(F("  can roll sang PHAI -> R (CH1) TANG      can ga LEN -> T (CH3) TANG"));
  MON.println(F("  can pitch          -> P (CH2) doi       can yaw sang PHAI -> Y (CH4) TANG"));
  MON.println(F("  CH5 = ARM (>1500 = BAT),  CH7 = che do 3 nac"));
  MON.println(F("  Goi/giay la so lenh can dieu khien FC nhan duoc moi giay."));
  MON.println();
  uint32_t f0 = crsf_rc_frames, b0 = crsf_bytes, t0 = millis();
  uint32_t sum_rate = 0, n_rate = 0;
  while (true) {
    if (!wait_ms(500)) break;
    uint32_t dt = millis() - t0;
    float rate = (crsf_rc_frames - f0) * 1000.0f / dt;
    uint32_t bytes = crsf_bytes - b0;
    f0 = crsf_rc_frames; b0 = crsf_bytes; t0 = millis();
    if (rate > 0) { sum_rate += (uint32_t)rate; n_rate++; }

    if (bytes == 0) {
      MON.println(F("Khong nhan byte nao: bat tay cam? ELRS TX -> PA1? nguon 5V may thu?"));
      continue;
    }
    if (rate == 0) {
      MON.println(F("Co byte nhung khong co goi kenh: sai baud (420000) hoac chan may thu chua dat SERIAL."));
      continue;
    }
    MON.print(F("Goi/giay ")); MON.print((int)rate);
    if (link_seen) {
      MON.print(F("  LQ ")); MON.print(link_lq); MON.print(F("%  RSSI -"));
      MON.print(link_rssi1 > link_rssi2 && link_rssi2 ? link_rssi2 : link_rssi1); MON.print(F("dBm"));
    }
    MON.print(F("  CRC loi ")); MON.print(crsf_crc_err);
    MON.print(F(" | R ")); MON.print((int)rc[0]); MON.print(F(" P ")); MON.print((int)rc[1]);
    MON.print(F(" T ")); MON.print((int)rc[2]); MON.print(F(" Y ")); MON.print((int)rc[3]);
    MON.print(F(" | ARM ")); MON.print(arm_on() ? F("BAT") : F("tat"));
    float md = rc[MODE_CHANNEL];
    MON.print(F(" | ")); MON.print(md > MODE_THR_POS ? F("Giu vi tri") : md > MODE_THR_ALT ? F("Giu do cao") : F("Tu can bang"));
    MON.print(F(" | CH6 ")); MON.print((int)rc[5]); MON.print(F(" CH8 ")); MON.println((int)rc[7]);
  }
  if (n_rate) {
    uint32_t avg = sum_rate / n_rate;
    MON.println();
    MON.print(F("Trung binh ")); MON.print(avg); MON.println(F(" goi kenh/giay."));
    if (avg < 100) {
      MON.println(F("==> CHAM. Can phan ung tre. Vao ExpressLRS Lua tren tay cam:"));
      MON.println(F("    Packet Rate = 250Hz (hoac 150Hz), Telem Ratio = 1:8 hoac 1:16."));
    } else if (avg < 180) MON.println(F("==> Tam duoc. Muon nhay hon: Packet Rate 250Hz, Telem Ratio 1:8."));
    else MON.println(F("==> TOT."));
  }
}

/* ===========================================================================
   22. MENU g - GPS
   =========================================================================*/

void stream_gps() {
  MON.println();
  MON.println(F("--- GPS (bam phim bat ky de thoat) ---"));
  MON.println(F("Can ngoai troi. Code bay can fix 3D, >= 8 ve tinh va hAcc < 2.5m moi giu vi tri."));
  gps_config_pvt();
  uint32_t nm0 = gps_nmea_seen;
  uint32_t b0 = gps_bytes, v0 = gps_valid;
  while (true) {
    if (!wait_ms(1000)) break;
    uint32_t b = gps_bytes - b0, v = gps_valid - v0;
    b0 = gps_bytes; v0 = gps_valid;
    if (b == 0) { MON.println(F("Khong nhan byte nao: GPS TX -> PA10? nguon 5V?")); continue; }
    if (v == 0) { MON.println(F("Co byte nhung khong dung checksum: sai baud. Dung code test M10, menu l / x.")); continue; }
    if (gps_nmea_seen != nm0) { nm0 = gps_nmea_seen; gps_config_pvt(); }   // module van NMEA -> bat lai PVT
    if (millis() - gps_last_gga_ms > 1500) { MON.print(v); MON.println(F(" goi/giay nhung CHUA co NAV-PVT (dang bat...)")); continue; }
    MON.print(v); MON.print(F(" goi/giay  "));
    if (!gps_fix) { MON.print(F("CHUA fix  ve tinh ")); MON.println(gps_sats); continue; }
    bool ready = gps_sats >= 8 && gps_hacc < 2.5f;
    MON.print(F("Fix  ve tinh ")); MON.print(gps_sats);
    MON.print(F("  hAcc ")); MON.print(gps_hacc, 2);
    MON.print(F("m  pDOP ")); MON.print(gps_hdop, 2);
    MON.print(F("  vN ")); MON.print(gps_vn, 0); MON.print(F(" vE ")); MON.print(gps_ve, 0);
    MON.print(F("  ")); MON.print(gps_lat, 7); MON.print(F(", ")); MON.print(gps_lon, 7);
    MON.print(F("  cao ")); MON.print(gps_alt, 1); MON.print(F("m  "));
    MON.println(ready ? F("DU giu vi tri") : F("chua du giu vi tri"));
  }
}

/* ===========================================================================
   23. MENU 1-4 - QUAY TUNG MOTOR
   Theo bo tron cua code bay (FC_F405.ino):
       M1 = T - R - P - Y   truoc-phai, quay NGUOC chieu kim dong ho
       M2 = T - R + P + Y   sau-phai,   quay THUAN
       M3 = T + R + P - Y   sau-trai,   quay NGUOC
       M4 = T + R - P + Y   truoc-trai, quay THUAN
   (chieu nhin tu TREN xuong)
   =========================================================================*/

void print_motor_layout() {
  MON.println(F("            MUI (phia truoc)"));
  MON.println(F("     M4 thuan         M1 nguoc"));
  MON.println(F("           \\         /"));
  MON.println(F("            [  FC  ]"));
  MON.println(F("           /         \\"));
  MON.println(F("     M3 nguoc         M2 thuan"));
  MON.println(F("  (thuan / nguoc chieu kim dong ho, nhin tu TREN xuong)"));
}

void motor_single(uint8_t idx) {
  MON.println();
  MON.println(F("--- QUAY TUNG MOTOR THEO CAN GA ---"));
  print_motor_layout();
  if (!motor_prepare(false, NULL)) return;
  MON.println(F("Day CAN GA len tu tu: CHI motor duoc chon quay, toc do theo can ga."));
  MON.print(F("Ga toi da trong bai nay: ")); MON.print(MOTOR_FOLLOW_MAX); MON.println(F(" us."));
  MON.println(F("Dang quay: bam 1 2 3 4 de DOI motor, phim khac de DUNG."));
  MON.println(F("Tat cong tac ARM / mat song -> dung ngay."));
  MON.println();

  uint8_t r = 0;
  uint32_t last = 0;
  bool announce = true;
  while (true) {
    service();
    // Phim: 1-4 doi motor, phim khac dung
    if (MON.available() > 0) {
      char c = MON.read();
      delay(20);
      while (MON.available() > 0) MON.read();
      if (c >= '1' && c <= '4') {
        motors_off();
        idx = c - '1';
        announce = true;
        delay(200);
      } else { r = 1; break; }
    }
#if MOTOR_NEED_RADIO
    if (!radio_ok()) { r = 2; break; }
    if (!arm_on())   { r = 3; break; }
#endif
    if (announce) {
      announce = false;
      MON.print(F(">> MOTOR ")); MON.print(idx + 1); MON.print(F(": phai la goc "));
      MON.print(MOTOR_POS[idx]); MON.print(F(", quay ")); MON.println(MOTOR_DIR[idx]);
    }
    uint16_t us = (uint16_t)constrain(rc[2], 1000, MOTOR_FOLLOW_MAX);
    for (uint8_t i = 0; i < 4; i++) motor_us[i] = 1000;
    motor_us[idx] = us;
    motors_write();
    if (millis() - last > 400) {
      last = millis();
      MON.print(F("   M")); MON.print(idx + 1); MON.print(F(" ga ")); MON.print(us);
      MON.println(F(" us"));
    }
  }
  motors_off();
  print_stop_reason(r);
  MON.println(F("Da tat."));
  MON.println(F("  SAI VI TRI (motor khac quay): doi day tin hieu ESC tren PC6..PC9 cho dung."));
  MON.println(F("  SAI CHIEU: dao 2 trong 3 day motor, hoac dao chieu trong BLHeli."));
  MON.println(F("  Motor khong quay nhung ESC keu: ESC chua nhan hanh trinh ga -> menu e."));
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   24. MENU m - CA 4 MOTOR THEO CAN GA
   =========================================================================*/

void motor_follow() {
  MON.println();
  MON.println(F("--- CA 4 MOTOR THEO CAN GA ---"));
  MON.println(F("Tang ga THAT CHAM tu duoi cung. Ca 4 motor phai bat dau quay CUNG LUC"));
  MON.println(F("va nghe deu nhau. Mot motor quay muon / giat -> hieu chuan ESC (menu e)."));
  MON.print(F("Gioi han ga trong bai nay: ")); MON.print(MOTOR_FOLLOW_MAX); MON.println(F(" us."));
  if (!motor_prepare(false, NULL)) return;
  uint32_t last = 0;
  uint8_t r = 0;
  while (true) {
    r = motor_stop_reason();
    if (r) break;
    uint16_t us = (uint16_t)constrain(rc[2], 1000, MOTOR_FOLLOW_MAX);
    motors_set_all(us);
    if (millis() - last > 300) {
      last = millis();
      MON.print(F("Ga ")); MON.print(us); MON.println(F(" us"));
    }
  }
  print_stop_reason(r);
  MON.println(F("Da tat. Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   25. MENU v - DO RUNG
   Doc con quay + gia toc o 1000 lan/giay voi bo loc RONG (khong dung bo
   loc 10Hz cua code bay) de thay rung that. Moi muc ga: RMS 3 truc con
   quay, RMS gia toc, tan so rung manh nhat (FFT 512 diem, ~2 Hz/o).
   =========================================================================*/

#define VN 512
static float   v_re[VN], v_im[VN];
static int16_t v_gx[VN], v_gy[VN];

void fft512(float *re, float *im) {
  // dao bit
  for (uint16_t i = 1, j = 0; i < VN; i++) {
    uint16_t bit = VN >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { float t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
  }
  for (uint16_t len = 2; len <= VN; len <<= 1) {
    float ang = -2.0f * PI / len;
    float wr = cosf(ang), wi = sinf(ang);
    for (uint16_t i = 0; i < VN; i += len) {
      float cr = 1, ci = 0;
      for (uint16_t k = 0; k < len / 2; k++) {
        uint16_t a = i + k, b = i + k + len / 2;
        float xr = re[b] * cr - im[b] * ci, xi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - xr; im[b] = im[a] - xi;
        re[a] += xr; im[a] += xi;
        float ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
}

// Pho bien do cong don cua con quay roll + pitch (da tru trung binh, cua so Hann)
static float v_mag[VN / 2];

void vibe_add_spectrum(const int16_t *x) {
  float mean = 0;
  for (uint16_t i = 0; i < VN; i++) mean += x[i];
  mean /= VN;
  for (uint16_t i = 0; i < VN; i++) {
    float w = 0.5f * (1.0f - cosf(2.0f * PI * i / (VN - 1)));
    v_re[i] = (x[i] - mean) / 65.5f * w;
    v_im[i] = 0;
  }
  fft512(v_re, v_im);
  for (uint16_t k = 0; k < VN / 2; k++)
    v_mag[k] += sqrtf(v_re[k] * v_re[k] + v_im[k] * v_im[k]) * 4.0f / VN;   // bien do do/s
}

// Lay mau 512 diem o 1kHz. Tra ve ly do dung motor (0 = xong)
uint8_t vibe_sample(Vibe *v) {
  float sg[3] = {0}, sg2[3] = {0}, sa[3] = {0}, sa2[3] = {0};
  uint8_t b[14];
  uint32_t next = micros();
  for (uint16_t i = 0; i < VN; i++) {
    while ((int32_t)(micros() - next) < 0) { }
    next += 1000;
    icm_burst(REG_ACCEL_XOUT_H, b, 14);
    int16_t raw[7];
    for (uint8_t k = 0; k < 7; k++) raw[k] = (int16_t)((b[2 * k] << 8) | b[2 * k + 1]);
    for (uint8_t k = 0; k < 3; k++) {
      float a = raw[k] / 4096.0f, g = raw[4 + k] / 65.5f;
      sa[k] += a; sa2[k] += a * a; sg[k] += g; sg2[k] += g * g;
    }
    v_gx[i] = raw[4]; v_gy[i] = raw[5];
    uint8_t r = motor_stop_reason();
    if (r) return r;
  }
  for (uint8_t k = 0; k < 3; k++) v->g[k] = stddev(sg[k], sg2[k], VN);
  float ax = stddev(sa[0], sa2[0], VN), ay = stddev(sa[1], sa2[1], VN), az = stddev(sa[2], sa2[2], VN);
  v->a = sqrtf(ax * ax + ay * ay + az * az);

  for (uint16_t k = 0; k < VN / 2; k++) v_mag[k] = 0;
  vibe_add_spectrum(v_gx);
  vibe_add_spectrum(v_gy);
  v->peak_hz = 0; v->peak_amp = 0;
  for (uint16_t k = 10; k < VN / 2; k++)             // tu ~20 Hz tro len
    if (v_mag[k] > v->peak_amp) { v->peak_amp = v_mag[k]; v->peak_hz = k * 1000.0f / VN; }
  return 0;
}

void vibe_print(const __FlashStringHelper *label, uint16_t us, const Vibe *v) {
  MON.print(label); MON.print(us);
  MON.print(F(" | con quay RMS  R ")); MON.print(v->g[0], 1);
  MON.print(F("  P ")); MON.print(v->g[1], 1); MON.print(F("  Y ")); MON.print(v->g[2], 1);
  MON.print(F(" do/s | gia toc RMS ")); MON.print(v->a, 2);
  MON.print(F(" g | dinh ")); MON.print(v->peak_hz, 0); MON.print(F(" Hz ("));
  MON.print(v->peak_amp, 1); MON.println(F(" do/s)"));
}

void vibration_test() {
  if (!need_imu()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- DO RUNG ---"));
  MON.println(F("KHONG canh: tim motor cong truc / ho vong bi / oc long, mach bi chan rung kem."));
  MON.println(F("CO canh (drone BUOC CHAT xuong): thay rung that khi bay, gom ca canh mat can bang."));
  bool props = false;
  if (!motor_prepare(true, &props)) return;

  const uint16_t steps_np[5] = { 1000, 1150, 1300, 1450, 1600 };
  const uint16_t steps_p[5]  = { 1000, 1100, 1150, 1200, 1250 };
  const uint16_t *steps = props ? steps_p : steps_np;
  const uint16_t single_us = props ? 1150 : 1300;

  imu_config_wide();
  Vibe res[5], mres[4];
  uint16_t cur = 1000;
  uint8_t r = 0;

  MON.println(F("Phan 1: ca 4 motor, tang dan ga (1000 = motor tat, nhieu nen)"));
  for (uint8_t s = 0; s < 5 && !r; s++) {
    r = motor_ramp(255, cur, steps[s], 400); cur = steps[s];
    if (!r) r = motor_hold(800);
    if (!r) r = vibe_sample(&res[s]);
    if (!r) vibe_print(F("  Ga "), steps[s], &res[s]);
  }
  if (!r) r = motor_ramp(255, cur, 1000, 300);
  cur = 1000;

  if (!r) {
    MON.print(F("Phan 2: tung motor mot, ga ")); MON.println(single_us);
    for (uint8_t m = 0; m < 4 && !r; m++) {
      r = motor_ramp(m, 1000, single_us, 400);
      if (!r) r = motor_hold(700);
      if (!r) r = vibe_sample(&mres[m]);
      motor_us[m] = 1000; motors_write();
      if (!r) {
        MON.print(F("  M")); MON.print(m + 1);
        vibe_print(F(" ga "), single_us, &mres[m]);
        if (!r) r = motor_hold(400);
      }
    }
  }
  motors_off();
  imu_config_flight();
  if (r) { print_stop_reason(r); MON.println(F("Bam phim de ve menu.")); wait_key(); return; }

  // Danh gia
  MON.println();
  float worst_a = 0; uint8_t worst_s = 0;
  for (uint8_t s = 1; s < 5; s++) if (res[s].a > worst_a) { worst_a = res[s].a; worst_s = s; }
  float lim_ok = props ? 0.5f : 0.15f, lim_bad = props ? 1.0f : 0.4f;
  MON.print(F("Rung manh nhat khi ca 4 motor: ")); MON.print(worst_a, 2); MON.print(F(" g o ga "));
  MON.print(steps[worst_s]); MON.print(F(", tan so ~")); MON.print(res[worst_s].peak_hz, 0); MON.println(F(" Hz"));
  if (worst_a < lim_ok) MON.println(F("==> TOT."));
  else if (worst_a < lim_bad) MON.println(F("==> TRUNG BINH. Nen kiem tra dem chong rung mach, oc motor."));
  else MON.println(F("==> RUNG MANH. Can xu ly truoc khi bay (xem motor rung nhat ben duoi)."));

  float sum = 0, mxa = 0; uint8_t mi = 0;
  for (uint8_t m = 0; m < 4; m++) { sum += mres[m].a; if (mres[m].a > mxa) { mxa = mres[m].a; mi = m; } }
  float others = (sum - mxa) / 3.0f;
  if (others > 0 && mxa > 1.5f * others && mxa > lim_ok * 0.5f) {
    MON.print(F("Motor M")); MON.print(mi + 1); MON.print(F(" (")); MON.print(MOTOR_POS[mi]);
    MON.println(F(") rung gap ruoi cac motor khac:"));
    MON.println(props ? F("  kiem canh motor do (nut, mat can bang), roi truc va oc motor.")
                      : F("  kiem truc motor co cong, vong bi, oc bat motor, chuong motor bi co."));
  } else MON.println(F("Bon motor rung gan nhu nhau: khong co motor nao hong rieng."));

  MON.println();
  MON.println(F("Ghi chu cho bo loc code bay: chip dang loc 10 Hz (REG_CONFIG 0x05) va EMA"));
  MON.println(F("0.15 (~6 Hz) -> tre ~40 ms, lam drone cham va de lac. Rung o day tren ~80 Hz"));
  MON.println(F("va nho thi co the noi bo loc de drone nhay hon. Gui ket qua nay de chinh."));
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   26. MENU x - ANH HUONG DONG MOTOR LEN LA BAN
   Dong dien chay qua day nguon sinh tu truong -> huong la ban lech theo
   ga. Lech nhieu thi giu huong se keo yaw qua lai (lac cheo).
   =========================================================================*/

bool mag_avg_guarded(uint8_t n, float *m, float *roll, float *pitch, uint8_t *reason) {
  float s[3] = {0, 0, 0}, sr = 0, sp = 0, c[3];
  uint8_t got = 0;
  *reason = 0;
  for (uint8_t i = 0; i < n; i++) {
    *reason = motor_stop_reason();
    if (*reason) return false;
    if (!mag_read_raw()) continue;
    mag_apply_cal(c);
    imu_read(); sr += angle_roll; sp += angle_pitch;
    for (uint8_t k = 0; k < 3; k++) s[k] += c[k];
    got++;
  }
  if (got < n / 2) return false;
  for (uint8_t k = 0; k < 3; k++) m[k] = s[k] / got;
  *roll = sr / got; *pitch = sp / got;
  return true;
}

void motor_mag_interference() {
  if (!need_mag() || !need_imu()) { wait_key(); return; }
  MON.println();
  MON.println(F("--- ANH HUONG MOTOR LEN LA BAN ---"));
  MON.println(F("De drone NAM YEN tren ban (khong phai ban sat), khong dich day nguon."));
  MON.println(F("KHONG canh: dong dien chi ~1 A nen so lech NHO hon luc bay (10-20 A)."));
  bool props = false;
  if (!motor_prepare(true, &props)) return;

  float m0[3], r0, p0; uint8_t r = 0;
  MON.println(F("Do luc motor TAT..."));
  if (!mag_avg_guarded(30, m0, &r0, &p0, &r)) {
    if (r) print_stop_reason(r); else MON.println(F("Doc la ban loi."));
    wait_key(); return;
  }
  float h0 = mag_heading(m0, r0, p0, MAG_ROLL_SIGN, MAG_PITCH_SIGN);
  float f0 = sqrtf(m0[0] * m0[0] + m0[1] * m0[1] + m0[2] * m0[2]);
  MON.print(F("  Motor tat: huong ")); MON.print(h0, 1); MON.print(F(" do  |M| ")); MON.println(f0, 1);

  const uint16_t steps_np[4] = { 1150, 1300, 1450, 1600 };
  const uint16_t steps_p[4]  = { 1100, 1150, 1200, 1250 };
  const uint16_t *steps = props ? steps_p : steps_np;
  uint16_t cur = 1000;
  float worst = 0;
  for (uint8_t s = 0; s < 4 && !r; s++) {
    r = motor_ramp(255, cur, steps[s], 400); cur = steps[s];
    if (!r) r = motor_hold(1000);
    float m[3], rr, pp;
    if (!r && mag_avg_guarded(20, m, &rr, &pp, &r)) {
      float h = mag_heading(m, rr, pp, MAG_ROLL_SIGN, MAG_PITCH_SIGN);
      float f = sqrtf(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
      float dh = ang_diff(h, h0);
      if (fabsf(dh) > worst) worst = fabsf(dh);
      MON.print(F("  Ga ")); MON.print(steps[s]); MON.print(F(": huong ")); MON.print(h, 1);
      MON.print(F(" do  lech ")); if (dh >= 0) MON.print('+'); MON.print(dh, 1);
      MON.print(F(" do   |M| ")); MON.print(f, 1); MON.print(F(" (")); MON.print((f - f0) * 100.0f / f0, 1);
      MON.println(F("%)"));
    }
  }
  if (!r) r = motor_ramp(255, cur, 1000, 300);
  motors_off();
  if (r) { print_stop_reason(r); MON.println(F("Bam phim de ve menu.")); wait_key(); return; }

  float m1[3], r1, p1;
  if (mag_avg_guarded(20, m1, &r1, &p1, &r)) {
    float dh = ang_diff(mag_heading(m1, r1, p1, MAG_ROLL_SIGN, MAG_PITCH_SIGN), h0);
    MON.print(F("  Motor tat lai: lech ")); MON.print(dh, 1); MON.println(F(" do (phai ~0, neu khong la drone bi xe dich)"));
  }

  MON.println();
  MON.print(F("Lech lon nhat: ")); MON.print(worst, 1); MON.println(F(" do"));
  float ok_lim = props ? 2.0f : 0.5f, bad_lim = props ? 5.0f : 2.0f;
  if (worst < ok_lim) MON.println(F("==> TOT. Dong motor anh huong it."));
  else if (worst < bad_lim) {
    MON.println(F("==> DANG LO. Khi bay (dong lon hon) co the lech vai do."));
    MON.println(F("    Xoan doi day nguon, dua la ban cao / xa day nguon va ESC hon."));
  } else {
    MON.println(F("==> NANG. Giu huong se keo yaw qua lai (lac cheo). Phai doi cho la ban:"));
    MON.println(F("    len cot cao 10-15 cm, xa day pin, ESC, dau cam XT60."));
  }
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   27. MENU e - HIEU CHUAN HANH TRINH GA ESC
   ESC PWM thuong: cap nguon khi tin hieu 2000us -> ESC ghi nho muc toi da,
   ha xuong 1000us -> ghi nho muc toi thieu.
   =========================================================================*/

void esc_calibrate() {
  MON.println();
  MON.println(F("--- HIEU CHUAN HANH TRINH GA ESC ---"));
  MON.println(F("!!! THAO HET CANH. RUT PIN RA (chi cam USB). !!!"));
  MON.println(F("Gui 'y' khi DA THAO CANH VA DA RUT PIN, phim khac = huy."));
  if (wait_key() != 'y') { MON.println(F("Da huy.")); return; }
  motors_set_all(2000);
  MON.println(F("Dang xuat 2000 us (ga toi da) ra ca 4 ESC."));
  MON.println(F("BAY GIO CAM PIN. Cho ESC keu nhac + 2 tieng bip (vai giay),"));
  MON.println(F("roi bam phim bat ky. (Neu motor QUAY: bam phim NGAY, ESC nay khong"));
  MON.println(F("co che do hieu chuan - rut pin.)"));
  wait_key();
  motors_set_all(1000);
  MON.println(F("Dang xuat 1000 us (ga thap nhat). ESC se keu xac nhan (nhieu tieng bip)."));
  wait_ms(4000);
  MON.println(F("Xong. Rut pin, cam lai, roi thu menu m: ca 4 motor phai bat dau quay cung luc."));
  MON.println(F("Bam phim de ve menu."));
  wait_key();
}

/* ===========================================================================
   28. BANG MENU
   =========================================================================*/

void run_menu(char c) {
  switch (c) {
    case 's': test_quick_all();        break;
    case 'k': test_timing();           break;
    case 'l': test_leds();             break;
    case 'i': test_imu();              break;
    case 'p': stream_attitude();       break;
    case 'y': imu_axis_wizard();       break;
    case 'z': calib_acc_offset();      break;
    case 'b': test_baro();             break;
    case 'h': stream_altitude();       break;
    case 'c': stream_heading();        break;
    case 'n': mag_tilt_sign_wizard();  break;
    case 'r': stream_receiver();       break;
    case 'g': stream_gps();            break;
    case '1': case '2': case '3': case '4': motor_single(c - '1'); break;
    case 'm': motor_follow();          break;
    case 'v': vibration_test();        break;
    case 'x': motor_mag_interference(); break;
    case 'e': esc_calibrate();         break;
    default: break;
  }
}
