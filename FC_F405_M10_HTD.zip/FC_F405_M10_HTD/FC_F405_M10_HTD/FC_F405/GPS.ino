/* =====================================================================
 *  TAB GPS — u-blox M10 (GEPRC GEP-M10) tren USART1 (PA9/PA10)
 *  Doc goi NHI PHAN UBX-NAV-PVT (class 0x01, id 0x07), khong doc NMEA.
 *
 *  VI SAO NAV-PVT THAY CHO NMEA (GGA + RMC)
 *    - Co san van toc Bac/Dong (velN, velE) tu Doppler, KE CA khi drone
 *      gan nhu dung yen. RMC thi bo trong huong khi di cham -> truoc day
 *      phai coi van toc = 0 dung luc giu vi tri can no nhat.
 *    - So ve tinh that (numSV), khong bi chan o 12 nhu cau GGA.
 *    - hAcc: sai so vi tri ngang tinh bang MET, do tin cay truc tiep hon HDOP.
 *    - Mot goi nhi phan 100 byte, kiem bang checksum Fletcher-8.
 *  Vi tri cac truong theo "u-blox M10 SPG 5.10 Interface Description",
 *  muc UBX-NAV-PVT (tham khao driver gps_ubx.ino, viet lai cho STM32).
 *
 *  Module mac dinh phat NMEA. Moi lan khoi dong, FC gui CFG-VALSET bat
 *  NAV-PVT va tat NMEA, CHI ghi vao RAM: rut dien cam lai, module quay ve
 *  cau hinh da luu (NMEA) nen code test F405_IST8310_M10_test van doc duoc.
 *
 *  NGUYEN TAC: gpsUpdate() moi vong chi doc toi da GPS_MAX_BYTES byte, tra
 *  ve nhanh. NAV-PVT 10 lan/giay = ~1000 byte/giay = ~4 byte moi vong 4ms.
 * =====================================================================
 */

HardwareSerial GpsSerial(PIN_GPS_RX, PIN_GPS_TX);

#define GPS_MAX_BYTES   48
#define GPS_BUF_LEN     100      // dong NMEA (chi dung khi do baud)
#define UBX_PVT_LEN     92
#define UBX_PAYLOAD_MAX 100

// Van toc tu NAV-PVT (cm/s) va thoi diem co mau moi
float    GpsVelNorthCms = 0, GpsVelEastCms = 0;
uint32_t GpsVelMs = 0;
float    GpsHaccM = 99.0f;       // sai so vi tri ngang (m)

static char     gpsBuf[GPS_BUF_LEN];
static uint8_t  gpsIdx = 0;

// Trang thai gom diem goc
static double   homeLatSum = 0, homeLonSum = 0;
static uint16_t homeCount  = 0;

/* Vi tri ban tin truoc, de chan buoc nhay. Tien to gps_ vi Arduino ghep
 * moi tab thanh mot file (NavControl.ino da co lastPosN/lastPosE). */
static float    gpsPrevPosN = 0, gpsPrevPosE = 0;
static bool     gpsPrevPosValid = false;

// ---------------------------------------------------------------------
//  Kiem checksum NMEA (chi dung luc DO BAUD: module chua cau hinh thi phat NMEA)
// ---------------------------------------------------------------------
static int8_t gpsHexVal(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}
static bool gpsChecksumOk(const char *s) {
  if (s[0] != '$') return false;
  uint8_t sum = 0, i = 1;
  while (s[i] && s[i] != '*') { sum ^= (uint8_t)s[i]; if (++i >= GPS_BUF_LEN - 3) return false; }
  if (s[i] != '*') return false;
  int8_t hi = gpsHexVal(s[i + 1]), lo = gpsHexVal(s[i + 2]);
  return hi >= 0 && lo >= 0 && sum == (uint8_t)((hi << 4) | lo);
}

/* =====================================================================
 *  BO TACH GOI UBX (may trang thai)
 * ===================================================================== */
enum { U_SYNC1, U_SYNC2, U_CLASS, U_ID, U_LEN1, U_LEN2, U_PAYLOAD, U_CKA, U_CKB };
static uint8_t  ubxState = U_SYNC1;
static uint8_t  ubxClass, ubxId, ubxCkA, ubxCkB, ubxCkARx;
static uint16_t ubxLen, ubxIdx;
static uint8_t  ubxPayload[UBX_PAYLOAD_MAX];
static bool     ubxSkip = false;          // goi qua dai: van dem byte nhung khong luu

static void ubxCk(uint8_t b) { ubxCkA += b; ubxCkB += ubxCkA; }

static int32_t ubxI4(uint8_t o) {
  return (int32_t)((uint32_t)ubxPayload[o] | ((uint32_t)ubxPayload[o + 1] << 8) |
                   ((uint32_t)ubxPayload[o + 2] << 16) | ((uint32_t)ubxPayload[o + 3] << 24));
}

void gpsSetHome(void);
void gpsUpdatePosition(void);

/* Phan tich NAV-PVT. Offset theo tai lieu u-blox (byte trong payload):
 *   20 fixType  21 flags(bit0 gnssFixOK)  23 numSV  24 lon  28 lat
 *   36 hMSL(mm)  40 hAcc(mm)  48 velN  52 velE (mm/s)  76 pDOP(x0.01) */
static void gpsParsePvt(void) {
  uint8_t fixType = ubxPayload[20];
  bool    fixOk   = (ubxPayload[21] & 0x01) && (fixType == 3 || fixType == 4);  // 3D hoac 3D+DR

  GpsFixType  = fixOk ? fixType : 0;
  GpsSatCount = ubxPayload[23];
  GpsHaccM    = (float)(uint32_t)ubxI4(40) * 0.001f;
  GpsHdop     = (float)((uint16_t)ubxPayload[76] | ((uint16_t)ubxPayload[77] << 8)) * 0.01f;  // PDOP
  GpsAltitude = ubxI4(36) * 0.001f;

  GpsVelNorthCms = ubxI4(48) * 0.1f;     // mm/s -> cm/s
  GpsVelEastCms  = ubxI4(52) * 0.1f;
  GpsVelMs       = millis();

  if (!fixOk) return;
  GpsLatitude  = ubxI4(28) * 1e-7;
  GpsLongitude = ubxI4(24) * 1e-7;
  GpsLastFixMs = millis();

  // Suc khoe tinh TRUOC khi chot home (gpsSetHome doi GpsHealthy)
  GpsHealthy = (GpsSatCount >= GPS_MIN_SATS) && (GpsHaccM < GPS_MAX_HACC_M);
  gpsSetHome();
  gpsUpdatePosition();
}

/* Nap MOT byte. Tra ve 1 = vua xong mot dong NMEA hop le,
 * 2 = vua xong mot goi UBX hop le (bat ky loai), 0 = chua.
 * parse = true: phan tich NAV-PVT (luc bay). */
static uint8_t gpsFeed(uint8_t c, bool parse) {
  uint8_t res = 0;

  // --- NMEA (chi de nhan ra dung baud luc module chua cau hinh) ---
  if (c == '$') { gpsIdx = 0; gpsBuf[gpsIdx++] = c; }
  else if (gpsIdx > 0) {
    if (c == '\r' || c == '\n') {
      gpsBuf[gpsIdx] = 0; gpsIdx = 0;
      if (gpsChecksumOk(gpsBuf)) res = 1;
    } else if (gpsIdx < GPS_BUF_LEN - 1) gpsBuf[gpsIdx++] = c;
    else gpsIdx = 0;
  }

  // --- UBX ---
  switch (ubxState) {
    case U_SYNC1: if (c == 0xB5) ubxState = U_SYNC2; break;
    case U_SYNC2: ubxState = (c == 0x62) ? U_CLASS : U_SYNC1; break;
    case U_CLASS: ubxClass = c; ubxCkA = ubxCkB = 0; ubxCk(c); ubxState = U_ID; break;
    case U_ID:    ubxId = c; ubxCk(c); ubxState = U_LEN1; break;
    case U_LEN1:  ubxLen = c; ubxCk(c); ubxState = U_LEN2; break;
    case U_LEN2:
      ubxLen |= (uint16_t)c << 8; ubxCk(c);
      if (ubxLen > 1024) { ubxState = U_SYNC1; break; }      // rac
      ubxSkip = (ubxLen > UBX_PAYLOAD_MAX);
      ubxIdx = 0;
      ubxState = (ubxLen == 0) ? U_CKA : U_PAYLOAD;
      break;
    case U_PAYLOAD:
      if (!ubxSkip) ubxPayload[ubxIdx] = c;
      ubxIdx++; ubxCk(c);
      if (ubxIdx >= ubxLen) ubxState = U_CKA;
      break;
    case U_CKA:   ubxCkARx = c; ubxState = U_CKB; break;
    case U_CKB:
      ubxState = U_SYNC1;
      if (ubxCkARx == ubxCkA && c == ubxCkB) {
        res = 2;
        if (parse && !ubxSkip && ubxClass == 0x01 && ubxId == 0x07 && ubxLen == UBX_PVT_LEN)
          gpsParsePvt();
      }
      break;
  }
  return res;
}

// Nghe toi da ms mili-giay, true khi nhan du 2 dong NMEA / goi UBX hop le
static bool gpsListen(uint16_t ms) {
  uint32_t t0 = millis();
  uint8_t  valid = 0;
  gpsIdx = 0; ubxState = U_SYNC1;
  while (millis() - t0 < ms) {
    while (GpsSerial.available()) {
      if (gpsFeed(GpsSerial.read(), false)) valid++;
      if (valid >= 2) return true;
    }
  }
  return false;
}

/* =====================================================================
 *  CAU HINH MODULE (CFG-VALSET, chi ghi RAM)
 * ===================================================================== */
static void gpsSendUbx(uint8_t cls, uint8_t id, const uint8_t *p, uint16_t len) {
  uint8_t h[6] = { 0xB5, 0x62, cls, id, (uint8_t)(len & 0xFF), (uint8_t)(len >> 8) };
  uint8_t a = 0, b = 0;
  for (uint8_t i = 2; i < 6; i++) { a += h[i]; b += a; }
  for (uint16_t i = 0; i < len; i++) { a += p[i]; b += a; }
  GpsSerial.write(h, 6);
  if (len) GpsSerial.write(p, len);
  GpsSerial.write(a);
  GpsSerial.write(b);
  GpsSerial.flush();
  delay(120);
}

#define UBX_KEY_UART1_BAUD     0x40520001UL
#define UBX_KEY_RATE_MEAS      0x30210001UL
#define UBX_KEY_RATE_NAV       0x30210002UL
#define UBX_KEY_DYNMODEL       0x20110021UL
#define UBX_KEY_OUTPROT_UBX    0x10740001UL   // UART1 phat UBX
#define UBX_KEY_OUTPROT_NMEA   0x10740002UL   // UART1 phat NMEA
#define UBX_KEY_PVT_UART1      0x20910007UL   // CFG-MSGOUT-UBX_NAV_PVT_UART1

static void gpsValset(uint8_t layers, const uint32_t *keys, const uint32_t *vals, uint8_t n) {
  uint8_t p[4 + 12 * 8];
  uint16_t len = 4;
  p[0] = 0; p[1] = layers; p[2] = 0; p[3] = 0;
  for (uint8_t k = 0; k < n && len + 8 <= sizeof(p); k++) {
    for (uint8_t i = 0; i < 4; i++) p[len++] = (uint8_t)(keys[k] >> (8 * i));
    uint8_t sz = (keys[k] >> 28) & 0x07;
    uint8_t nb = (sz == 3) ? 2 : (sz == 4) ? 4 : 1;
    for (uint8_t i = 0; i < nb; i++) p[len++] = (uint8_t)(vals[k] >> (8 * i));
  }
  gpsSendUbx(0x06, 0x8A, p, len);
}

/* Bat NAV-PVT moi chu ky, tat het NMEA, GPS_RATE_HZ, kieu chuyen dong bay.
 * changeBaud = module dang o toc do khac GPS_BAUD. Lop 0x01 = CHI RAM. */
static void gpsConfigure(bool changeBaud) {
  static const uint32_t K[] = {
    UBX_KEY_OUTPROT_UBX, UBX_KEY_OUTPROT_NMEA, UBX_KEY_PVT_UART1,
    UBX_KEY_RATE_MEAS, UBX_KEY_RATE_NAV, UBX_KEY_DYNMODEL };
  const uint32_t V[] = { 1, 0, 1, 1000 / GPS_RATE_HZ, 1, GPS_DYN_MODEL };
  gpsValset(0x01, K, V, sizeof(K) / sizeof(K[0]));

  if (changeBaud) {
    const uint32_t kb = UBX_KEY_UART1_BAUD, vb = GPS_BAUD;
    gpsValset(0x01, &kb, &vb, 1);
    GpsSerial.end();
    GpsSerial.begin(GPS_BAUD);
    delay(300);
  }
  gpsIdx = 0; ubxState = U_SYNC1;
}

void gpsInit(void) {
  gpsIdx          = 0;
  ubxState        = U_SYNC1;
  GpsHealthy      = false;
  homeLatSum      = homeLonSum = 0;
  homeCount       = 0;
  gpsPrevPosValid = false;
  GpsBaudOk       = false;

  GpsSerial.begin(GPS_BAUD);
  delay(100);
  if (gpsListen(1200)) {
    gpsConfigure(false);
    GpsBaudOk = true;
    return;
  }
  // Khong thay: gpsUpdate() tu do cac toc do khac khi CHUA ARM, khong chan.
}

/* ---------------------------------------------------------------------
 *  Doi kinh vi do sang toa do phang (cm) so voi diem goc.
 *    1 do vi do = 111320 m;  1 do kinh do = 111320 m * cos(vi do)
 * ------------------------------------------------------------------- */
void gpsUpdatePosition(void) {
  if (!HomeSet) return;

  float n = (float)((GpsLatitude  - HomeLatitude)  * 11132000.0);
  float e = (float)((GpsLongitude - HomeLongitude) * 11132000.0 * LonScale);

  // ---- Chan buoc nhay vo ly ----
  if (gpsPrevPosValid) {
    float dn = n - gpsPrevPosN, de = e - gpsPrevPosE;
    if (dn * dn + de * de > GPS_JUMP_MAX_CM * GPS_JUMP_MAX_CM) {
      // Ban tin nay nhay qua xa. Bo qua, giu vi tri cu.
      // Neu nhay that (GPS vua bat lai fix), lan sau se dong bo lai.
      gpsPrevPosValid = false;
      return;
    }
  }

  PosNorthCm = n;
  PosEastCm  = e;
  gpsPrevPosN = n; gpsPrevPosE = e;
  gpsPrevPosValid = true;
}

/* ---------------------------------------------------------------------
 *  Chot diem goc: trung binh HOME_SAMPLES mau khi GPS khoe.
 * ------------------------------------------------------------------- */
void gpsSetHome(void) {
  if (HomeSet) return;

  if (!GpsHealthy) {                      // fix chua du tot -> gom lai tu dau
    homeLatSum = homeLonSum = 0;
    homeCount  = 0;
    return;
  }

  homeLatSum += GpsLatitude;
  homeLonSum += GpsLongitude;
  homeCount++;
  if (homeCount < HOME_SAMPLES) return;

  HomeLatitude  = homeLatSum / homeCount;
  HomeLongitude = homeLonSum / homeCount;
  LonScale      = cos(HomeLatitude * 0.0174533);
  PosNorthCm    = 0;
  PosEastCm     = 0;
  gpsPrevPosN      = 0;
  gpsPrevPosE      = 0;
  gpsPrevPosValid  = true;
  HomeSet       = true;
}

/* ---------------------------------------------------------------------
 *  TU DO LAI GPS KHI CHUA ARM (khong chan). Nhan ra ca NMEA (module
 *  vua bat, chua cau hinh) lan UBX (da cau hinh). Da arm thi KHONG do.
 * ------------------------------------------------------------------- */
#define GPS_PROBE_MS  1200
static const uint32_t GPS_PROBE_BAUDS[] = { GPS_BAUD, 38400, 115200, 9600, 57600 };
#define GPS_PROBE_N  (sizeof(GPS_PROBE_BAUDS) / sizeof(GPS_PROBE_BAUDS[0]))

static uint8_t  gpsProbeBaudIdx = 0;
static uint32_t gpsProbeT0      = 0;
static uint8_t  gpsProbeValid   = 0;

static void gpsProbe(void) {
  if (gpsProbeT0 == 0) gpsProbeT0 = millis();
  uint8_t n = 0;
  while (GpsSerial.available() && n < GPS_MAX_BYTES) {
    if (gpsFeed(GpsSerial.read(), false)) gpsProbeValid++;
    n++;
  }
  if (gpsProbeValid >= 2) {
    if (gpsProbeBaudIdx == 0) {
      DBG_PRINTLN(F("GPS: tim thay o GPS_BAUD -> gui cau hinh bay"));
      gpsConfigure(false);
      GpsBaudOk = true;
    } else {
      DBG_PRINT(F("GPS: tim thay o ")); DBG_PRINT(GPS_PROBE_BAUDS[gpsProbeBaudIdx]);
      DBG_PRINTLN(F(" -> doi sang GPS_BAUD"));
      gpsConfigure(true);
      GpsBaudOk = gpsListen(1200);
      if (!GpsBaudOk) { GpsSerial.end(); GpsSerial.begin(GPS_BAUD); }
      gpsProbeBaudIdx = 0;
    }
    gpsProbeValid = 0;
    gpsProbeT0 = 0;
    return;
  }
  if (millis() - gpsProbeT0 >= GPS_PROBE_MS) {
    do {
      gpsProbeBaudIdx = (gpsProbeBaudIdx + 1) % GPS_PROBE_N;
    } while (gpsProbeBaudIdx != 0 && GPS_PROBE_BAUDS[gpsProbeBaudIdx] == GPS_BAUD);
    GpsSerial.end();
    GpsSerial.begin(GPS_PROBE_BAUDS[gpsProbeBaudIdx]);
    gpsProbeValid = 0;
    gpsIdx = 0; ubxState = U_SYNC1;
    gpsProbeT0 = millis();
  }
}

// ---------------------------------------------------------------------
//  Goi moi vong lap. Doc toi da GPS_MAX_BYTES byte roi tra ve ngay.
// ---------------------------------------------------------------------
static uint32_t gpsLastValidMs = 0;      // lan cuoi co goi hop le (UBX/NMEA)
static uint32_t gpsReconfigMs  = 0;

void gpsUpdate(void) {
  // Nam dat ma mat du lieu > 3 giay -> do lai baud. Da arm thi khong.
  if (GpsBaudOk && !Armed && gpsLastValidMs != 0 &&
      millis() - gpsLastValidMs > 3000) {
    GpsBaudOk = false;
    gpsLastValidMs = 0;
    DBG_PRINTLN(F("GPS: mat du lieu -> do lai baud"));
  }

  if (!GpsBaudOk && !Armed) { gpsProbe(); return; }

  if (gpsProbeBaudIdx != 0) {
    gpsProbeBaudIdx = 0;
    GpsSerial.end();
    GpsSerial.begin(GPS_BAUD);
  }

  uint8_t n = 0;
  while (GpsSerial.available() && n < GPS_MAX_BYTES) {
    uint8_t r = gpsFeed(GpsSerial.read(), true);
    n++;
    if (r) gpsLastValidMs = millis();
    /* Van con NMEA (module vua bi reset, mat cau hinh RAM) va dang nam
     * dat -> gui lai cau hinh, toi da 1 lan / 2 giay. */
    if (r == 1 && !Armed && millis() - gpsReconfigMs > 2000) {
      gpsReconfigMs = millis();
      gpsConfigure(false);
      break;
    }
  }

  GpsHealthy = (GpsFixType > 0) &&
               ((millis() - GpsLastFixMs) < GPS_TIMEOUT_MS) &&
               (GpsSatCount >= GPS_MIN_SATS) && (GpsHaccM < GPS_MAX_HACC_M);
}
