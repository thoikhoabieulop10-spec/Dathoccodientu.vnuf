#ifndef CONFIG_H
#define CONFIG_H

/* =====================================================================
 *  ############   MOI THONG SO CHINH DUOC DEU NAM O DAY   ############
 *
 *  MUC LUC (tim nhanh bang Ctrl+F, go so muc, vd "[7]"):
 *    [1]  Chan cam
 *    [2]  May thu va cong tac (ARM, che do bay)
 *    [3]  Telemetry ve tay cam
 *    [4]  Debug
 *    [5]  Cam bien gia toc va con quay (IMU)
 *    [6]  PID rate va PID goc (tu the)
 *    [7]  Ga, can dieu khien, bo tron motor
 *    [8]  Do cao (baro, Kalman, EKF, PID do cao)
 *    [9]  La ban: hieu chuan va truc
 *    [10] La ban: bo loc va giu huong yaw
 *    [11] GPS
 *    [12] Giu vi tri bang GPS
 *
 *  Cac tab khac chi con nhung hang so cua CHIP (dia chi thanh ghi, ma
 *  nhan dang, kich thuoc bo dem). Dung doi nhung so do.
 * =====================================================================
 */

/* =====================================================================
 *  [1] CHAN CAM — xem them file FC_F405_so_do_chan.pdf
 *
 *  Noi UART luon CHEO: TX cua thiet bi -> RX cua F405 va nguoc lai.
 * ===================================================================== */
// ICM-20602 va BMP388 dung chung SPI1 (SCK PA5, MISO PA6, MOSI PA7)
#define PIN_CS          PA4       // chip select ICM-20602
#define BMP_CS          PA3       // chip select BMP388

// ESC (TIM3 CH1..CH4)
#define M1_PIN          PC6
#define M2_PIN          PC7
#define M3_PIN          PC8
#define M4_PIN          PC9

// Den bao
#define LED_GREEN       PB3       // co song
#define LED_RED         PB4       // mat song (failsafe)
#define LED_GPS         PB5       // tat / nhay / sang = chua co / chua du / san sang

// May thu ELRS (UART4): ELRS TX -> PA1, ELRS RX -> PA0
// PA0 BAT BUOC de gui telemetry ve tay cam.
#define CRSF_PIN_RX     PA1
#define CRSF_PIN_TX     PA0

// GPS GEP-M10 (USART1): GPS TX -> PA10, GPS RX -> PA9
// PA9 can de FC tu cau hinh lai module khi no mat cai dat.
#define PIN_GPS_RX      PA10
#define PIN_GPS_TX      PA9

// La ban IST8310 (I2C1, module rieng hoac tren cum GPS)
#define PIN_MAG_SCL     PB6
#define PIN_MAG_SDA     PB7

// May thu PPM (chi khi RX_PROTOCOL = 0)
#define PPM_PIN         PA0

/* =====================================================================
 *  [2] MAY THU VA CONG TAC
 * ===================================================================== */
/* Giao thuc may thu:
 *   0 = PPM   (FlySky FS-iA6B, 8 kenh, day tin hieu vao PA0)
 *   1 = CRSF  (ELRS, 16 kenh, UART4 tren PA0/PA1)                     */
#define RX_PROTOCOL     1

/* Toc do CRSF. ELRS 3.x mac dinh 420000. Neu day da dung ma van "Khong
 * co song", thu 115200 (mot so may thu ELRS cu hoac hang nhai).      */
#define CRSF_BAUD       420000
#define CRSF_TIMEOUT_MS 500       // mat goi lau hon nay = MAT SONG (failsafe)

// PPM (chi khi RX_PROTOCOL = 0)
#define PPM_CH          8
#define PPM_MIN_US      900
#define PPM_MAX_US      2100
#define PPM_SYNC_US     3000
#define PPM_TIMEOUT_MS  500

// Cong tac ARM: kenh 5 (dem tu 0 nen la 4)
#define ARM_CHANNEL         4
#define ARM_THRESHOLD       1500  // tren muc nay = muon arm
#define ARM_THROTTLE_MAX    1050  // ga phai thap hon muc nay moi cho arm
#define GYRO_RECAL_ON_ARM   1     // 1 = hieu chuan lai con quay moi lan arm

/* Cong tac che do bay 3 nac: kenh 7 (dem tu 0 nen la 6)
 *   duoi 1250        : tu can bang
 *   1250 - 1750      : giu do cao (baro)
 *   tren 1750        : giu do cao + giu vi tri (GPS)
 * Cong tac nam o kenh khac thi doi MODE_CHANNEL.                      */
#define MODE_CHANNEL    6
#define MODE_THR_ALT    1250
#define MODE_THR_POS    1750

/* =====================================================================
 *  [3] TELEMETRY VE TAY CAM (ms giua hai goi cung loai)
 *
 *  Duong telemetry cua ELRS rat hep: thuc te chi ve duoc 5-7 goi CRSF
 *  moi giay. Gui nhanh hon kha nang truyen thi hang doi trong may thu
 *  dai ra va so lieu tren tay cam cang TRE.
 *    Van thay tre  -> tang cac so nay, hoac dat Telem Ratio trong
 *                     script ExpressLRS ve 1:4 hoac 1:8
 *    Muon muot hon -> giam TELEM_ATT_MS xuong 150, kem Telem Ratio 1:4
 * ===================================================================== */
#define TELEM_ATT_MS     200    // pitch, roll, yaw
#define TELEM_ALT_MS     250    // do cao baro
#define TELEM_GPS_MS    1000    // toa do, ve tinh, toc do
#define TELEM_VARIO_MS   500    // toc do len xuong
#define TELEM_FM_MS     1000    // che do bay

/* =====================================================================
 *  [4] DEBUG
 *
 *  DEBUG_ARM 1: in trang thai qua Serial (USB). In Serial CHAN vong lap
 *    nhieu ms -> chi dung tren ban, THAO CANH. Dat 0 truoc khi bay.
 *  DEBUG_EKF 1: in do cao baro va do cao EKF moi giay.
 *  VIBE_ANALYZE 1: ghi gyro tho vao bo dem de phan tich rung.
 * ===================================================================== */
#define DEBUG_ARM       0
#define DEBUG_EKF       0
#define VIBE_ANALYZE    0
#define NAV_DEBUG       1

/* =====================================================================
 *  [5] CAM BIEN GIA TOC VA CON QUAY (IMU)
 * ===================================================================== */
/* TRUC IMU: chip ICM-20602 tren module co the gan XOAY khac nhau. Code
 * can 3 truc theo drone:
 *   X = huong MUI,  Y = sang TRAI,  Z = huong LEN (tren troi)
 * Moi truc lay tu truc nao cua chip (0 = X chip, 1 = Y chip, 2 = Z chip)
 * va co dao dau khong. Module CU: 0 +1 / 1 +1 / 2 +1.
 * DOI MODULE IMU -> chay F405_drone_test menu y, chep 6 dong in ra,
 * roi chay menu z do lai offset.                                       */
#define IMU_X_AXIS      0
#define IMU_X_SIGN      (+1)
#define IMU_Y_AXIS      1
#define IMU_Y_SIGN      (+1)
#define IMU_Z_AXIS      2
#define IMU_Z_SIGN      (+1)

// Offset gia toc ke (g) - tinh SAU khi doi truc o tren
#define ACC_OFFSET_X   (-0.0020)
#define ACC_OFFSET_Y   (0.0121)
#define ACC_OFFSET_Z   (0.0171)

/* Bo loc TREN CHIP ICM-20602 (loc truoc khi code doc, 250 lan/giay).
 * Phai cat duoc rung motor (do bang F405_drone_test menu v: 130-210 Hz)
 * vi code chi doc 250 lan/giay, rung tren 125 Hz khong loc se bi "gap"
 * xuong thanh dao dong gia o tan so thap.
 *   5 = 10 Hz, tre ~18 ms   <- DANG DUNG (bo loc goc, bay da quen)
 *   4 = 20 Hz, tre ~10 ms   (thu 28/09, da quay lai 30/09)
 *   3 = 41 Hz, tre ~6 ms
 * Motor nong / keu re re sau khi bay -> quay lai so lon hon.           */
#define GYRO_CHIP_DLPF     5

// Loc gyro trong code (biquad bac 2, sau bo loc chip)
#define GYRO_LPF_HZ        60.0f
#define GYRO_NOTCH_ENABLE  0
#define GYRO_NOTCH_HZ      83.0f
#define GYRO_NOTCH_BW      30.0f
/* 1 = EMA cu (GYRO_FILTER_ALPHA 0.15 ~ 6 Hz, tre ~23 ms - qua cham).
 * 0 = biquad GYRO_LPF_HZ (tre ~4 ms). Tong tre moi ~14 ms thay vi ~40 ms.
 * Muon quay ve ban cu: USE_OLD_EMA_FILTER 1 va GYRO_CHIP_DLPF 5.       */
#define USE_OLD_EMA_FILTER 1
#define GYRO_FILTER_ALPHA  0.15f

/* =====================================================================
 *  [6] PID RATE VA PID GOC (tu the)
 * ===================================================================== */
// PID rate: toc do quay (do/giay) -> lenh motor
float PRateRoll = 1.4,  PRatePitch = 1.4,  PRateYaw = 4.4;
float IRateRoll = 3.5,  IRatePitch = 3.5,  IRateYaw = 15.3;
float DRateRoll = 0.04, DRatePitch = 0.04, DRateYaw = 0.0;

// PID goc: goc nghieng (do) -> toc do quay mong muon
float PAngleRoll = 1.7, PAnglePitch = 1.7;
float IAngleRoll = 1.0, IAnglePitch = 0.5;
float DAngleRoll = 0.0, DAnglePitch = 0.0;

/* Gioi han rieng cho yaw. Yaw tren khung X = tang toc mot CAP CHEO, giam
 * cap cheo con lai; cho yaw dung nhieu quyen thi motor de cham tran ->
 * LAC CHEO.
 *   Drone van xoay cham khi dang giu huong -> tang YAW_ITERM_LIMIT len 120
 *   Van lac cheo                           -> giam YAW_OUT_LIMIT xuong 150 */
#define YAW_OUT_LIMIT        200.0f
#define YAW_ITERM_LIMIT      80.0f

/* =====================================================================
 *  [7] GA, CAN DIEU KHIEN, BO TRON MOTOR
 * ===================================================================== */
#define ESC_PERIOD_US      4000   // chu ky PWM ESC (4000us = 250Hz)
#define THROTTLE_CUT       1000   // motor tat han (disarm, failsafe)
#define THROTTLE_IDLE      1180   // motor quay cham khi da arm
#define THROTTLE_MAX_CMD   1800   // ga toi da, chua cong PID
float HoverThrottle = 1500;       // ga de treo (dung khi giu do cao)

// Do nhay can dieu khien
#define MAX_ANGLE_DEG      55.0   // goc nghieng toi da khi day het can
#define STICK_EXPO         0.50
#define STICK_YAW_GAIN     (-0.15)
#define STICK_DEADBAND     0.03
#define MAX_TILT_DEG       60.0
#define STICK_ALT_GAIN     0.0008
/* Khi dang giu do cao: can ga lech khoi VI TRI LUC BAT che do qua
 * muc nay (us) moi tinh la muon len/xuong. Chi co tac dung khi
 * PAltitude > 0.                                                     */
#define ALT_STICK_DEADBAND 80.0f

/* Bo tron motor, YAW UU TIEN THAP NHAT:
 *   1 = tinh cho trong cua tung motor roi chi cho yaw dung phan con lai.
 *       Roll/pitch khong bao gio bi yaw chiem cho -> het lac cheo.
 *   0 = bo tron cu (chan tung motor rieng le).                        */
#define MIXER_YAW_PRIORITY   1

/* =====================================================================
 *  [8] DO CAO
 *
 *  BMP388 lo giu do cao. Do cao tinh tu luc BAT NGUON.
 *  Luu y: PAltitude = 0 nghia la chi giu van toc dung bang 0, KHONG keo
 *  ve do cao cu, va can ga khong co tac dung khi dang giu do cao.
 * ===================================================================== */
// PID do cao: sai lech do cao -> van toc dung mong muon
float PAltitude = 1.8;
float IAltitude = 3.05;
float DAltitude = 0.08;

// PID van toc dung: sai lech van toc dung -> ga
float PVelocityVertical = 3.5;
/* I van toc dung: bu phan ga THIEU so voi ga treo that (pin sut ap,
 * luc bat che do can ga dang hoi thap). Don vi: us ga moi giay cho
 * moi cm/s dang roi. 0.005 cu qua nho (roi 10 cm/s phai ~5 phut moi
 * bu duoc 15 us) -> drone tu tu ha xuong dat. Sua 02/10.
 *   van tu tu ha / len   -> tang 0.6
 *   nhap nho len xuong cham (vai giay mot lan) -> giam 0.2           */
float IVelocityVertical = 1.07;
float DVelocityVertical = 0.08;

// Nhieu Kalman 2D
#define KAL2D_ACC_VAR   (30.0*30.0)
#define KAL2D_BARO_R    (30.0*30.0)

// EKF: toc do hoc bias gia toc ke
#define EKF_BIAS_VAR    (0.05f*0.05f)
#define EKF_BIAS_LIMIT  60.0f

/* =====================================================================
 *  [9] LA BAN IST8310: HIEU CHUAN VA TRUC
 *
 *  Lay so tu sketch test F405_IST8310_M10_test (menu d -> w -> t).
 *  DO LAI MOI KHI doi module la ban, doi vi tri, di lai day nguon, doi
 *  cho dat pin. Mo hinh:  m_cal = SOFT * (m_tho - OFFSET)
 * ===================================================================== */

/* KHOA AN TOAN: 1 = so hieu chuan ben duoi DUNG voi la ban dang lap.
 *   0 = chua hieu chuan lai (vua doi module / vi tri). Luc do van tinh
 *       va gui huong mui ve tay cam de kiem tra, nhung KHONG giu huong
 *       va KHONG giu vi tri GPS (den GPS khong sang, che do bao "POS!").
 *   Bay giu vi tri voi so hieu chuan SAI -> drone luon vong xoan oc
 *   hoac bay ra xa. Chep so moi tu menu t xong moi dat 1.
 *   Cac so duoi day: IST8310 module rieng, chip nam NGUA, calib LAI
 *   30/09/2026 sau khi roi (e lech 3.5 do).                           */
#define MAG_CAL_DONE    1

#define MAG_I2C_CLOCK   100000
#define MAG_LOOP_DIV    5         // doc la ban moi 5 vong -> 25Hz

#define MAG_OFFSET_X    19.2f
#define MAG_OFFSET_Y    -25.3f
#define MAG_OFFSET_Z    14.5f

/* Lan calib 30/09 ra mo hinh CHEO (MAG_SCALE_X/Y/Z) -> dat len duong
 * cheo cua ma tran, cac so hang ngoai = 0.                             */
#define MAG_SOFT_R0   { 0.99293f, 0.00082f, 0.01186f }
#define MAG_SOFT_R1   { 0.00082f, 1.00783f, 0.02728f }
#define MAG_SOFT_R2   { 0.01186f, 0.02728f, 1.00018f }

// Do lon tu truong do duoc luc hieu chuan (LSB)
#define MAG_FIELD_NOMINAL   150.1f    // |M| tu menu d/j khung moi (16/10)

// Anh xa truc (menu w). Doi module la ban thi PHAI lam lai menu w.
#define MAG_FWD         ( mx)
#define MAG_RIGHT       ( my)
#define MAG_DOWN        (-mz)

#define MAG_DECLINATION     (-1.74f)  // do lech tu thien Ha Noi, am = lech Tay
#define MAG_HEADING_OFFSET  0.0f      // bu them neu la ban lech deu mot goc

/* Dau bu nghieng. Kiem tra: giu nguyen huong mui, nghieng drone 20-30
 * do; "Huong mui" tren tay cam chi duoc doi vai do. Doi hon 15 do thi
 * doi dau truc bi sai.                                                 */
#define MAG_ROLL_SIGN       (+1)
#define MAG_PITCH_SIGN      (-1)      // 01/10: do bang menu n (+1 lech 19.7 do, -1 lech 2.6 do)

/* Dau toc do yaw cua con quay so voi huong TANG theo chieu kim dong ho.
 * Kiem tra: DEBUG_ARM 1, xoay drone sang phai, "Mag" va "Fused" trong
 * dong [MAG] phai CUNG TANG. Nguoc nhau thi doi thanh (+1).            */
#define YAW_GYRO_SIGN       (-1)

/* =====================================================================
 *  [10] LA BAN: BO LOC VA GIU HUONG YAW
 * ===================================================================== */
/* MAG_FUSE_GAIN: moi mau la ban keo huong ve phia la ban bao nhieu.
 *   0.02 -> hang so thoi gian ~2 giay.
 *     con quay troi, huong lech dan  -> tang len 0.05
 *     huong lung lay theo ga         -> giam ve 0.01
 * MAG_FILTER_ALPHA: loc tren hai thanh phan ngang cua tu truong.
 * MAG_FIELD_TOL: |M| lech qua muc nay so voi MAG_FIELD_NOMINAL thi BO
 *   mau (motor keo dong lon, bay qua khung sat).
 *     bi loai qua nhieu khi len ga -> noi long 0.35
 *     huong bi motor keo lech      -> that chat 0.15
 * MAG_MAX_TILT_DEG: nghieng qua goc nay thi khong tin la ban.
 * MAG_HEALTH_TIMEOUT_MS: khong co mau DUNG lau hon nay = la ban hong.  */
#define MAG_FUSE_GAIN          0.02f
#define MAG_FILTER_ALPHA       0.15f
#define MAG_FIELD_TOL          0.25f
#define MAG_MAX_TILT_DEG       45.0f
#define MAG_HEALTH_TIMEOUT_MS  500

/* Giu huong: vong CHI CO P, sai lech huong (do) -> toc do yaw (do/giay).
 * Dau AM de khop voi STICK_YAW_GAIN am.
 *   drone lac qua lai quanh huong giu -> giam ve -2.0
 *   ve huong qua cham                 -> tang len -4.0
 *   KHONG BAO GIO doi sang so duong: drone se quay tit.               */
float PHeadingHold = -5.7;

#define HEADING_RATE_MAX     60.0f   // toc do yaw tu dong toi da (do/giay)
#define HEADING_DEADBAND_DEG 1.5f    // lech duoi muc nay thi khong sua
#define YAW_STICK_DEADBAND   50.0f   // can yaw lech qua muc nay = nguoi lai cam quyen
#define HEADING_HOLD_MIN_THR 1200    // ga duoi muc nay coi nhu chua bay

/* =====================================================================
 *  [11] GPS
 * ===================================================================== */
/* Module: GEPRC GEP-M10 (u-blox M10), thu GPS+Galileo+BeiDou+QZSS+SBAS.
 * FC tu cau hinh lai module moi lan khoi dong (xem GPS.ino).          */

/* Toc do cong. M10 cua GEPRC xuat xuong 115200. FC tu do tat ca toc do
 * thuong gap va tu doi module ve toc do nay, khong can cai truoc.      */
#define GPS_BAUD        115200

/* So lan GPS tinh vi tri moi giay. M10 chay tot o 10.
 * Neu thay mat fix / so ve tinh giam khi dat 10, ha ve 5.             */
#define GPS_RATE_HZ     10

/* Kieu chuyen dong - bo loc ben trong GPS dua vao day:
 *   7 = bay tren khong, gia toc duoi 2g (hop voi quadcopter)
 *   8 = duoi 4g (drone dua / bay gat)   0 = mac dinh "cam tay"        */
#define GPS_DYN_MODEL   7

// Dieu kien GPS "khoe" (du thi den GPS sang, dong che do dao mau)
#define GPS_MIN_SATS    8         // it hon -> vi tri nhay vai met
#define GPS_MAX_HACC_M  2.5f      // sai so vi tri ngang (m) tu NAV-PVT; ngoai troi thuong 0.5-1.5
#define GPS_TIMEOUT_MS  2000      // khong co du lieu moi lau hon nay = mat GPS

// So mau GPS khoe gom lai de chot diem goc: 3 giay du lieu
#define HOME_SAMPLES    (3 * GPS_RATE_HZ)

// Vi tri nhay qua xa giua hai mau (cm) thi coi la mau hong va bo qua
#define GPS_JUMP_MAX_CM 3000.0f

/* Van toc ngang:
 *   VEL_SOURCE_RMC 1: dung van toc Bac/Dong (velN, velE) co san trong
 *                     goi UBX-NAV-PVT (Doppler, muot, khong tre)
 *                  0: tinh bang hieu hai vi tri (du phong)
 *   (ten giu nguyen tu ban NMEA cu de khoi sua NavControl.ino)
 * VEL_SMOOTH_TAU: noi suy van toc muot o 250Hz (giay).
 * VEL_FILTER_ALPHA: chi dung khi tinh bang hieu vi tri.               */
#define VEL_SOURCE_RMC    1
#define VEL_SMOOTH_TAU    0.12f
#define VEL_FILTER_ALPHA  0.5f

/* =====================================================================
 *  [12] GIU VI TRI BANG GPS  (nac TREN cong tac CH7)
 *
 *  Hai tang noi tiep, deu chay 250 lan/giay:
 *
 *    TANG VI TRI:  sai lech vi tri (cm)  -> van toc mong muon (cm/s)
 *       PPosition = cm/s cho moi cm lech.  0.3: lech 1 m -> bay ve 30 cm/s
 *       IPosition : de 0 (tang van toc da chong gio).
 *
 *    TANG VAN TOC: sai lech van toc (cm/s) -> GOC NGHIENG (do)
 *       PVelocityHoriz = DO cho moi cm/s.  0.1: troi 50 cm/s -> nghieng
 *                        5 do de ham.  (ArduPilot mac dinh ~ 0.1)
 *       IVelocityHoriz = chong gio thoi deu. 0.02: troi deu 20 cm/s thi
 *                        sau 5 s da bu them 2 do.
 *    Ca hai D = 0: GPS chi co so moi 10 lan/giay, D se giat moi lan co so.
 *
 *  THU TU TUNE:
 *    Buoc 1: PPosition 0, IVelocityHoriz 0  -> chi PHANH khi tha can
 *    Buoc 2: them IVelocityHoriz 0.02       -> chong gio
 *    Buoc 3: them PPosition 0.2             -> keo ve dung diem cu
 *
 *  KHONG DUNG LAI bo cu 0.5/0.05 hay 1.5/0.15: troi 10 cm/s (nhieu GPS)
 *  da nghieng 5 do -> drone giat lien tuc.
 * ===================================================================== */
// DANG O BUOC 1 (01/10)
float PPosition = 0.3, IPosition = 0.0, DPosition = 0.0;
float PVelocityHoriz = 0.10, IVelocityHoriz = 0.02, DVelocityHoriz = 0.0;

#define POS_VEL_MAX         150.0f  // van toc toi da khi keo ve diem neo (cm/s)
#define POS_ANGLE_MAX       12.0f    // goc nghieng toi da GPS duoc ra lenh (do)

/* Chieu lenh. Kiem tra TREN DAT (DEBUG_ARM 1, cam USB, CHUA arm, nac
 * tren, den GPS sang): cam drone di bo ve phia MUI -> CmdP phai AM
 * (ngoc mui = ham); di ve phia suon PHAI -> CmdR phai AM (nghieng trai).
 * Sai dau nao thi doi dau do sang (-1).
 * Sai chieu ma van bay: drone se bay ra xa ngay cang nhanh.           */
#define POS_PITCH_SIGN      (+1)
#define POS_ROLL_SIGN       (+1)

/* Nguoi lai cam quyen: day can roll/pitch qua POS_STICK_DEADBAND (us)
 * thi GPS nha ra; tha can thi drone ham den duoi POS_BRAKE_SPEED roi
 * chot diem neo moi tai do.                                            */
#define POS_STICK_DEADBAND  40.0f
#define POS_BRAKE_SPEED     30.0f   // cm/s

/* =====================================================================
 *  ###################   HET PHAN CHINH THONG SO   ###################
 * =====================================================================
 */

#endif
