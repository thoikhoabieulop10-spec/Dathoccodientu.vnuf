/* ===== TAB IMU — ICM-20602 (SPI) + doc gyro/accel + Kalman 1D goc ===== */

// Bo dem vong ghi gyro tho khi VIBE_ANALYZE = 1 (Config.h).
// Truoc day cac bien nay nam trong file chinh cu; thieu chung thi bat
// VIBE_ANALYZE se loi "was not declared in this scope".
#if VIBE_ANALYZE
#define VIBE_N 512
int16_t  vibeBuf[VIBE_N];
uint16_t vibeIdx = 0, vibeCount = 0;
#endif

static void icmWrite(uint8_t reg, uint8_t val) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg & 0x7F); SPI.transfer(val);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  delayMicroseconds(20);
}
static uint8_t icmRead(uint8_t reg) {
  SPI.beginTransaction(SPI_SLOW);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  uint8_t v = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
  return v;
}
static void icmBurst(uint8_t reg, uint8_t *buf, uint8_t len) {
  SPI.beginTransaction(SPI_FAST);
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(reg | 0x80);
  for (uint8_t i = 0; i < len; i++) buf[i] = SPI.transfer(0x00);
  digitalWrite(PIN_CS, HIGH);
  SPI.endTransaction();
}
static bool icmInit(void) {
  pinMode(PIN_CS, OUTPUT); digitalWrite(PIN_CS, HIGH);
  SPI.begin(); delay(100);
  icmWrite(REG_PWR_MGMT_1, 0x80); delay(100);
  icmWrite(REG_SIGPATH_RESET, 0x03); delay(100);
  icmWrite(REG_USER_CTRL, 0x10);
  icmWrite(REG_PWR_MGMT_1, 0x01);
  icmWrite(REG_PWR_MGMT_2, 0x00); delay(20);
  if (icmRead(REG_WHO_AM_I) != ICM_WHOAMI) return false;
  icmWrite(REG_SMPLRT_DIV, 0x00);
  icmWrite(REG_CONFIG, GYRO_CHIP_DLPF);          // Config.h muc [5]
  icmWrite(REG_GYRO_CONFIG, 0x08);
  icmWrite(REG_ACCEL_CONFIG, 0x10);
  icmWrite(REG_ACCEL_CONFIG_2, 0x05);
  delay(20);
  return true;
}

// Reads gyro AND accel, filters the gyro, computes raw angle (Project 14)
void gyro_signals(void) {
  uint8_t b[14];
  icmBurst(REG_ACCEL_XOUT_H, b, 14);
  // So tho theo truc CHIP
  int32_t ca[3] = { (int16_t)((b[0] << 8) | b[1]), (int16_t)((b[2]  << 8) | b[3]),
                    (int16_t)((b[4] << 8) | b[5]) };
  int32_t cg[3] = { (int16_t)((b[8] << 8) | b[9]), (int16_t)((b[10] << 8) | b[11]),
                    (int16_t)((b[12] << 8) | b[13]) };
  // Doi sang truc DRONE (X mui, Y trai, Z len) - xem IMU_*_AXIS trong Config.h.
  // Gia toc va con quay cung nam tren mot chip nen dung CHUNG mot phep doi.
  int32_t ax = IMU_X_SIGN * ca[IMU_X_AXIS], gx = IMU_X_SIGN * cg[IMU_X_AXIS];
  int32_t ay = IMU_Y_SIGN * ca[IMU_Y_AXIS], gy = IMU_Y_SIGN * cg[IMU_Y_AXIS];
  int32_t az = IMU_Z_SIGN * ca[IMU_Z_AXIS], gz = IMU_Z_SIGN * cg[IMU_Z_AXIS];

  float rawRoll  = (float)gx / 65.5;

  // ---- Ghi gyro thô vào bộ đệm vòng để phân tích rung sau khi bay ----
  // Không ảnh hưởng PID: chỉ lưu lại, không đổi tín hiệu điều khiển.
  #if VIBE_ANALYZE
  vibeBuf[vibeIdx] = gx;                 // roll thô, chưa lọc
  vibeIdx = (vibeIdx + 1) % VIBE_N;
  if (vibeCount < VIBE_N) vibeCount++;
  #endif
  float rawPitch = (float)gy / 65.5;
  float rawYaw   = (float)gz / 65.5;
#if USE_OLD_EMA_FILTER
  // Bộ lọc EMA cũ (bậc 1) — giữ để so sánh
  RateRollFilt  = GYRO_FILTER_ALPHA*rawRoll  + (1-GYRO_FILTER_ALPHA)*RateRollFilt;
  RatePitchFilt = GYRO_FILTER_ALPHA*rawPitch + (1-GYRO_FILTER_ALPHA)*RatePitchFilt;
  RateYawFilt   = GYRO_FILTER_ALPHA*rawYaw   + (1-GYRO_FILTER_ALPHA)*RateYawFilt;
#else
  // Biquad bậc 2: notch (nếu bật) rồi low-pass
 #if GYRO_NOTCH_ENABLE
  rawRoll  = biquadApply(&NotchRoll,  rawRoll);
  rawPitch = biquadApply(&NotchPitch, rawPitch);
  rawYaw   = biquadApply(&NotchYaw,   rawYaw);
 #endif
  RateRollFilt  = biquadApply(&LpfRoll,  rawRoll);
  RatePitchFilt = biquadApply(&LpfPitch, rawPitch);
  RateYawFilt   = biquadApply(&LpfYaw,   rawYaw);
#endif
  RateRoll  = RateRollFilt;
  RatePitch = RatePitchFilt;
  RateYaw   = RateYawFilt;

  // offset gia tốc kế -- đo trên cảm biến của bạn (nằm phẳng, cân bằng)
  AccX = (float)ax / 4096.0 + (ACC_OFFSET_X);
  AccY = (float)ay / 4096.0 + (ACC_OFFSET_Y);
  AccZ = (float)az / 4096.0 + (ACC_OFFSET_Z);

  // angle from gravity direction (Project 14). Note the -AccX on pitch,
  // matching the manual's sign convention you verified earlier.
  AngleRoll  =  atan( AccY / sqrt(AccX*AccX + AccZ*AccZ)) * 57.2958;
  AnglePitch = -atan( AccX / sqrt(AccY*AccY + AccZ*AccZ)) * 57.2958;
}

// =====================================================================
//  Kalman filter, 1 dimension (Project 15)
//    input       = gyro rate (prediction)
//    measurement = accelerometer angle (correction)
//    4*4 = process noise (gyro), 3*3 = measurement noise (accel)
// =====================================================================
void kalman_1d(float KalmanState, float KalmanUncertainty,
               float KalmanInput, float KalmanMeasurement) {
  KalmanState = KalmanState + 0.004 * KalmanInput;
  KalmanUncertainty = KalmanUncertainty + 0.004 * 0.004 * 4 * 4;
  float KalmanGain = KalmanUncertainty / (KalmanUncertainty + 3 * 3);
  KalmanState = KalmanState + KalmanGain * (KalmanMeasurement - KalmanState);
  KalmanUncertainty = (1 - KalmanGain) * KalmanUncertainty;
  Kalman1DOutput[0] = KalmanState;
  Kalman1DOutput[1] = KalmanUncertainty;
}
