/* =====================================================================
 *  TAB NAVCONTROL — GIỮ VỊ TRÍ BẰNG GPS
 *
 *  Vòng này chỉ sinh ra GÓC NGHIÊNG MONG MUỐN (PosCmdPitch/Roll) cho
 *  cascade angle -> rate sẵn có. PID angle và rate đã tune giữ nguyên.
 *  Giữ hướng yaw nằm trong tab Compass (headingHoldUpdate).
 * =====================================================================
 */

// ---------------------------------------------------------------------
//  GPS: Uoc luong van toc ngang — GOI MOI VONG LAP (250Hz)
//
//  Hai buoc:
//   1. Moi khi co so GPS moi (5Hz): cap nhat van toc MUC TIEU.
//        uu tien van toc Doppler tu RMC; RMC mat > 0.5s thi tru vi tri.
//   2. Moi vong (4ms): keo VelNorthCms/VelEastCms tu tu ve muc tieu.
//      Buoc nay bien bac thang 5Hz thanh duong cong muot, giong y tuong
//      noi suy len 50Hz cua Brokking nhung khong can bo dem vong.
// ---------------------------------------------------------------------
static float    lastPosN = 0, lastPosE = 0;
static uint32_t lastVelMs = 0;
static bool     velReady = false;
static float    velTgtN = 0, velTgtE = 0;

void navUpdateVelocity(void) {
  // ---- 1a. Van toc Doppler tu RMC ----
  static uint32_t lastRmc = 0;
  bool rmcFresh = VEL_SOURCE_RMC && (millis() - GpsVelMs < 500) && GpsVelMs != 0;
  if (rmcFresh && GpsVelMs != lastRmc) {
    lastRmc = GpsVelMs;
    velTgtN = GpsVelNorthCms;
    velTgtE = GpsVelEastCms;
  }

  // ---- 1b. Tru vi tri (luon theo doi, chi dung khi RMC mat) ----
  static uint32_t lastFix = 0;
  if (GpsLastFixMs != lastFix) {
    lastFix = GpsLastFixMs;
    uint32_t now = millis();
    if (!velReady) {
      lastPosN = PosNorthCm; lastPosE = PosEastCm;
      lastVelMs = now; velReady = true;
    } else {
      float dt = (now - lastVelMs) * 0.001f;
      lastVelMs = now;
      if (dt >= 0.05f && dt <= 1.0f) {
        float vN = (PosNorthCm - lastPosN) / dt;
        float vE = (PosEastCm  - lastPosE) / dt;
        if (vN >  1000) vN =  1000;  if (vN < -1000) vN = -1000;
        if (vE >  1000) vE =  1000;  if (vE < -1000) vE = -1000;
        if (!rmcFresh) {
          velTgtN += VEL_FILTER_ALPHA * (vN - velTgtN);
          velTgtE += VEL_FILTER_ALPHA * (vE - velTgtE);
        }
      }
      lastPosN = PosNorthCm; lastPosE = PosEastCm;
    }
  }

  // ---- 2. Noi suy muot moi vong ----
  const float k = 0.004f / VEL_SMOOTH_TAU;
  VelNorthCms += k * (velTgtN - VelNorthCms);
  VelEastCms  += k * (velTgtE - VelEastCms);
}

// ---------------------------------------------------------------------
//  GIỮ VỊ TRÍ BẰNG GPS
// ---------------------------------------------------------------------
/* Trang thai giu vi tri:
 *   POS_HOLD   : giu diem neo (vong vi tri + vong van toc)
 *   POS_PILOT  : nguoi lai dang day can -> GPS nha, drone theo can
 *   POS_BRAKE  : vua tha can -> chi ham (van toc muc tieu = 0), cham
 *                roi moi chot diem neo moi. */
enum { POS_HOLD = 0, POS_PILOT, POS_BRAKE };
static uint8_t posState = POS_HOLD;

static void posResetIterms(void) {
  PrevErrPosNorth = PrevErrPosEast = 0;
  PrevItermPosNorth = PrevItermPosEast = 0;
  PrevErrVelNorth = PrevErrVelEast = 0;
  PrevItermVelNorth = PrevItermVelEast = 0;
}

/* Tra ve true neu lenh nghieng GPS (PosCmdPitch/Roll) dang duoc dung.
 * Tra ve false -> dung goc tu can dieu khien nhu binh thuong. */
bool navPositionHold(bool wantHold, bool pilotSticks) {
  bool canHold = wantHold && GpsHealthy && CompassHealthy && HomeSet;

  if (!canHold) {
    if (PosHoldOn) {
      PosHoldOn = false;
      posResetIterms();
      PosCmdPitch = PosCmdRoll = 0;
    }
    return false;
  }

  if (!PosHoldOn) {
    // Vua bat giu vi tri: ham truoc roi moi chot diem neo
    posResetIterms();
    posState  = pilotSticks ? POS_PILOT : POS_BRAKE;
    PosHoldOn = true;
  }

  // ---- Nguoi lai cam quyen ----
  if (pilotSticks) {
    if (posState != POS_PILOT) posResetIterms();
    posState = POS_PILOT;
    TargetNorthCm = PosNorthCm;          // diem neo di theo drone
    TargetEastCm  = PosEastCm;
    PosCmdPitch = PosCmdRoll = 0;
    return false;                        // dung goc tu can
  }
  if (posState == POS_PILOT) {           // vua tha can
    posResetIterms();
    posState = POS_BRAKE;
  }

  float desVelN = 0, desVelE = 0;

  if (posState == POS_BRAKE) {
    // Chi ham: van toc muc tieu = 0. Du cham thi chot diem neo tai day.
    float spd = sqrtf(VelNorthCms * VelNorthCms + VelEastCms * VelEastCms);
    TargetNorthCm = PosNorthCm;
    TargetEastCm  = PosEastCm;
    if (spd < POS_BRAKE_SPEED) {
      PrevErrPosNorth = PrevErrPosEast = 0;
      PrevItermPosNorth = PrevItermPosEast = 0;
      posState = POS_HOLD;
    }
  } else {
    // ---- Tang vi tri: sai lech (cm) -> van toc mong muon (cm/s) ----
    ErrPosNorth = TargetNorthCm - PosNorthCm;
    ErrPosEast  = TargetEastCm  - PosEastCm;

    pid_equation_lim(ErrPosNorth, PPosition, IPosition, DPosition,
                     PrevErrPosNorth, PrevItermPosNorth, POS_VEL_MAX, POS_VEL_MAX);
    desVelN = PIDReturn[0];
    PrevErrPosNorth = PIDReturn[1]; PrevItermPosNorth = PIDReturn[2];

    pid_equation_lim(ErrPosEast, PPosition, IPosition, DPosition,
                     PrevErrPosEast, PrevItermPosEast, POS_VEL_MAX, POS_VEL_MAX);
    desVelE = PIDReturn[0];
    PrevErrPosEast = PIDReturn[1]; PrevItermPosEast = PIDReturn[2];
  }

  ErrVelNorth = desVelN - VelNorthCms;
  ErrVelEast  = desVelE - VelEastCms;

  pid_equation_lim(ErrVelNorth, PVelocityHoriz, IVelocityHoriz, DVelocityHoriz,
                   PrevErrVelNorth, PrevItermVelNorth, POS_ANGLE_MAX, POS_ANGLE_MAX);
  float tiltN = PIDReturn[0];
  PrevErrVelNorth = PIDReturn[1]; PrevItermVelNorth = PIDReturn[2];

  pid_equation_lim(ErrVelEast, PVelocityHoriz, IVelocityHoriz, DVelocityHoriz,
                   PrevErrVelEast, PrevItermVelEast, POS_ANGLE_MAX, POS_ANGLE_MAX);
  float tiltE = PIDReturn[0];
  PrevErrVelEast = PIDReturn[1]; PrevItermVelEast = PIDReturn[2];

  /* Quay lenh tu truc Bac/Dong sang truc mui/suon drone.
   * Dung FusedHeading (da tron con quay) chu khong dung goc la ban tho:
   * goc tho giat theo nhieu motor, lam lenh nghieng giat theo. */
  float h  = FusedHeading * 0.0174533f;
  float ch = cosf(h), sh = sinf(h);
  float cmdFwd   =  tiltN * ch + tiltE * sh;
  float cmdRight = -tiltN * sh + tiltE * ch;

  cmdFwd   = POS_PITCH_SIGN * cmdFwd;
  cmdRight = POS_ROLL_SIGN  * cmdRight;

  if (cmdFwd   >  POS_ANGLE_MAX) cmdFwd   =  POS_ANGLE_MAX;
  if (cmdFwd   < -POS_ANGLE_MAX) cmdFwd   = -POS_ANGLE_MAX;
  if (cmdRight >  POS_ANGLE_MAX) cmdRight =  POS_ANGLE_MAX;
  if (cmdRight < -POS_ANGLE_MAX) cmdRight = -POS_ANGLE_MAX;

  PosCmdPitch = cmdFwd;
  PosCmdRoll  = cmdRight;

  return true;
}

