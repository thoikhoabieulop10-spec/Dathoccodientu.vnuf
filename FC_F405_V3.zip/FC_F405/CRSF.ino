/* =====================================================================
 *  TAB CRSF — DOC ELRS QUA GIAO THUC CRSF
 *
 *  Thay cho PPM. Cung cap DUNG BA HAM ma FC_F405.ino goi:
 *      receiver_init()   receiver_alive()   read_receiver()
 *  nen phan con lai cua firmware khong phai sua gi.
 *
 *  VI SAO CRSF TOT HON PPM
 *    PPM nhoi 8 kenh vao MOT day tin hieu bang do rong xung, moi khung
 *    mat 20ms va moi kenh la mot xung rieng -> tre trung binh ~10ms va
 *    nhieu day lam sai gia tri kenh ma khong co cach nao phat hien.
 *
 *    CRSF la goi NHI PHAN co CRC8. Sai mot bit la loai ca goi, khong bao
 *    gio nhan gia tri rac. 16 kenh thay vi 8. Toc do khung theo cau hinh
 *    ELRS (50-500Hz), tre thap hon PPM mot bac.
 *
 *  CAU TRUC GOI
 *      [0xC8][len][type][payload ...][crc8]
 *    len   = so byte SAU byte len, tuc type + payload + crc
 *    crc8  = da thuc 0xD5, tinh tren type + payload (len-1 byte)
 *    type 0x16 = RC_CHANNELS_PACKED: 22 byte chua 16 kenh x 11 bit
 *
 *  DOI GIA TRI — dung dai 1000-2000, KHONG dung 988-2012
 *
 *    Diem chuan goc cua giao thuc TBS la 172->988us, 1811->2012us.
 *    NHUNG firmware nay duoc tune voi FlySky PPM, dai 1000-2000, va moi
 *    nguong deu dua tren dai do:
 *        THROTTLE_IDLE 1180   HoverThrottle 1500   THROTTLE_MAX_CMD 1800
 *        cat ga khi rx[2] < 1050
 *    Dung 988-2012 se lam ga het can vuot 2012 va stickExpo phai cat bot,
 *    tuc mat mot phan hanh trinh can. Nen anh xa thang ve 1000-2000:
 *
 *        us = 1000 + (gia_tri - 172) * 1000 / 1639
 *
 *    Kiem lai:  172 -> 1000    992 -> 1500    1811 -> 2000
 *
 *  DAY NOI — xem CRSF_PIN_RX / CRSF_PIN_TX trong Config.h
 *
 *    Tren may thu trong anh, hai chan ghi la CH2/TX va CH3/RX. Phai vao
 *    ELRS Lua hoac WebUI dat hai chan do sang che do SERIAL (CRSF), khong
 *    thi may thu van xuat PWM tung kenh va FC khong nhan duoc gi.
 *
 *  CAI DAT TAY DIEU KHIEN (RadioMaster Pocket, EdgeTX)
 *    Model -> Internal RF -> Mode = CRSF, Baudrate = 420k
 *    Thu tu kenh phai la AETR: CH1 Aileron(roll), CH2 Elevator(pitch),
 *    CH3 Throttle, CH4 Rudder(yaw) — dung thu tu ma read_receiver() gia
 *    dinh. Neu tay dang de TAER thi doi lai trong Model -> Setup.
 * ===================================================================== */

#if RX_PROTOCOL == 1

HardwareSerial CrsfSerial(CRSF_PIN_RX, CRSF_PIN_TX);

/* CRSF_BAUD gio nam trong Config.h (de doi baud khi chan doan).
 * #ifndef de tuong thich neu ai do van define san o cho khac. */
#define CRSF_SYNC             0xC8
#define CRSF_TYPE_RC          0x16
#define CRSF_FRAME_MAX        64

/* Doc toi da bao nhieu byte moi vong lap.
 * O 420000 baud, 4ms toi da toi 168 byte. Nhung bo dem UART cua
 * STM32duino chi 64 byte, va ELRS 500Hz chi gui 26 byte moi 2ms (tuc
 * ~52 byte moi vong 4ms). 96 la du rong rai ma van chan duoc truong
 * hop xau lam keo dai vong lap. */
#define CRSF_MAX_BYTES_LOOP   96

static uint8_t  crsfBuf[CRSF_FRAME_MAX];
static uint8_t  crsfIdx  = 0;
static uint8_t  crsfLen  = 0;
static uint32_t crsfLastFrameMs = 0;

// Bo dem thong ke — huu ich khi chan doan chat luong day noi
uint32_t CrsfGoodFrames = 0;
uint32_t CrsfCrcErrors  = 0;

// ---------------------------------------------------------------------
//  CRC8 da thuc 0xD5 (chuan CRSF)
// ---------------------------------------------------------------------
static uint8_t crsfCrc8(const uint8_t *p, uint8_t len) {
  uint8_t crc = 0;
  for (uint8_t i = 0; i < len; i++) {
    crc ^= p[i];
    for (uint8_t b = 0; b < 8; b++)
      crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0xD5) : (uint8_t)(crc << 1);
  }
  return crc;
}

/* ---------------------------------------------------------------------
 *  Giai nen 16 kenh x 11 bit tu 22 byte.
 *
 *  Cac kenh xep LIEN TIEP theo bit, khong can le byte. Nen phai gom bit
 *  vao mot thanh ghi truot roi lay ra tung 11 bit mot.
 * ------------------------------------------------------------------- */
static void crsfUnpack(const uint8_t *p) {
  uint32_t bits  = 0;
  uint8_t  nbits = 0;
  uint8_t  ch    = 0;

  for (uint8_t i = 0; i < 22 && ch < RX_CH; i++) {
    bits |= (uint32_t)p[i] << nbits;
    nbits += 8;
    while (nbits >= 11 && ch < RX_CH) {
      uint16_t v = (uint16_t)(bits & 0x7FF);
      bits  >>= 11;
      nbits  -= 11;
      if (v < 172)  v = 172;          // chan gia tri ngoai dai hop le
      if (v > 1811) v = 1811;
      ReceiverValue[ch++] = 1000.0f + ((float)v - 172.0f) * 1000.0f / 1639.0f;
    }
  }
}

// ---------------------------------------------------------------------
//  Goi MOI VONG LAP, truoc read_receiver(). Tra ve nhanh, khong chan.
// ---------------------------------------------------------------------
void crsfUpdate(void) {
  uint8_t n = 0;
  while (CrsfSerial.available() && n < CRSF_MAX_BYTES_LOOP) {
    uint8_t c = (uint8_t)CrsfSerial.read();
    n++;

    if (crsfIdx == 0) {                       // cho byte dong bo
      if (c != CRSF_SYNC) continue;
      crsfBuf[crsfIdx++] = c;
    }
    else if (crsfIdx == 1) {                  // byte do dai
      if (c < 2 || c > CRSF_FRAME_MAX - 2) { crsfIdx = 0; continue; }
      crsfLen = c;
      crsfBuf[crsfIdx++] = c;
    }
    else {                                    // than goi
      crsfBuf[crsfIdx++] = c;
      if (crsfIdx == (uint8_t)(crsfLen + 2)) {
        // CRC tinh tren type + payload, tuc (len-1) byte ke tu chi so 2
        if (crsfCrc8(&crsfBuf[2], (uint8_t)(crsfLen - 1)) == crsfBuf[crsfLen + 1]) {
          CrsfGoodFrames++;
          if (crsfBuf[2] == CRSF_TYPE_RC) {
            crsfUnpack(&crsfBuf[3]);
            crsfLastFrameMs = millis();
          }
        } else {
          CrsfCrcErrors++;                    // goi hong -> BO HAN, khong dung
        }
        crsfIdx = 0;
      }
    }
  }
}

// ---------------------------------------------------------------------
void receiver_init(void) {
  CrsfSerial.begin(CRSF_BAUD);
  crsfIdx = 0;
  crsfLastFrameMs = 0;
  CrsfGoodFrames = 0;
  CrsfCrcErrors  = 0;
}

bool receiver_alive(void) {
  return (crsfLastFrameMs != 0) &&
         ((millis() - crsfLastFrameMs) < CRSF_TIMEOUT_MS);
}

void read_receiver(float *o) {
  noInterrupts();
  for (int i = 0; i < 4; i++) o[i] = ReceiverValue[i];
  interrupts();
}

/* =====================================================================
 *  TELEMETRY: GUI SO LIEU VE TAY CAM QUA MAY THU ELRS
 *
 *  FC gui goi CRSF ra chan TX (PA0) -> may thu ELRS -> song ve tay cam.
 *  EdgeTX tu nhan ra cac loai goi chuan duoi day (giong Betaflight):
 *
 *    0x02 GPS       -> GPS (toa do), GSpd, Hdg, GAlt/Alt, Sats
 *    0x09 Do cao baro -> Alt   (do cao so voi luc cat canh, don vi dm)
 *    0x07 Vario     -> VSpd  (toc do len xuong, cm/s)
 *    0x1E Tu the    -> Ptch, Roll, Yaw (Yaw = huong mui tu la ban)
 *    0x21 Che do    -> FM    (chuoi chu: che do bay + trang thai GPS)
 *
 *  NHIP GUI phai KHOP voi bang thong telemetry cua ELRS, neu khong hang
 *  doi trong may thu cu dai ra va so lieu tren tay cam ngay cang TRE.
 *  Moi goi vo tuyen cua ELRS chi cho vai byte, nen mot goi GPS 15 byte
 *  phai chia 3-4 luot; thuc te chi gui ve duoc khoang 5-7 goi CRSF/giay.
 *  Vi vay moi loai co nhip RIENG (xem TELEM_*_MS trong Config.h), uu tien
 *  tu the vi do la thu can muot nhat. Tong khoang 10 goi/giay.
 *  KHONG BAO GIO chan vong lap: bo dem phat khong du cho thi bo qua luot.
 *
 *  So byte nhieu byte deu gui BIG-ENDIAN (byte cao truoc).
 * ===================================================================== */
static void crsfPut16(uint8_t *p, int16_t v)  { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }
static void crsfPutU16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }
static void crsfPut32(uint8_t *p, int32_t v) {
  p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16);
  p[2] = (uint8_t)(v >> 8);  p[3] = (uint8_t)v;
}

// Dong goi va gui: [0xC8][len][type][payload][crc]. false = bo dem day.
static bool crsfSendFrame(uint8_t type, const uint8_t *payload, uint8_t n) {
  uint8_t f[64];
  if (n > 58) return false;
  if (CrsfSerial.availableForWrite() < n + 4) return false;
  f[0] = CRSF_SYNC;
  f[1] = n + 2;                       // type + payload + crc
  f[2] = type;
  memcpy(&f[3], payload, n);
  f[3 + n] = crsfCrc8(&f[2], n + 1);
  CrsfSerial.write(f, n + 4);
  return true;
}

// ---- 0x02 GPS ----
static bool crsfSendGps(void) {
  uint8_t p[15];
  crsfPut32(&p[0], (int32_t)(GpsLatitude  * 1e7));      // do * 1e7
  crsfPut32(&p[4], (int32_t)(GpsLongitude * 1e7));

  float spd = sqrtf(VelNorthCms * VelNorthCms + VelEastCms * VelEastCms);  // cm/s
  crsfPutU16(&p[8], (uint16_t)(spd * 0.36f + 0.5f));    // km/h * 10

  // Huong: dang di chuyen thi la huong bay; dung yen thi lay huong mui
  float hdg = (spd > 50.0f) ? atan2f(VelEastCms, VelNorthCms) * 57.29578f
                            : FusedHeading;
  if (hdg < 0) hdg += 360.0f;
  crsfPutU16(&p[10], (uint16_t)(hdg * 100.0f));         // do * 100

  float altm = GpsAltitude;                             // m tren muc nuoc bien
  if (altm < -1000) altm = -1000;
  crsfPutU16(&p[12], (uint16_t)(altm + 1000.0f));       // m + 1000
  p[14] = GpsSatCount;
  return crsfSendFrame(0x02, p, 15);
}

// ---- 0x09 Do cao baro (so voi luc khoi dong) ----
static bool crsfSendBaroAlt(void) {
  int32_t dm = (int32_t)(AltitudeKalman * 0.1f);        // cm -> dm
  uint16_t packed;
  if (dm < -10000)            packed = 0;
  else if (dm < 0x8000 - 10000) packed = (uint16_t)(dm + 10000);        // MSB=0: dm + 10000
  else                        packed = 0x8000 | (uint16_t)min(dm / 10, (int32_t)0x7FFE);  // MSB=1: m
  uint8_t p[2];
  crsfPutU16(p, packed);
  return crsfSendFrame(0x09, p, 2);
}

// ---- 0x07 Vario (toc do len xuong) ----
static bool crsfSendVario(void) {
  uint8_t p[2];
  crsfPut16(p, (int16_t)constrain(VelocityKalman, -32000.0f, 32000.0f));  // cm/s
  return crsfSendFrame(0x07, p, 2);
}

// ---- 0x1E Tu the: pitch, roll, yaw (rad * 10000) ----
static bool crsfSendAttitude(void) {
  float yaw = FusedHeading;
  if (yaw > 180.0f) yaw -= 360.0f;                      // -180..180
  uint8_t p[6];
  crsfPut16(&p[0], (int16_t)(KalmanAnglePitch * 0.0174533f * 10000.0f));
  crsfPut16(&p[2], (int16_t)(KalmanAngleRoll  * 0.0174533f * 10000.0f));
  crsfPut16(&p[4], (int16_t)(yaw              * 0.0174533f * 10000.0f));
  return crsfSendFrame(0x1E, p, 6);
}

/* ---- 0x21 Che do bay: chuoi chu ket thuc bang 0 ----
 *   STAB  : noc duoi CH7, tu can bang
 *   ALT   : noc giua, giu do cao
 *   POS   : noc tren, DANG giu vi tri bang GPS
 *   POS!  : noc tren nhung GPS/la ban CHUA san sang -> chi giu do cao
 *   them "*" o cuoi khi CHUA ARM  (vd "STAB*")
 *   them " G" khi GPS san sang giu vi tri (giong den do)
 *   them " L3.8" = vong lap LAU NHAT tu lan gui truoc la 3.8 ms.
 *     Phai luon DUOI 4.0. Bang hoac tren 4.0 = vong lap bi tre
 *     -> drone rung va phan ung cham. Xem tren tay cam: Telemetry, cam bien FM. */
static bool crsfSendFlightMode(void) {
  float chMode;
  noInterrupts(); chMode = ReceiverValue[MODE_CHANNEL]; interrupts();
  bool navReady = GpsBaudOk && GpsHealthy && HomeSet && CompassHealthy;

  char m[20];
  if      (chMode > MODE_THR_POS) strcpy(m, navReady ? "POS" : "POS!");
  else if (chMode > MODE_THR_ALT) strcpy(m, "ALT");
  else                            strcpy(m, "STAB");
  if (navReady) strcat(m, " G");
  if (!Armed)   strcat(m, "*");

  // Thoi gian vong lap lau nhat (don vi 0.1 ms), roi dat lai
  uint32_t t = (LoopMaxUs + 50) / 100;
  LoopMaxUs = 0;
  if (t > 999) t = 999;
  char l[8];
  l[0] = ' '; l[1] = 'L';
  uint8_t i = 2;
  if (t >= 100) l[i++] = '0' + (t / 100);
  l[i++] = '0' + (t / 10) % 10;
  l[i++] = '.';
  l[i++] = '0' + t % 10;
  l[i]   = 0;
  strcat(m, l);
  return crsfSendFrame(0x21, (const uint8_t *)m, (uint8_t)(strlen(m) + 1));
}

/* Goi MOI VONG LAP, sau crsfUpdate().
 * Moi lan chi gui TOI DA MOT goi, loai nao qua han lau nhat thi gui truoc. */
void crsfTelemetryUpdate(void) {
  static const uint16_t period[5] = {
    TELEM_ATT_MS, TELEM_ALT_MS, TELEM_GPS_MS, TELEM_VARIO_MS, TELEM_FM_MS
  };
  static uint32_t lastSent[5] = { 0, 0, 0, 0, 0 };
  uint32_t now = millis();

  int8_t   pick = -1;
  uint32_t worst = 0;
  for (uint8_t i = 0; i < 5; i++) {
    uint32_t due = now - lastSent[i];
    if (due >= period[i] && due > worst) { worst = due; pick = i; }
  }
  if (pick < 0) return;

  bool ok;
  switch (pick) {
    case 0:  ok = crsfSendAttitude();   break;
    case 1:  ok = crsfSendBaroAlt();    break;
    case 2:  ok = crsfSendGps();        break;
    case 3:  ok = crsfSendVario();      break;
    default: ok = crsfSendFlightMode(); break;
  }
  if (ok) lastSent[pick] = now;      // bo dem day -> thu lai vong sau
}

#endif  // RX_PROTOCOL == 1
