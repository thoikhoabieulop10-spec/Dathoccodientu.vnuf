/* ===== TAB BARO — BMP388 (SPI): trim Bosch, bù nhiệt, ra độ cao ===== */

static void bmpWrite(uint8_t r,uint8_t v){ SPI.beginTransaction(BMP_SPI); digitalWrite(BMP_CS,LOW); SPI.transfer(r&0x7F); SPI.transfer(v); digitalWrite(BMP_CS,HIGH); SPI.endTransaction();}
static void bmpRead(uint8_t r,uint8_t*b,uint8_t n){ SPI.beginTransaction(BMP_SPI); digitalWrite(BMP_CS,LOW); SPI.transfer(r|0x80); SPI.transfer(0); for(uint8_t i=0;i<n;i++)b[i]=SPI.transfer(0); digitalWrite(BMP_CS,HIGH); SPI.endTransaction();}
static uint8_t bmpRead8(uint8_t r){ uint8_t v; bmpRead(r,&v,1); return v;}
void bmpCal(){
  uint8_t d[21]; bmpRead(BMP_CAL_DATA,d,21);
  uint16_t t1=(d[1]<<8|d[0]),t2=(d[3]<<8|d[2]); int8_t t3=d[4];
  int16_t p1=(d[6]<<8|d[5]),p2=(d[8]<<8|d[7]); int8_t p3=d[9],p4=d[10];
  uint16_t p5=(d[12]<<8|d[11]),p6=(d[14]<<8|d[13]); int8_t p7=d[15],p8=d[16];
  int16_t p9=(d[18]<<8|d[17]); int8_t p10=d[19],p11=d[20];
  bcal.t1=(float)t1/0.00390625f; bcal.t2=(float)t2/1073741824.0f; bcal.t3=(float)t3/281474976710656.0f;
  bcal.p1=((float)p1-16384.0f)/1048576.0f; bcal.p2=((float)p2-16384.0f)/536870912.0f;
  bcal.p3=(float)p3/4294967296.0f; bcal.p4=(float)p4/137438953472.0f;
  bcal.p5=(float)p5/0.125f; bcal.p6=(float)p6/64.0f; bcal.p7=(float)p7/256.0f;
  bcal.p8=(float)p8/32768.0f; bcal.p9=(float)p9/281474976710656.0f;
  bcal.p10=(float)p10/281474976710656.0f; bcal.p11=(float)p11/36893488147419103232.0f;
}
float bmpTemp(uint32_t raw){ float d1=(float)raw-bcal.t1,d2=d1*bcal.t2; t_lin_b=d2+d1*d1*bcal.t3; return t_lin_b;}
float bmpPress(uint32_t raw){
  float d1,d2,d3,o1,o2,pp;
  d1=bcal.p6*t_lin_b; d2=bcal.p7*t_lin_b*t_lin_b; d3=bcal.p8*t_lin_b*t_lin_b*t_lin_b; o1=bcal.p5+d1+d2+d3;
  d1=bcal.p2*t_lin_b; d2=bcal.p3*t_lin_b*t_lin_b; d3=bcal.p4*t_lin_b*t_lin_b*t_lin_b; o2=(float)raw*(bcal.p1+d1+d2+d3);
  d1=(float)raw*(float)raw; d2=bcal.p9+bcal.p10*t_lin_b; d3=d1*d2; pp=d3+(float)raw*(float)raw*(float)raw*bcal.p11;
  return o1+o2+pp;
}
bool bmpInit(){
  pinMode(BMP_CS,OUTPUT); digitalWrite(BMP_CS,HIGH); delay(10);
  bmpWrite(BMP_CMD,0xB6); delay(10);
  bmpRead8(BMP_CHIP_ID); if(bmpRead8(BMP_CHIP_ID)!=BMP388_ID) return false;
  bmpCal();
  bmpWrite(BMP_OSR,0x03); bmpWrite(BMP_ODR,0x02); bmpWrite(BMP_CONFIG,0x02<<1); bmpWrite(BMP_PWR_CTRL,0x33);
  delay(50); return true;
}
void bmpAltitude(){
  uint8_t d[6]; bmpRead(BMP_DATA_0,d,6);
  uint32_t rp=(uint32_t)d[2]<<16|(uint32_t)d[1]<<8|d[0];
  uint32_t rt=(uint32_t)d[5]<<16|(uint32_t)d[4]<<8|d[3];
  bmpTemp(rt); float pr=bmpPress(rp)/100.0;
  BaroAltitude=44330.0*(1.0-pow(pr/SeaLevel,0.1903));
}

// =====================================================================
//  2D Kalman: fuse baro altitude + vertical acceleration
// =====================================================================
//  EKF ĐỘ CAO 3 TRẠNG THÁI: [độ_cao, vận_tốc, BIAS gia tốc kế]
//
//  Kalman 2 trạng thái cũ giả định gia tốc kế KHÔNG lệch. Thực tế nó
//  luôn có bias, và bias TRÔI theo nhiệt độ (motor nóng, nắng...).
//  Bias 0.01g = ~10 cm/s^2 -> tích phân vài chục giây là vận tốc sai
//  hàng chục cm/s, baro phải liên tục "kéo lại" -> độ cao dập dềnh.
//
//  Bộ lọc này thêm BIAS làm trạng thái thứ 3 và TỰ HỌC nó từ baro.
//  Đây là mánh cốt lõi trong EKF của ArduPilot/PX4.
//
//  Mô hình:   h' = v
//             v' = (a_đo − bias)
//             bias' = 0  (+ random walk chậm)
//
//  F = | 1  T  −T²/2 |      đo: z = h  ->  H = [1 0 0]
//      | 0  1  −T    |
