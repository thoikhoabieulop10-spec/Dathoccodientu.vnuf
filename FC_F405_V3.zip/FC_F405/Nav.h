#ifndef NAV_H
#define NAV_H

/* =====================================================================
 *  NAV.H — CHI CON KHAI BAO BIEN DUNG CHUNG GIUA CAC TAB.
 *
 *  KHONG CO THONG SO NAO DE CHINH O DAY. Moi thong so (chan cam, hieu
 *  chuan la ban, dau truc, PID, nguong GPS...) deu nam trong Config.h.
 * =====================================================================
 */

// ---------------- La ban ----------------
extern uint8_t  MagType, MagAddress;
extern int16_t  MagRawX, MagRawY, MagRawZ;
extern float    MagHorizFwd, MagHorizRight;
extern float    MagFieldNow;
extern float    CompassHeading;    // goc tu la ban (co the giat)
extern float    FusedHeading;      // goc da tron voi con quay - DUNG CAI NAY
extern bool     CompassHealthy;

// ---------------- Giu huong ----------------
extern float    PHeadingHold;
extern float    TargetHeading;
extern bool     HeadingHoldOn;

// ---------------- GPS ----------------
extern double   HomeLatitude, HomeLongitude;
extern float    LonScale;
extern bool     HomeSet;
extern float    PosNorthCm, PosEastCm;
extern float    VelNorthCms, VelEastCms;
extern uint8_t  GpsFixType, GpsSatCount;
extern double   GpsLatitude, GpsLongitude;
extern float    GpsHdop, GpsAltitude;
extern uint32_t GpsLastFixMs;
extern bool     GpsHealthy, GpsBaudOk;
extern float    GpsVelNorthCms, GpsVelEastCms;   // van toc Doppler tu RMC
extern uint32_t GpsVelMs;

// ---------------- Giu vi tri GPS ----------------
extern bool     PosHoldOn;
extern float    TargetNorthCm, TargetEastCm;
extern float    ErrPosNorth, ErrPosEast;
extern float    PrevErrPosNorth, PrevErrPosEast;
extern float    PrevItermPosNorth, PrevItermPosEast;
extern float    ErrVelNorth, ErrVelEast;
extern float    PrevErrVelNorth, PrevErrVelEast;
extern float    PrevItermVelNorth, PrevItermVelEast;
extern float    PosCmdPitch, PosCmdRoll;   // lenh nghieng do vong giu vi tri sinh ra

// ---------------- Trang thai ----------------
extern bool     Armed;

#endif
