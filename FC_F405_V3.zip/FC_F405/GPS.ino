/* =====================================================================
 *  TAB GPS — u-blox M10 (GEPRC GEP-M10) tren USART1 (PA9/PA10),
 *  phan tich NMEA KHONG CHAN.
 *  (ban da sua: kiem checksum, chot ten cau, chan truong rong,
 *   diem goc lay trung binh, chan buoc nhay vi tri)
 *
 *  NGUYEN TAC QUAN TRONG NHAT: ham gpsUpdate() phai tra ve nhanh va
 *  co thoi gian chay ON DINH. Vong dieu khien chi co 4000us; neu mot
 *  vong nao do bi keo dai thi xung ra ESC bi meo.
 *
 *  Vi vay moi vong chi doc TOI DA GPS_MAX_BYTES byte. O 115200bps, 4ms
 *  chi toi duoc toi da 46 byte, nen gioi han 48 vua du ca khi module
 *  dang phat lien tuc, ma van chan duoc truong hop xau.
 * =====================================================================
 */

HardwareSerial GpsSerial(PIN_GPS_RX, PIN_GPS_TX);

#define GPS_MAX_BYTES   48
#define GPS_BUF_LEN     100

// GPS_TIMEOUT_MS, HOME_SAMPLES, GPS_JUMP_MAX_CM: xem Config.h muc [11]

static char     gpsBuf[GPS_BUF_LEN];

/* Van toc Doppler tu cau RMC (xem gpsParseRmc). */
float    GpsVelNorthCms = 0, GpsVelEastCms = 0;
uint32_t GpsVelMs = 0;          // millis() luc co mau van toc moi
static uint8_t  gpsIdx = 0;

// Trang thai gom diem goc
static double   homeLatSum = 0, homeLonSum = 0;
static uint16_t homeCount  = 0;

/* Vi tri ban tin truoc, de chan buoc nhay.
 *
 * LUU Y DAT TEN: Arduino GHEP TAT CA tab .ino thanh MOT file truoc khi
 * bien dich, nen 'static' KHONG tao pham vi rieng cho tung tab nhu khi
 * chung la cac file .cpp tach biet. Hai tab dat trung ten se bao
 * "redefinition". NavControl.ino da co lastPosN/lastPosE roi, nen o day
 * phai dat tien to gps_ cho khac di. */
static float    gpsPrevPosN = 0, gpsPrevPosE = 0;
static bool     gpsPrevPosValid = false;

/* =====================================================================
 *  TU DO BAUDRATE + TU CAU HINH MODULE KHI KHOI DONG
 *
 *  Khong tin vao bo nho cua module: moi lan khoi dong, FC tu tim xem
 *  module dang o toc do nao, roi GUI LAI cau hinh can cho bay (chi phat
 *  GGA + RMC, GPS_RATE_HZ lan/giay, doi sang GPS_BAUD neu can). Nho vay
 *  module mat cai dat, bi khoi phuc goc, hay vua thay moi deu tu chay.
 *
 *  M10 chi nhan lenh CFG-VALSET (khoa + gia tri), khong nhan cac lenh
 *  kieu cu CFG-MSG / CFG-RATE / CFG-PRT cua dong M8.
 *
 *  THOI GIAN: tim thay ngay o GPS_BAUD thi ~1.3 giay trong setup().
 *  Khong thay thi gpsUpdate() tu do tiep, khong chan, khi CHUA ARM.
 * ===================================================================== */

// (GpsBaudOk khai bao trong Nav.h)

/* Gom tung byte thanh cau NMEA, dem cau co CHECKSUM DUNG. Khong dem ky
 * tu '$': doc sai toc do van ra rac, ma rac co the tinh co chua byte
 * 0x24 ('$') -> tuong nham la dung baud. */
static bool gpsLineFeed(char c, uint8_t *valid) {
  if (c == '$') { gpsIdx = 0; gpsBuf[gpsIdx++] = c; return false; }
  if (gpsIdx == 0 || gpsIdx >= GPS_BUF_LEN - 1) { gpsIdx = 0; return false; }
  if (c == '\r' || c == '\n') {
    gpsBuf[gpsIdx] = 0;
    gpsIdx = 0;
    if (gpsChecksumOk(gpsBuf)) { (*valid)++; return true; }
    return false;
  }
  gpsBuf[gpsIdx++] = c;
  return false;
}

// Nghe toi da ms mili-giay, true khi nhan du 2 cau NMEA checksum dung
static bool gpsListen(uint16_t ms) {
  uint32_t t0 = millis();
  uint8_t  valid = 0;
  gpsIdx = 0;
  while (millis() - t0 < ms) {
    while (GpsSerial.available()) {
      gpsLineFeed(GpsSerial.read(), &valid);
      if (valid >= 2) { gpsIdx = 0; return true; }
    }
  }
  gpsIdx = 0;
  return false;
}

/* Dong goi va gui mot ban tin UBX. Checksum Fletcher-8 tinh luc chay,
 * nen khong the go sai byte nao nhu khi viet tay ca ban tin. */
static void gpsSendUbx(uint8_t cls, uint8_t id, const uint8_t *p, uint16_t len) {
  uint8_t h[6] = { 0xB5, 0x62, cls, id, (uint8_t)(len & 0xFF), (uint8_t)(len >> 8) };
  uint8_t a = 0, b = 0;
  for (uint8_t i = 2; i < 6; i++) { a += h[i]; b += a; }
  for (uint16_t i = 0; i < len; i++) { a += p[i]; b += a; }
  GpsSerial.write(h, 6);
  if (len) GpsSerial.write(p, len);
  GpsSerial.write(a);
  GpsSerial.write(b);
  GpsSerial.flush();
  delay(120);
}

/* ---------------------------------------------------------------------
 *  u-blox M10: CFG-VALSET (class 0x06, id 0x8A)
 *    [phien ban 0][lop nho][0][0] + nhieu cap (khoa 4 byte, gia tri)
 *  Do dai gia tri nam trong chinh ma khoa (bit 28-30):
 *    1 = 1 bit (gui 1 byte), 2 = 1 byte, 3 = 2 byte, 4 = 4 byte.
 *  Lop nho: 1 = RAM (co hieu luc ngay), 2 = BBR (giu nho tu farad).
 *  Khong ghi FLASH moi lan khoi dong de khoi mon bo nho.
 * ------------------------------------------------------------------- */
#define UBX_KEY_UART1_BAUD   0x40520001UL
#define UBX_KEY_RATE_MEAS    0x30210001UL
#define UBX_KEY_RATE_NAV     0x30210002UL
#define UBX_KEY_DYNMODEL     0x20110021UL
#define UBX_KEY_GGA_UART1    0x209100BBUL
#define UBX_KEY_RMC_UART1    0x209100ACUL
#define UBX_KEY_GSA_UART1    0x209100C0UL
#define UBX_KEY_GSV_UART1    0x209100C5UL
#define UBX_KEY_GLL_UART1    0x209100CAUL
#define UBX_KEY_VTG_UART1    0x209100B1UL

static void gpsValset(uint8_t layers, const uint32_t *keys, const uint32_t *vals, uint8_t n) {
  uint8_t p[4 + 12 * 8];
  uint16_t len = 4;
  p[0] = 0; p[1] = layers; p[2] = 0; p[3] = 0;
  for (uint8_t k = 0; k < n && len + 8 <= sizeof(p); k++) {
    uint32_t key = keys[k], v = vals[k];
    for (uint8_t i = 0; i < 4; i++) p[len++] = (uint8_t)(key >> (8 * i));
    uint8_t sz = (key >> 28) & 0x07;
    uint8_t nb = (sz == 3) ? 2 : (sz == 4) ? 4 : 1;
    for (uint8_t i = 0; i < nb; i++) p[len++] = (uint8_t)(v >> (8 * i));
  }
  gpsSendUbx(0x06, 0x8A, p, len);
}

/* Gui cau hinh bay. changeBaud = module dang o toc do khac GPS_BAUD.
 * He ve tinh: GIU NGUYEN mac dinh cua M10 (GPS + Galileo + BeiDou +
 * QZSS + SBAS) - dung bo GEPRC quang cao, khong can doi. */
static void gpsConfigure(bool changeBaud) {
  static const uint32_t K[] = {
    UBX_KEY_GGA_UART1, UBX_KEY_RMC_UART1,
    UBX_KEY_GSA_UART1, UBX_KEY_GSV_UART1, UBX_KEY_GLL_UART1, UBX_KEY_VTG_UART1,
    UBX_KEY_RATE_MEAS, UBX_KEY_RATE_NAV, UBX_KEY_DYNMODEL };
  const uint32_t V[] = {
    1, 1,                     // GGA, RMC: moi chu ky
    0, 0, 0, 0,               // tat GSA, GSV, GLL, VTG
    1000 / GPS_RATE_HZ, 1,    // chu ky do (ms), 1 lan do = 1 lan tinh
    GPS_DYN_MODEL };
  gpsValset(0x03, K, V, sizeof(K) / sizeof(K[0]));        // RAM + BBR

  if (changeBaud) {
    const uint32_t kb = UBX_KEY_UART1_BAUD, vb = GPS_BAUD;
    gpsValset(0x03, &kb, &vb, 1);                          // module doi baud NGAY
    GpsSerial.end();
    GpsSerial.begin(GPS_BAUD);
    delay(300);
  }
}


void gpsInit(void) {
  gpsIdx          = 0;
  GpsHealthy      = false;
  homeLatSum      = homeLonSum = 0;
  homeCount       = 0;
  gpsPrevPosValid = false;
  GpsBaudOk       = false;

  // Thu dung toc do mong muon. Thay thi gui lai cau hinh bay (o RAM).
  GpsSerial.begin(GPS_BAUD);
  delay(100);
  if (gpsListen(1200)) {
    gpsConfigure(false);
    GpsBaudOk = true;
    return;
  }
  // Khong thay: GPS chua kip phat, dang o toc do khac, hoac long day.
  // gpsUpdate() se TU DO tat ca toc do khi drone chua arm, khong chan.
}

/* ---------------------------------------------------------------------
 *  KIEM CHECKSUM NMEA — bo sung quan trong nhat cua ban nay.
 *
 *  Cau NMEA co dang  $GNGGA,....*4F
 *  Checksum la XOR cua moi ky tu GIUA '$' va '*', viet duoi dang 2 chu
 *  so hex. Ban cu khong kiem tra gi ca: mot byte bi lat do nhieu tu ESC
 *  co the bien kinh do 105.58 thanh 105.68 — lech 10km — va vong giu vi
 *  tri se nghieng het co lao di.
 * ------------------------------------------------------------------- */
static int8_t gpsHexVal(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

static bool gpsChecksumOk(const char *s) {
  if (s[0] != '$') return false;

  uint8_t sum = 0;
  uint8_t i   = 1;
  while (s[i] && s[i] != '*') {
    sum ^= (uint8_t)s[i];
    i++;
    if (i >= GPS_BUF_LEN - 3) return false;     // khong tim thay '*'
  }
  if (s[i] != '*') return false;

  int8_t hi = gpsHexVal(s[i + 1]);
  int8_t lo = gpsHexVal(s[i + 2]);
  if (hi < 0 || lo < 0) return false;

  return sum == (uint8_t)((hi << 4) | lo);
}

// ---------------------------------------------------------------------
//  Lay truong thu n cua cau NMEA. Tra ve false neu truong rong.
// ---------------------------------------------------------------------
static bool gpsField(const char *s, uint8_t n, char *out, uint8_t maxLen) {
  uint8_t field = 0, j = 0;
  for (uint8_t i = 0; s[i]; i++) {
    if (s[i] == ',' || s[i] == '*') {
      if (field == n) break;
      field++; j = 0; continue;
    }
    if (field == n && j < maxLen - 1) out[j++] = s[i];
  }
  out[j] = 0;
  return (j > 0);
}

// ddmm.mmmmm -> do thap phan. PHAI tra ve double.
static double gpsToDegrees(const char *val, const char *hemi) {
  if (val[0] == 0) return 0;
  double raw = atof(val);
  int    deg = (int)(raw / 100);
  double min = raw - (deg * 100);
  double res = deg + min / 60.0;
  if (hemi[0] == 'S' || hemi[0] == 'W') res = -res;
  return res;
}

/* ---------------------------------------------------------------------
 *  Doi kinh vi do sang toa do phang (cm) so voi diem goc.
 *
 *  O khoang cach vai tram met, mat cau coi nhu mat phang duoc:
 *      1 do vi do   = 111320 m  (khong doi)
 *      1 do kinh do = 111320 m * cos(vi do)
 *  Bac duong, Dong duong. Don vi cm de khop voi EKF do cao san co.
 * ------------------------------------------------------------------- */
void gpsUpdatePosition(void) {
  if (!HomeSet) return;

  float n = (float)((GpsLatitude  - HomeLatitude)  * 11132000.0);
  float e = (float)((GpsLongitude - HomeLongitude) * 11132000.0 * LonScale);

  // ---- Chan buoc nhay vo ly ----
  if (gpsPrevPosValid) {
    float dn = n - gpsPrevPosN, de = e - gpsPrevPosE;
    if (dn * dn + de * de > GPS_JUMP_MAX_CM * GPS_JUMP_MAX_CM) {
      // Ban tin nay nhay qua xa. Bo qua, giu vi tri cu.
      // Neu nhay that (GPS vua bat lai fix), lan sau se dong bo lai.
      gpsPrevPosValid = false;
      return;
    }
  }

  PosNorthCm = n;
  PosEastCm  = e;
  gpsPrevPosN = n; gpsPrevPosE = e;
  gpsPrevPosValid = true;
}

/* ---------------------------------------------------------------------
 *  Chot diem goc.
 *
 *  SUA QUAN TRONG so voi ban cu:
 *    1. Ban cu chi doi GpsFixType > 0, nen co the chot home tren mot fix
 *       3 ve tinh HDOP 9 — thuong la fix te nhat ca phien bay. Bay gio
 *       doi GpsHealthy (>=6 ve tinh, HDOP < 2.5).
 *    2. Ban cu lay MOT mau duy nhat. Bay gio lay trung binh HOME_SAMPLES
 *       ban tin.
 *    3. Ban cu duoc goi tu FC_F405.ino BEN TRONG khoi #if NAV_DEBUG, nen
 *       khi tat debug de bay thi home KHONG BAO GIO duoc dat va giu vi
 *       tri khong bao gio vao duoc. Bay gio ham nay tu duoc goi trong
 *       gpsParse() moi khi co ban tin fix moi — HAY XOA dong
 *       "if (!HomeSet) gpsSetHome();" trong FC_F405.ino.
 * ------------------------------------------------------------------- */
void gpsSetHome(void) {
  if (HomeSet) return;

  if (!GpsHealthy) {                      // fix chua du tot -> gom lai tu dau
    homeLatSum = homeLonSum = 0;
    homeCount  = 0;
    return;
  }

  homeLatSum += GpsLatitude;
  homeLonSum += GpsLongitude;
  homeCount++;
  if (homeCount < HOME_SAMPLES) return;

  HomeLatitude  = homeLatSum / homeCount;
  HomeLongitude = homeLonSum / homeCount;
  LonScale      = cos(HomeLatitude * 0.0174533);
  PosNorthCm    = 0;
  PosEastCm     = 0;
  gpsPrevPosN      = 0;
  gpsPrevPosE      = 0;
  gpsPrevPosValid  = true;
  HomeSet       = true;
}

/* ---------------------------------------------------------------------
 *  VAN TOC TU CAU RMC — thay cho viec lay hieu vi tri.
 *
 *  $GNRMC,time,A,lat,N,lon,E,TOC_DO,HUONG,date,,,A*hh
 *           1  2  3  4  5 6    7     8
 *  M10 tinh van toc bang hieu ung DOPPLER (do lech tan so song ve
 *  tinh), khong phai bang cach tru hai vi tri. Nho vay:
 *    - khong bi cai "troi cham" cua vi tri lam nhieu
 *    - khong phai cho hai mau moi tinh duoc
 *  De yen tren ban, toc do chi 0.005-0.12 knot (duoi 6 cm/s).
 *
 *  Khi toc do rat thap, module co the de TRONG truong huong. Luc do van toc gan
 *  nhu bang 0 nen coi nhu 0. Neu truong huong trong ma toc do lai lon
 *  (hiem) thi bo mau, NavControl tu dung cach tru vi tri du phong.
 * ------------------------------------------------------------------- */
static void gpsParseRmc(const char *s) {
  char f[16];
  if (!gpsField(s, 2, f, sizeof(f)) || f[0] != 'A') return;   // A = hop le
  if (!gpsField(s, 7, f, sizeof(f))) return;
  float spdCms = atof(f) * 51.4444f;                          // knot -> cm/s

  if (gpsField(s, 8, f, sizeof(f))) {
    float crs = atof(f) * 0.0174533f;                         // 0 = Bac, CW
    GpsVelNorthCms = spdCms * cosf(crs);
    GpsVelEastCms  = spdCms * sinf(crs);
  } else if (spdCms < 15.0f) {
    GpsVelNorthCms = 0;
    GpsVelEastCms  = 0;
  } else {
    return;
  }
  GpsVelMs = millis();
}

// ---------------------------------------------------------------------
static void gpsParse(const char *s) {
  char f[16], hemi[4];

  /* Chot dung vi tri ten cau thay vi strstr.
   * strstr(s,"GGA") khop ca khi chuoi "GGA" tinh co nam giua payload.
   * Cau that luon co dang $xxGGA, nen ten nam o s[3..5].
   * Cach nay nhan ca $GPGGA (chi GPS) lan $GNGGA (GPS+GLONASS). */
  if (s[0] != '$') return;
  if (strncmp(s + 3, "RMC", 3) == 0) { gpsParseRmc(s); return; }
  if (strncmp(s + 3, "GGA", 3) != 0) return;

  // ---- Chat luong fix ----
  if (gpsField(s, 6, f, sizeof(f))) GpsFixType  = atoi(f);
  else                              GpsFixType  = 0;

  // Truong rong -> dat ve gia tri AN TOAN, khong giu gia tri cu.
  // Ban cu giu lai gia tri tot cuoi cung, nen HDOP co the ket o muc
  // dep trong khi module da mat fix.
  if (gpsField(s, 7, f, sizeof(f))) GpsSatCount = atoi(f);
  else                              GpsSatCount = 0;

  if (gpsField(s, 8, f, sizeof(f))) GpsHdop     = atof(f);
  else                              GpsHdop     = 99.9;

  if (gpsField(s, 9, f, sizeof(f))) GpsAltitude = atof(f);

  // ---- Toa do ----
  if (GpsFixType > 0 &&
      gpsField(s, 2, f, sizeof(f)) && gpsField(s, 3, hemi, sizeof(hemi))) {

    double lat = gpsToDegrees(f, hemi);
    double lon = GpsLongitude;
    bool   lonOk = false;

    if (gpsField(s, 4, f, sizeof(f)) && gpsField(s, 5, hemi, sizeof(hemi))) {
      lon   = gpsToDegrees(f, hemi);
      lonOk = true;
    }

    if (lonOk) {
      GpsLatitude  = lat;
      GpsLongitude = lon;
      GpsLastFixMs = millis();

      // Suc khoe phai tinh TRUOC khi chot home, vi gpsSetHome() doi
      // GpsHealthy. Tinh lai o day thay vi doi den cuoi gpsUpdate().
      GpsHealthy = (GpsFixType > 0) &&
                   (GpsSatCount >= GPS_MIN_SATS) && (GpsHdop < GPS_MAX_HDOP);

      gpsSetHome();
      gpsUpdatePosition();
    }
  }
}

/* ---------------------------------------------------------------------
 *  TU DO LAI GPS KHI CHUA ARM
 *
 *  Khi chua co du lieu hop le VA drone CHUA ARM, gpsUpdate() lan luot
 *  nghe o tung toc do trong danh sach duoi, moi toc do GPS_PROBE_MS,
 *  KHONG CHAN (chi gom cau va kiem checksum). Bat duoc o GPS_BAUD ->
 *  gui lai cau hinh bay. Bat duoc o toc do khac -> cau hinh lai va doi
 *  module sang GPS_BAUD (chan ~0.7s mot lan, drone dang nam tren dat).
 *
 *  Da arm roi thi KHONG BAO GIO do: doi baud giua chung se lam mat GPS.
 * ------------------------------------------------------------------- */
#define GPS_PROBE_MS  1200

// M10: xuat xuong 38400 (chip goc) hoac 115200 (GEPRC da cai san)
static const uint32_t GPS_PROBE_BAUDS[] = { GPS_BAUD, 38400, 115200, 9600, 57600 };
#define GPS_PROBE_N  (sizeof(GPS_PROBE_BAUDS) / sizeof(GPS_PROBE_BAUDS[0]))

static uint8_t  gpsProbeBaudIdx = 0;     // 0 = GPS_BAUD
static uint32_t gpsProbeT0      = 0;
static uint8_t  gpsProbeValid   = 0;     // so cau NMEA co checksum dung

static void gpsProbe(void) {
  if (gpsProbeT0 == 0) gpsProbeT0 = millis();

  // Gom cau va kiem checksum trong luc nghe (khong chan)
  uint8_t n = 0;
  while (GpsSerial.available() && n < GPS_MAX_BYTES) {
    gpsLineFeed(GpsSerial.read(), &gpsProbeValid);
    n++;
  }

  if (gpsProbeValid >= 2) {
    if (gpsProbeBaudIdx == 0) {
      DBG_PRINTLN(F("GPS: tim thay o GPS_BAUD -> gui cau hinh bay"));
      gpsConfigure(false);
      GpsBaudOk = true;
    } else {
      DBG_PRINT(F("GPS: tim thay o ")); DBG_PRINT(GPS_PROBE_BAUDS[gpsProbeBaudIdx]);
      DBG_PRINTLN(F(" -> cau hinh lai va doi sang GPS_BAUD..."));
      gpsConfigure(true);
      GpsBaudOk = gpsListen(1200);
      if (!GpsBaudOk) { GpsSerial.end(); GpsSerial.begin(GPS_BAUD); }
      gpsProbeBaudIdx = 0;
    }
    gpsIdx = 0;
    gpsProbeValid = 0;
    gpsProbeT0 = 0;
    return;
  }

  // Het thoi gian nghe o toc do nay -> sang toc do tiep theo
  // (bo qua muc trung voi GPS_BAUD, da nghe o vi tri 0 roi)
  if (millis() - gpsProbeT0 >= GPS_PROBE_MS) {
    do {
      gpsProbeBaudIdx = (gpsProbeBaudIdx + 1) % GPS_PROBE_N;
    } while (gpsProbeBaudIdx != 0 && GPS_PROBE_BAUDS[gpsProbeBaudIdx] == GPS_BAUD);
    GpsSerial.end();
    GpsSerial.begin(GPS_PROBE_BAUDS[gpsProbeBaudIdx]);
    gpsProbeValid = 0;
    gpsIdx = 0;
    gpsProbeT0 = millis();
  }
}

// ---------------------------------------------------------------------
//  Goi moi vong lap. Doc toi da GPS_MAX_BYTES byte roi tra ve ngay.
// ---------------------------------------------------------------------
static uint32_t gpsLastValidMs = 0;      // lan cuoi co cau checksum dung

void gpsUpdate(void) {
  /* Dang nam dat ma mat du lieu > 3 giay (vd rut ra cam lai, module
   * mat cai dat) -> quay lai che do do. Da arm thi khong bao gio. */
  if (GpsBaudOk && !Armed && gpsLastValidMs != 0 &&
      millis() - gpsLastValidMs > 3000) {
    GpsBaudOk = false;
    gpsLastValidMs = 0;
    DBG_PRINTLN(F("GPS: mat du lieu -> do lai baud"));
  }

  if (!GpsBaudOk && !Armed) { gpsProbe(); return; }

  // Dang do do dung giua chung (vd vua arm khi cong dang o toc do
  // khac) -> ve lai GPS_BAUD de gpsUpdate doc binh thuong.
  if (gpsProbeBaudIdx != 0) {
    gpsProbeBaudIdx = 0;
    GpsSerial.end();
    GpsSerial.begin(GPS_BAUD);
  }

  uint8_t n = 0;
  while (GpsSerial.available() && n < GPS_MAX_BYTES) {
    char c = GpsSerial.read();
    n++;
    if (c == '$') { gpsIdx = 0; gpsBuf[gpsIdx++] = c; }
    else if (gpsIdx > 0 && gpsIdx < GPS_BUF_LEN - 1) {
      if (c == '\r' || c == '\n') {
        gpsBuf[gpsIdx] = 0;
        // CHI phan tich khi checksum dung
        if (gpsChecksumOk(gpsBuf)) {
          GpsBaudOk = true;
          gpsLastValidMs = millis();
          gpsParse(gpsBuf);
        }
        gpsIdx = 0;
      } else gpsBuf[gpsIdx++] = c;
    }
  }

  // Tuoi ban tin duoc kiem o day (moi vong), khong phai trong gpsParse.
  GpsHealthy = (GpsFixType > 0) &&
               ((millis() - GpsLastFixMs) < GPS_TIMEOUT_MS) &&
               (GpsSatCount >= GPS_MIN_SATS) && (GpsHdop < GPS_MAX_HDOP);
}
