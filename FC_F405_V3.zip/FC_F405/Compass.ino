/* =====================================================================
 *  TAB COMPASS — IST8310 (module rieng) + GIU HUONG YAW
 *
 *  BA TANG, TACH RIENG DE DE SUA:
 *    1. DRIVER      doc 3 truc tho tu IST8310, khong chan vong lap bay
 *    2. HUONG DO    tru offset -> nhan ma tran -> doi truc -> bu nghieng
 *    3. HOP NHAT    tron con quay voi la ban -> FusedHeading
 *
 *  VI SAO PHAI HOP NHAT VOI CON QUAY
 *    La ban mot minh KHONG du de giu huong:
 *      - chi cap nhat 25Hz, cham hon vong bay 250Hz 10 lan
 *      - motor chay -> dong dien hang chuc ampe -> tu truong lech
 *        vai do, dao theo ga
 *      - nhieu 1-2 LSB tren ban kinh 148 -> +-1 do lung lay
 *    Con quay thi nguoc lai: rat nhanh, rat muot, nhung TROI theo thoi
 *    gian (vai do moi phut).
 *    Tron hai cai: lay toc do tu con quay, lay MOC TUYET DOI tu la ban.
 *    Day dung la bo loc bu (complementary filter) bac nhat.
 *
 *  BU NGHIENG
 *    Tu truong Ha Noi chuc xuong 33 do, nen thanh phan thang dung lon
 *    hon ca thanh phan ngang. Khi drone nghieng, phan thang dung do ro
 *    sang hai truc ngang:  nghieng 10 do -> sai 6 do,  20 do -> 11 do.
 *    Bay thi nghieng 20-30 do la thuong, nen khong bu thi vo dung.
 *
 *  CHAN NHIEU (gating)
 *    Mau nao co |M| lech qua MAG_FIELD_TOL so voi luc hieu chuan thi
 *    BO, khong dua vao bo loc. Do la luc dong co keo dong lon, hoac
 *    bay qua khung sat. Luc do con quay tu giu huong mot minh — troi
 *    vai do mot phut, van tot hon la bi keo lech chuc do.
 * =====================================================================
 */

#include <Wire.h>

TwoWire MagWire(PIN_MAG_SDA, PIN_MAG_SCL);

/* IST8310: dia chi 0x0C..0x0F tuy chan CAD0/CAD1 cua module.
 * Thanh ghi: 0x00 WHO_AM_I (=0x10), 0x02 STAT1 (bit0 DRDY),
 *            0x03..0x08 X,Y,Z little-endian, 0x0A CNTL1 (1 = do don),
 *            0x0B CNTL2 (1 = reset mem), 0x41 AVGCNTL, 0x42 PDCNTL. */
#define IST_WHOAMI_VAL   0x10
#define IST_ADDR_MIN     0x0C
#define IST_ADDR_MAX     0x0F

// Ma tran hieu chuan sat mem (theo hang) — so lieu trong Nav.h
static const float MagSoft[3][3] = { MAG_SOFT_R0, MAG_SOFT_R1, MAG_SOFT_R2 };

static uint8_t  magLoopCount   = 0;
static bool     magPending     = false;   // da kich do, dang cho ket qua
static bool     magFilterReady = false;
static uint32_t magLastGoodMs  = 0;       // lan cuoi co mau DUNG (qua gate)
static uint32_t magRejectCount = 0;       // so mau bi loai (debug)

// ---------------------------------------------------------------------
static bool magReadReg(uint8_t addr, uint8_t reg, uint8_t *val) {
  MagWire.beginTransmission(addr);
  MagWire.write(reg);
  if (MagWire.endTransmission() != 0) return false;
  if (MagWire.requestFrom(addr, (uint8_t)1) != 1) return false;
  *val = MagWire.read();
  return true;
}

static bool magWriteReg(uint8_t reg, uint8_t val) {
  MagWire.beginTransmission(MagAddress);
  MagWire.write(reg);
  MagWire.write(val);
  return (MagWire.endTransmission() == 0);
}

void compassInit(void) {
  MagWire.begin();
  MagWire.setClock(MAG_I2C_CLOCK);
  delay(50);

  MagType = 0;
  for (uint8_t a = IST_ADDR_MIN; a <= IST_ADDR_MAX; a++) {
    uint8_t id;
    if (magReadReg(a, 0x00, &id) && id == IST_WHOAMI_VAL) {
      MagType = 3;                 // 3 = IST8310
      MagAddress = a;
      break;
    }
  }
  if (MagType == 0) { CompassHealthy = false; return; }

  magWriteReg(0x0B, 0x01);         // CNTL2: reset mem
  delay(20);
  magWriteReg(0x41, 0x24);         // AVGCNTL: trung binh 16 lan X,Y,Z
  magWriteReg(0x42, 0xC0);         // PDCNTL: pulse duration normal (bat buoc)
  delay(10);
  magWriteReg(0x0A, 0x01);         // kich do lan dau
  magPending     = true;
  magFilterReady = false;
  magLastGoodMs  = millis();
}

/* ---------------------------------------------------------------------
 *  TANG 1 — doc 3 truc tho.
 *
 *  IST8310 chi co che do DO DON: moi lan do phai kich (CNTL1 = 1), cho
 *  6-10ms roi moi doc duoc. KHONG duoc cho trong vong lap bay 250Hz
 *  (4ms/vong), nen tach lam hai nhip:
 *      nhip A -> kich do        (1 lenh ghi,  ~0.3ms)
 *      nhip B -> doc 6 byte     (~0.9ms)
 *  Voi MAG_LOOP_DIV = 5 (moi nhip 20ms) thi la ban ra so moi 25Hz.
 *
 *  Thu tu byte: X_L, X_H, Y_L, Y_H, Z_L, Z_H (little-endian). Dung bien
 *  hi/lo tam — C++ khong quy dinh ben nao cua '|' duoc tinh truoc, viet
 *  (read() << 8) | read() co the bi hoan doi byte.
 * ------------------------------------------------------------------- */
static bool magReadRaw(void) {
  uint8_t st;
  if (!magReadReg(MagAddress, 0x02, &st)) return false;
  if (!(st & 0x01)) return false;                       // chua do xong

  MagWire.beginTransmission(MagAddress);
  MagWire.write(0x03);
  if (MagWire.endTransmission() != 0) return false;
  if (MagWire.requestFrom(MagAddress, (uint8_t)6) != 6) return false;

  uint8_t lo, hi;
  int16_t v[3];
  for (uint8_t i = 0; i < 3; i++) {
    lo = MagWire.read(); hi = MagWire.read();
    v[i] = (int16_t)((hi << 8) | lo);
    if (v[i] > 5400 || v[i] < -5400) return false;      // ngoai dai +-1600uT
  }
  MagRawX = v[0]; MagRawY = v[1]; MagRawZ = v[2];
  return true;
}

/* ---------------------------------------------------------------------
 *  TANG 2 — tu so tho ra goc phuong vi da bu nghieng.
 *  Tra ve false neu mau bi CHAN vi tu truong bat thuong.
 * ------------------------------------------------------------------- */
static bool magComputeHeading(float *headingOut) {
  // 1. Tru offset (sat cung) roi nhan ma tran (sat mem, ke ca lech truc)
  float dx = (float)MagRawX - MAG_OFFSET_X;
  float dy = (float)MagRawY - MAG_OFFSET_Y;
  float dz = (float)MagRawZ - MAG_OFFSET_Z;

  float mx = MagSoft[0][0] * dx + MagSoft[0][1] * dy + MagSoft[0][2] * dz;
  float my = MagSoft[1][0] * dx + MagSoft[1][1] * dy + MagSoft[1][2] * dz;
  float mz = MagSoft[2][0] * dx + MagSoft[2][1] * dy + MagSoft[2][2] * dz;

  // 2. CHAN NHIEU: do lon tu truong phai gan bang luc hieu chuan
  MagFieldNow = sqrtf(mx * mx + my * my + mz * mz);
#if MAG_CAL_DONE
  float dev = fabsf(MagFieldNow - MAG_FIELD_NOMINAL) / MAG_FIELD_NOMINAL;
  if (dev > MAG_FIELD_TOL) { magRejectCount++; return false; }
#endif

  // 3. Doi tu truc cam bien sang truc drone (xem MAG_FWD/RIGHT/DOWN)
  float f = MAG_FWD;
  float r = MAG_RIGHT;
  float d = MAG_DOWN;

  // 4. Bu nghieng — cong thuc chuan AN4248 cua Freescale.
  //    Nghieng qua MAG_MAX_TILT_DEG thi khong tin nua: luc do sai so
  //    goc nghieng cua Kalman anh huong manh hon ca so do la ban.
  float roll  = MAG_ROLL_SIGN  * KalmanAngleRoll;
  float pitch = MAG_PITCH_SIGN * KalmanAnglePitch;
  if (fabsf(roll) > MAG_MAX_TILT_DEG || fabsf(pitch) > MAG_MAX_TILT_DEG) {
    magRejectCount++;
    return false;
  }
  roll  *= 0.0174533f;
  pitch *= 0.0174533f;
  float sr = sinf(roll),  cr = cosf(roll);
  float sp = sinf(pitch), cp = cosf(pitch);

  float horizFwd   = f * cp + r * sr * sp + d * cr * sp;
  float horizRight = r * cr - d * sr;

  // 5. Loc tren HAI THANH PHAN NGANG, khong loc tren goc.
  //    Loc tren goc se quay nguoc ca vong khi so nhay tu 359 ve 0.
  if (!magFilterReady) {
    MagHorizFwd = horizFwd; MagHorizRight = horizRight;
    magFilterReady = true;
  } else {
    MagHorizFwd   += MAG_FILTER_ALPHA * (horizFwd   - MagHorizFwd);
    MagHorizRight += MAG_FILTER_ALPHA * (horizRight - MagHorizRight);
  }

  // 6. Goc phuong vi: 0 = Bac, tang theo chieu kim dong ho
  float h = atan2f(-MagHorizRight, MagHorizFwd) * 57.29578f;
  h += MAG_DECLINATION + MAG_HEADING_OFFSET;
  while (h <    0) h += 360.0f;
  while (h >= 360) h -= 360.0f;
  *headingOut = h;
  return true;
}

// Sai lech a - b, dua ve -180..+180
static float angDiff(float a, float b) {
  float e = a - b;
  while (e >  180.0f) e -= 360.0f;
  while (e < -180.0f) e += 360.0f;
  return e;
}

/* ---------------------------------------------------------------------
 *  TANG 3 — HOP NHAT CON QUAY + LA BAN (bo loc bu bac nhat)
 *
 *  Goi MOI VONG LAP (250Hz):
 *      FusedHeading += toc do yaw cua con quay * 4ms
 *  Khi co mau la ban moi (25Hz) va mau do qua duoc cac phep chan:
 *      FusedHeading += MAG_FUSE_GAIN * (goc la ban - FusedHeading)
 *
 *  MAG_FUSE_GAIN 0.02 nghia la moi mau keo 2% ve phia la ban. O 25Hz,
 *  hang so thoi gian khoang 2 giay: du cham de loc het nhieu motor,
 *  du nhanh de xoa troi con quay.
 * ------------------------------------------------------------------- */
void compassUpdate(void) {
  if (MagType == 0) { CompassHealthy = false; return; }

  // --- Con quay: chay moi vong, khong phu thuoc la ban ---
  FusedHeading += YAW_GYRO_SIGN * RateYaw * 0.004f;
  while (FusedHeading <    0) FusedHeading += 360.0f;
  while (FusedHeading >= 360) FusedHeading -= 360.0f;

  // --- La ban: chi cham vao bus moi MAG_LOOP_DIV vong ---
  magLoopCount++;
  if (magLoopCount < MAG_LOOP_DIV) return;
  magLoopCount = 0;

  if (!magPending) {                       // nhip kich do
    magPending = magWriteReg(0x0A, 0x01);
    return;
  }
  magPending = false;                      // nhip doc

  if (!magReadRaw()) {
    if (millis() - magLastGoodMs > MAG_HEALTH_TIMEOUT_MS) CompassHealthy = false;
    return;
  }

  float hMag;
  if (!magComputeHeading(&hMag)) {
    // Mau bi chan (nhieu tu / nghieng qua nhieu). Con quay tu giu huong.
    if (millis() - magLastGoodMs > MAG_HEALTH_TIMEOUT_MS) CompassHealthy = false;
    return;
  }
  CompassHeading = hMag;
  magLastGoodMs  = millis();

  // Lan dau co so: dong bo thang, khong cho keo tu tu.
  // MAG_CAL_DONE = 0 (chua hieu chuan lai): van hien huong mui nhung KHONG
  // bao la ban khoe -> khong giu huong, khong giu vi tri.
  if (!CompassHealthy) {
    FusedHeading   = hMag;
    TargetHeading  = hMag;
    CompassHealthy = (MAG_CAL_DONE != 0);
    return;
  }

  FusedHeading += MAG_FUSE_GAIN * angDiff(hMag, FusedHeading);
  while (FusedHeading <    0) FusedHeading += 360.0f;
  while (FusedHeading >= 360) FusedHeading -= 360.0f;
}

/* ---------------------------------------------------------------------
 *  Sai lech giua huong mong muon va huong hien tai, -180..+180.
 * ------------------------------------------------------------------- */
float headingError(float target) {
  return angDiff(target, FusedHeading);
}

/* ---------------------------------------------------------------------
 *  GIU HUONG YAW
 *
 *  Goi sau khi da tinh DesiredRateYaw tu can lai. Neu dang giu huong
 *  thi ham GHI DE DesiredRateYaw.
 *
 *  KHI NAO GIU
 *    - da arm, ga tren nguong (dang bay, khong phai dang de tren ban)
 *    - can yaw o giua (nguoi lai khong doi huong)
 *    - la ban con khoe
 *  Thieu mot dieu kien la nha ra ngay va bam huong hien tai lam muc
 *  tieu moi — de khi vua tha can, drone khong giat ve huong cu.
 *
 *  VONG CHI CO P
 *    Dau ra la TOC DO yaw, ma vong rate ben duoi da co I roi. Them I o
 *    day la hai tang tich phan noi tiep — rat de dao. Nguoi ta lam
 *    gimbal, may bay, tau thuy deu chi dung P o tang goc.
 * ------------------------------------------------------------------- */
void headingHoldUpdate(float yawStick, float throttleStick) {
  if (MagType == 0) return;

  bool stickMoved = fabsf(yawStick - 1500.0f) > YAW_STICK_DEADBAND;
  bool flying     = Armed && (throttleStick > HEADING_HOLD_MIN_THR);

  if (!flying || stickMoved || !CompassHealthy) {
    HeadingHoldOn = false;
    TargetHeading = FusedHeading;     // bam theo huong hien tai
    return;
  }

  if (!HeadingHoldOn) {
    TargetHeading = FusedHeading;     // vua tha can -> chot huong nay
    HeadingHoldOn = true;
  }

  /* Vung chet MEM: tru bot HEADING_DEADBAND_DEG thay vi cat phang, de
   * lenh tang tu 0 len lien tuc khi ra khoi vung chet (khong giat). */
  float err = headingError(TargetHeading);
  if      (err >  HEADING_DEADBAND_DEG) err -= HEADING_DEADBAND_DEG;
  else if (err < -HEADING_DEADBAND_DEG) err += HEADING_DEADBAND_DEG;
  else                                  err  = 0.0f;

  float rate = PHeadingHold * err;
  if (rate >  HEADING_RATE_MAX) rate =  HEADING_RATE_MAX;
  if (rate < -HEADING_RATE_MAX) rate = -HEADING_RATE_MAX;
  DesiredRateYaw = rate;
}

/* ---------------------------------------------------------------------
 *  In chan doan (chi khi DEBUG_ARM = 1, THAO CANH QUAT).
 *
 *  KIEM TRA DAU CON QUAY:
 *    Xoay drone sang PHAI (chieu kim dong ho nhin tu tren xuong).
 *    Ca "Mag" lan "Fused" phai CUNG TANG. Neu Fused giam trong khi Mag
 *    tang thi doi YAW_GYRO_SIGN trong Nav.h sang dau nguoc lai.
 * ------------------------------------------------------------------- */
void compassDebugPrint(void) {
#if DEBUG_ARM
  static uint32_t t = 0;
  if (millis() - t < 500) return;
  t = millis();
  DBG_PRINT(F("[MAG] "));
  if (MagType == 0) { DBG_PRINTLN(F("KHONG THAY IST8310")); return; }
  DBG_PRINT(F("Mag "));   DBG_PRINT(CompassHeading, 1);
  DBG_PRINT(F("  Fused ")); DBG_PRINT(FusedHeading, 1);
  DBG_PRINT(F("  Target ")); DBG_PRINT(TargetHeading, 1);
  DBG_PRINT(F("  |M| ")); DBG_PRINT(MagFieldNow, 0);
  DBG_PRINT(F("/")); DBG_PRINT((int)MAG_FIELD_NOMINAL);
  DBG_PRINT(F("  RateYaw ")); DBG_PRINT(RateYaw, 1);
  DBG_PRINT(F("  Hold ")); DBG_PRINT(HeadingHoldOn ? 1 : 0);
  DBG_PRINT(F("  Loai ")); DBG_PRINT(magRejectCount);
  DBG_PRINT(F("  Khoe ")); DBG_PRINTLN(CompassHealthy ? 1 : 0);
#endif
}
