/* =====================================================================
 *  TAB FILTERS — LỌC TẦN SỐ CHO GYRO (biquad bậc 2)
 *
 *  VÌ SAO KHÔNG DÙNG EMA NỮA
 *    EMA (alpha) là lọc bậc 1: dốc -6dB/octave.
 *    Biquad Butterworth bậc 2: dốc -12dB/octave.
 *    => Cùng mức khử nhiễu ở tần số cao, biquad TRỄ ÍT HƠN trong dải
 *       làm việc (0-30Hz nơi PID cần phản ứng nhanh).
 *
 *  HAI LOẠI BỘ LỌC
 *    LOW-PASS : cắt mọi thứ trên tần số cắt. Dùng làm nền.
 *    NOTCH    : cắt HẸP đúng một tần số (rung motor), gần như không
 *               ảnh hưởng các tần số khác => rất ít trễ.
 *
 *  Công thức RBJ Audio EQ Cookbook — chuẩn dùng trong Betaflight/INAV.
 * =====================================================================
 */

// (struct Biquad định nghĩa trong Filters.h — xem lý do ở đó)

// Các bộ lọc dùng cho 3 trục gyro.
// Đặt ở tab Filters vì Arduino nối tab theo thứ tự: FC_F405 -> Baro ->
// EKF -> Filters -> IMU -> ... nên IMU.ino (dùng sau) thấy được chúng.
Biquad LpfRoll, LpfPitch, LpfYaw;
Biquad NotchRoll, NotchPitch, NotchYaw;

// ---- Khởi tạo LOW-PASS Butterworth ----
//   fc : tần số cắt (Hz)   fs : tần số lấy mẫu (Hz, ở đây 250)
void biquadLowPass(Biquad *f, float fc, float fs) {
  if (fc >= fs * 0.5f) fc = fs * 0.45f;        // chống vượt Nyquist
  float w0 = 2.0f * PI * fc / fs;
  float cw = cosf(w0), sw = sinf(w0);
  float Q  = 0.7071f;                          // Butterworth
  float alpha = sw / (2.0f * Q);
  float a0 = 1.0f + alpha;
  f->b0 = ((1.0f - cw) * 0.5f) / a0;
  f->b1 = (1.0f - cw) / a0;
  f->b2 = f->b0;
  f->a1 = (-2.0f * cw) / a0;
  f->a2 = (1.0f - alpha) / a0;
  f->x1 = f->x2 = f->y1 = f->y2 = 0;
}

// ---- Khởi tạo NOTCH (cắt hẹp một tần số) ----
//   fc : tần số cần cắt (Hz)
//   bw : bề rộng dải cắt (Hz). Hẹp = ít trễ nhưng phải đúng tần số.
void biquadNotch(Biquad *f, float fc, float bw, float fs) {
  if (fc >= fs * 0.5f) fc = fs * 0.45f;
  if (bw < 1.0f) bw = 1.0f;
  float w0 = 2.0f * PI * fc / fs;
  float cw = cosf(w0), sw = sinf(w0);
  float Q  = fc / bw;
  float alpha = sw / (2.0f * Q);
  float a0 = 1.0f + alpha;
  f->b0 = 1.0f / a0;
  f->b1 = (-2.0f * cw) / a0;
  f->b2 = 1.0f / a0;
  f->a1 = (-2.0f * cw) / a0;
  f->a2 = (1.0f - alpha) / a0;
  f->x1 = f->x2 = f->y1 = f->y2 = 0;
}

// ---- Chạy một mẫu qua bộ lọc ----
float biquadApply(Biquad *f, float x) {
  float y = f->b0*x + f->b1*f->x1 + f->b2*f->x2
                    - f->a1*f->y1 - f->a2*f->y2;
  f->x2 = f->x1;  f->x1 = x;
  f->y2 = f->y1;  f->y1 = y;
  return y;
}

// ---- Khởi tạo tất cả bộ lọc gyro (gọi một lần trong setup) ----
void filtersInit() {
  const float fs = 250.0f;                     // tần số vòng lặp

  biquadLowPass(&LpfRoll,  GYRO_LPF_HZ, fs);
  biquadLowPass(&LpfPitch, GYRO_LPF_HZ, fs);
  biquadLowPass(&LpfYaw,   GYRO_LPF_HZ, fs);

#if GYRO_NOTCH_ENABLE
  biquadNotch(&NotchRoll,  GYRO_NOTCH_HZ, GYRO_NOTCH_BW, fs);
  biquadNotch(&NotchPitch, GYRO_NOTCH_HZ, GYRO_NOTCH_BW, fs);
  biquadNotch(&NotchYaw,   GYRO_NOTCH_HZ, GYRO_NOTCH_BW, fs);
#endif
}

/* =====================================================================
 *  CÁCH CHỌN TẦN SỐ
 *
 *  GYRO_LPF_HZ (low-pass nền)
 *    Cao quá  -> còn nhiễu, motor nóng, drone rung
 *    Thấp quá -> trễ nhiều, PID dao động
 *    Dải hợp lý cho drone 1.7kg: 40-80 Hz. Bắt đầu 60.
 *    (EMA alpha=0.15 cũ tương đương LPF ~6Hz -- TRỄ RẤT NHIỀU.
 *     Biquad 60Hz vừa sạch hơn vừa nhanh hơn nhiều.)
 *
 *  GYRO_NOTCH_HZ (cắt rung motor)
 *    Tính từ vòng tua:  f(Hz) = RPM / 60
 *    Motor 2312 800kV, pin 3S (12.6V), hover ~50% ga:
 *        RPM ≈ 800 * 12.6 * 0.5 ≈ 5000
 *        f   ≈ 5000/60 ≈ 83 Hz
 *    Nhưng ở 250Hz lấy mẫu, Nyquist = 125Hz -> 83Hz vẫn đo được.
 *    ĐO THỰC TẾ tốt hơn tính toán: xem hướng dẫn trong Config.h
 *
 *  GYRO_NOTCH_BW (bề rộng)
 *    Hẹp (10-15Hz): ít trễ, nhưng lệch tần là mất tác dụng
 *    Rộng (25-40Hz): bắt được cả khi vòng tua đổi, trễ nhiều hơn
 *    Vòng tua drone đổi liên tục theo ga -> nên để RỘNG: 30Hz
 * =====================================================================
 */
