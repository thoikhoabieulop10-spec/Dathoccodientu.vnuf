/* ===== TAB MOTORS — PWM ra 4 ESC (TIM3, 250Hz) ===== */

void setMotors(uint32_t m1, uint32_t m2, uint32_t m3, uint32_t m4) {
  MotorTimer->setCaptureCompare(1, constrain(m1, 1000, 2000));
  MotorTimer->setCaptureCompare(2, constrain(m2, 1000, 2000));
  MotorTimer->setCaptureCompare(3, constrain(m3, 1000, 2000));
  MotorTimer->setCaptureCompare(4, constrain(m4, 1000, 2000));
}

void motor_init(void) {
  MotorTimer = new HardwareTimer(TIM3);
  MotorTimer->setMode(1, TIMER_OUTPUT_COMPARE_PWM1, M1_PIN);
  MotorTimer->setMode(2, TIMER_OUTPUT_COMPARE_PWM1, M2_PIN);
  MotorTimer->setMode(3, TIMER_OUTPUT_COMPARE_PWM1, M3_PIN);
  MotorTimer->setMode(4, TIMER_OUTPUT_COMPARE_PWM1, M4_PIN);
  MotorTimer->setPrescaleFactor(MotorTimer->getTimerClkFreq() / 1000000);
  MotorTimer->setOverflow(ESC_PERIOD_US);
  setMotors(1000, 1000, 1000, 1000);
  MotorTimer->resume();
}
