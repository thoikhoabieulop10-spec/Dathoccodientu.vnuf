/* ===== TAB PID — hàm PID dùng chung cho mọi tầng ===== */

void pid_equation(float Error, float P, float I, float D,
                  float PrevError, float PrevIterm) {
  float Pterm = P * Error;
  float Iterm = PrevIterm + I * (Error + PrevError) * 0.004 / 2.0;
  // Anti-windup clamp. Tightened from 400 to 150 to stop the integral
  // term slowly building up and causing a diagonal wobble after a couple
  // of minutes. If the drone drifts (never quite levels), raise toward
  // 200. If it still wobbles after minutes, lower toward 100.
  if (Iterm > 150) Iterm = 150; else if (Iterm < -150) Iterm = -150;
  float Dterm = D * (Error - PrevError) / 0.004;
  float out = Pterm + Iterm + Dterm;
  if (out > 400) out = 400; else if (out < -400) out = -400;
  PIDReturn[0] = out; PIDReturn[1] = Error; PIDReturn[2] = Iterm;
}
/* =====================================================================
 *  Ban co GIOI HAN RIENG cho tung tang.
 *
 *  VI SAO CAN
 *    pid_equation() chot cung Iterm trong +/-150 va output trong +/-400.
 *    Hai so nay hop ly cho vong RATE, noi output la lenh motor tinh bang
 *    micro giay. Nhung vong VAN TOC NGANG co output la GOC NGHIENG, bi
 *    chan o POS_ANGLE_MAX = 12 do. I-term duoc phep tich luy toi 150
 *    trong khi dai huu ich chi la 12 — thua gap 12 lan. Khi gio day drone
 *    lech, I-term chay len 150; drone ve toi diem neo roi ma tich phan
 *    van con hang tram chu ky nua moi xa het -> VOT LO va dao dong.
 *
 *  pid_equation() cu duoc GIU NGUYEN, khong doi mot ky tu nao, nen vong
 *  rate va angle da tune van chay y het nhu truoc.
 * ===================================================================== */
void pid_equation_lim(float Error, float P, float I, float D,
                      float PrevError, float PrevIterm,
                      float iLimit, float outLimit) {
  float Pterm = P * Error;
  float Iterm = PrevIterm + I * (Error + PrevError) * 0.004 / 2.0;
  if (Iterm >  iLimit) Iterm =  iLimit;
  else if (Iterm < -iLimit) Iterm = -iLimit;
  float Dterm = D * (Error - PrevError) / 0.004;
  float out = Pterm + Iterm + Dterm;
  if (out >  outLimit) out =  outLimit;
  else if (out < -outLimit) out = -outLimit;
  PIDReturn[0] = out; PIDReturn[1] = Error; PIDReturn[2] = Iterm;
}

/* Xoa TAT CA trang thai tich phan.
 *
 * SUA: ban cu chi xoa vong rate va angle. Bon tich phan cua vong vi tri,
 * hai cua vong do cao va hai cua vong van toc dung van con nguyen sau
 * khi cat ga giua chung — lan arm sau se mang theo tich phan cu. */
void reset_pid(void) {
  PrevErrorRateRoll = PrevErrorRatePitch = PrevErrorRateYaw = 0;
  PrevItermRateRoll = PrevItermRatePitch = PrevItermRateYaw = 0;
  PrevErrorAngleRoll = PrevErrorAnglePitch = 0;
  PrevItermAngleRoll = PrevItermAnglePitch = 0;

  // ---- Vong do cao ----
  PrevErrorAltitude = 0;         PrevItermAltitude = 0;
  PrevErrorVelocityVertical = 0; PrevItermVelocityVertical = 0;

  // ---- Lenh nghieng do vong giu vi tri sinh ra ----
  PosCmdPitch = PosCmdRoll = 0;

  // ---- Giu huong yaw ----
  HeadingHoldOn = false;
  TargetHeading = FusedHeading;

  // ---- Vong giu vi tri GPS ----
  PrevErrPosNorth = PrevErrPosEast = 0;
  PrevItermPosNorth = PrevItermPosEast = 0;
  PrevErrVelNorth = PrevErrVelEast = 0;
  PrevItermVelNorth = PrevItermVelEast = 0;
  PosHoldOn = false;
}
