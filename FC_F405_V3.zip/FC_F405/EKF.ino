/* =====================================================================
 *  TAB EKF — BỘ LỌC ĐỘ CAO 3 TRẠNG THÁI  [h, v, bias_accel]
 *
 *  Nguồn đo độ cao: CHỈ barometer (đã bỏ lidar MTF-01P).
 *
 *  Mô hình:   h'    = v
 *             v'    = (a_do - bias)
 *             bias' = 0  (+ random walk cham)
 *
 *  Fm = | 1  dt  -dt^2/2 |    do: z = h  ->  H = [1 0 0]
 *       | 0  1   -dt     |
 *       | 0  0    1      |
 * =====================================================================
 */

void kalman_2d(){
  const float dt = 0.004f;

  float h = EkfX[0], v = EkfX[1], b = EkfX[2];
  float acc = AccZInertial - b;

  // ---- DỰ ĐOÁN trạng thái ----
  EkfX[0] = h + v*dt + 0.5f*dt*dt*acc;
  EkfX[1] = v + dt*acc;

  // ---- DỰ ĐOÁN hiệp phương sai: P = Fm*P*Fm' + Q ----
  float Fm[3][3] = {{1, dt, -0.5f*dt*dt},
                    {0, 1,  -dt},
                    {0, 0,   1}};
  float FP[3][3], Pnew[3][3];

  for (int i=0;i<3;i++) for (int j=0;j<3;j++){
    FP[i][j] = 0;
    for (int k=0;k<3;k++) FP[i][j] += Fm[i][k] * EkfP[k][j];
  }
  for (int i=0;i<3;i++) for (int j=0;j<3;j++){
    Pnew[i][j] = 0;
    for (int k=0;k<3;k++) Pnew[i][j] += FP[i][k] * Fm[j][k];
  }

  float av = KAL2D_ACC_VAR;
  Pnew[0][0] += 0.25f*dt*dt*dt*dt*av;   Pnew[0][1] += 0.5f*dt*dt*dt*av;
  Pnew[1][0] += 0.5f*dt*dt*dt*av;       Pnew[1][1] += dt*dt*av;
  Pnew[2][2] += dt * EKF_BIAS_VAR;

  for (int i=0;i<3;i++) for (int j=0;j<3;j++) EkfP[i][j] = Pnew[i][j];

  // ---- Đo độ cao: barometer (cm so với lúc khởi động) ----
  float z_meas = (BaroAltitude - AltitudeStart) * 100.0f;
  float R_meas = KAL2D_BARO_R;           // ±30cm (nhiễu)

  // ---- SỬA bằng measurement: z = h, H = [1 0 0] ----
  float Sinn = EkfP[0][0] + R_meas;
  float K0 = EkfP[0][0] / Sinn;
  float K1 = EkfP[1][0] / Sinn;
  float K2 = EkfP[2][0] / Sinn;
  float y  = z_meas - EkfX[0];
  EkfX[0] += K0*y;  EkfX[1] += K1*y;  EkfX[2] += K2*y;

  float Pupd[3][3];
  for (int j=0;j<3;j++){
    Pupd[0][j] = EkfP[0][j] - K0*EkfP[0][j];
    Pupd[1][j] = EkfP[1][j] - K1*EkfP[0][j];
    Pupd[2][j] = EkfP[2][j] - K2*EkfP[0][j];
  }
  for (int i=0;i<3;i++) for (int j=0;j<3;j++) EkfP[i][j] = Pupd[i][j];

  // chặn bias
  if (EkfX[2] >  EKF_BIAS_LIMIT) EkfX[2] =  EKF_BIAS_LIMIT;
  if (EkfX[2] < -EKF_BIAS_LIMIT) EkfX[2] = -EKF_BIAS_LIMIT;

  // xuất ra
  AltitudeKalman = EkfX[0];
  VelocityKalman = EkfX[1];
  AccelBiasEst   = EkfX[2];

  // debug: cho biết đang dùng nguồn nào (chỉ khi cần)
  #if DEBUG_EKF
  {
    static uint32_t dbgT = 0;
    if (millis() - dbgT > 1000) {
      dbgT = millis();
      Serial.print(F("EKF baro z=")); Serial.print(z_meas, 1);
      Serial.print(F(" h=")); Serial.print(AltitudeKalman, 1);
      Serial.println();
    }
  }
  #endif
}
