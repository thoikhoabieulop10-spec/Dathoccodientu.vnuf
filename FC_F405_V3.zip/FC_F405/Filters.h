#ifndef FILTERS_H
#define FILTERS_H

/* Định nghĩa kiểu Biquad phải nằm trong file .h.
 *
 * LÝ DO: Arduino tự sinh prototype hàm và đặt lên ĐẦU file đã ghép.
 * Nếu struct Biquad định nghĩa trong .ino, prototype
 *   void biquadLowPass(Biquad*, float, float);
 * sẽ xuất hiện TRƯỚC định nghĩa struct -> lỗi biên dịch.
 * Đưa struct vào .h và #include ở tab chính thì tránh được.
 */
struct Biquad {
  float b0, b1, b2, a1, a2;      // hệ số
  float x1, x2, y1, y2;          // bộ nhớ mẫu cũ
};

#endif
