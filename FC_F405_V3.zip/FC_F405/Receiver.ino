/* ===== TAB RECEIVER — đọc PPM từ FS-iA6B (TIM2 input capture) =====
 *
 * Toan bo phan PPM chi duoc bien dich khi RX_PROTOCOL == 0.
 * Khi dung ELRS (RX_PROTOCOL == 1) thi tab CRSF.ino thay the, va ba ham
 * receiver_init / receiver_alive / read_receiver nam ben do.
 * stickExpo() nam NGOAI khoi bao ve vi ca hai giao thuc deu dung. */

#if RX_PROTOCOL == 0

void ppmCallback(void) {
  uint32_t now = PPMTimer->getCaptureCompare(1);
  uint32_t d = now - ppmLastCapture;
  ppmLastCapture = now;
  if (d > PPM_SYNC_US) {
    if (ppmIndex > 0) { ChannelNumber = ppmIndex; ppmLastFrameMs = millis(); }
    ppmIndex = 0; return;
  }
  if (d < PPM_MIN_US || d > PPM_MAX_US) return;
  if (ppmIndex < PPM_CH) { ReceiverValue[ppmIndex] = (float)d; ppmIndex++; }
}
bool receiver_alive(void) { return (millis() - ppmLastFrameMs) < PPM_TIMEOUT_MS; }
void read_receiver(float *o) {
  noInterrupts();
  for (int i = 0; i < 4; i++) o[i] = ReceiverValue[i];
  interrupts();
}

void receiver_init(void) {
  PPMTimer = new HardwareTimer(TIM2);
  PPMTimer->setMode(1, TIMER_INPUT_CAPTURE_RISING, PPM_PIN);
  PPMTimer->setPrescaleFactor(PPMTimer->getTimerClkFreq() / 1000000);
  PPMTimer->setOverflow(0xFFFFFFFF);
  PPMTimer->attachInterrupt(1, ppmCallback);
  PPMTimer->resume();
}

#endif  // RX_PROTOCOL == 0

/* =====================================================================
 *  ĐƯỜNG CONG EXPO cho cần điều khiển
 *
 *  Trả về hệ số -1.0 .. +1.0 theo đường cong, nhân với MAX_ANGLE_DEG
 *  để ra góc nghiêng yêu cầu.
 *
 *  Công thức:  out = expo·x³ + (1-expo)·x     với x = độ lệch cần (-1..1)
 *
 *  x³ làm cong: gần 0 thì x³ rất nhỏ (nhẹ tay), gần 1 thì x³ ≈ 1
 *  (toàn lực). Trộn tuyến tính với x để không quá "chết" ở giữa.
 * ===================================================================== */
float stickExpo(float rxValue) {
  float x = (rxValue - 1500.0f) / 500.0f;      // chuẩn hoá -1..+1
  if (x >  1.0f) x =  1.0f;
  if (x < -1.0f) x = -1.0f;

  // vùng chết nhỏ quanh giữa, khử rung tay và nhiễu cần
  if (x > -STICK_DEADBAND && x < STICK_DEADBAND) return 0.0f;

  return STICK_EXPO * (x*x*x) + (1.0f - STICK_EXPO) * x;
}
