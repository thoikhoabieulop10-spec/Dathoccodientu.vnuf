"""Retro radio case for the "Nhu Y" English chatbot (ESP32-S3 + 4.0" ST7796 MSP4021).

Parts (print each STL separately, no supports needed):
  1. nhuy_radio_front.stl  - shell: front with screen window + speaker grille, sides, handle
  2. nhuy_radio_back.stl   - back cover, screwed on with 4 x M3 screws
  3. nhuy_radio_knob.stl   - decorative radio knob (print 2)

Coordinates: X = width, Y = height (up), Z = depth. Front face lies on z = 0
(print the shell with the front face on the bed). Viewed from the front the
screen is on the right and the speaker grille on the left.
All sizes in mm. Change the parameters below if your parts measure differently.
"""
import manifold3d as mf
from manifold3d import Manifold, CrossSection
import numpy as np, sys, os

mf.set_circular_segments(64)
OUT = sys.argv[1] if len(sys.argv) > 1 else "."

# ---------------- parameters ----------------
W, H, D = 200.0, 140.0, 72.0      # outer box size (width, height, depth)
R = 14.0                          # corner radius (front view)
WALL = 2.6                        # wall thickness
FRONT = 2.6                       # front wall thickness

# Display: LCDwiki MSP4021 (4.0" ST7796 + XPT2046)
PCB_W, PCB_H = 61.74, 108.04
VA_W, VA_H = 56.88, 85.22         # touch viewing area (window size)
WIN_MARGIN = 0.6                  # extra clearance around the viewing area
VA_DY = 0.0                       # move window up(+)/down(-) relative to PCB centre
GLASS_W, GLASS_H, GLASS_T = 61.2, 95.0, 4.1   # glass + touch stack (recess behind window)
HOLE_DX, HOLE_DY = 54.90, 102.04  # mounting hole spacing
STANDOFF_H = GLASS_T              # front wall -> PCB distance
SCREEN_X = -48.0                  # screen centre (negative = right side when seen from the front)

# Speaker (8 ohm 2 W): grille + glue frame
GRILLE_X = 46.0                   # grille centre (left side seen from the front)
GRILLE_Y = 8.0
GRILLE_D = 78.0                   # grille diameter
HOLE_D, HOLE_PITCH = 3.4, 6.0
SPK_W, SPK_H = 30.0, 40.0         # speaker body inner frame (hot-glue the speaker in)

# Back cover screws (M3, self-tapping into 2.6 mm holes)
POST_D, POST_HOLE = 8.0, 2.6
POST_INSET = 9.0
LIP = 1.6                         # back cover inset lip depth

# ---------------- helpers ----------------
def rrect(w, h, r):
    r = min(r, w / 2 - 0.01, h / 2 - 0.01)
    c = CrossSection.circle(r)
    pts = [(w / 2 - r, h / 2 - r), (-w / 2 + r, h / 2 - r), (w / 2 - r, -h / 2 + r), (-w / 2 + r, -h / 2 + r)]
    return CrossSection.batch_hull([c.translate(p) for p in pts])

def box(w, h, d, x=0, y=0, z=0):
    return Manifold.cube([w, h, d], True).translate([x, y, z])

def cyl(r, h, x=0, y=0, z=0):
    return Manifold.cylinder(h, r, r).translate([x, y, z])

# ---------------- front shell ----------------
outer = Manifold.extrude(rrect(W, H, R), D)
inner = Manifold.extrude(rrect(W - 2 * WALL, H - 2 * WALL, R - WALL), D).translate([0, 0, FRONT])
shell = outer - inner

# front face decoration: a shallow 1 mm raised "faceplate" border groove
groove = Manifold.extrude(rrect(W - 10, H - 10, R - 5), 0.8) - Manifold.extrude(rrect(W - 12, H - 12, R - 6), 0.8)
shell = shell - groove

# screen window with chamfer (wider at the front face)
ww, wh = VA_W + 2 * WIN_MARGIN, VA_H + 2 * WIN_MARGIN
window = Manifold.extrude(rrect(ww, wh, 1.5), FRONT + 0.2, scale_top=(1.0, 1.0)).translate([SCREEN_X, VA_DY, -0.1])
chamfer = Manifold.extrude(rrect(ww + 3.0, wh + 3.0, 2.5), 1.2, scale_top=(ww / (ww + 3.0), wh / (wh + 3.0))).translate([SCREEN_X, VA_DY, -0.01])
shell = shell - window - chamfer
# engraved frame line around the screen (radio dial look; front face stays flat for printing)
bezel = (Manifold.extrude(rrect(PCB_W + 10, PCB_H + 8, 7), 0.8) - Manifold.extrude(rrect(PCB_W + 7, PCB_H + 5, 6), 0.8)).translate([SCREEN_X, 0, -0.01])
shell = shell - bezel

# display standoffs (screw M3 / M2.5 through the PCB holes)
for sx in (-1, 1):
    for sy in (-1, 1):
        px, py = SCREEN_X + sx * HOLE_DX / 2, sy * HOLE_DY / 2
        post = cyl(3.0, STANDOFF_H, px, py, FRONT) - cyl(1.25, STANDOFF_H + 1, px, py, FRONT)
        shell = shell + post
# side rails that centre the glass (2 per long side)
for sx in (-1, 1):
    for sy in (-1, 1):
        rx = SCREEN_X + sx * (GLASS_W / 2 + 1.0)
        shell = shell + box(1.6, 14, STANDOFF_H, rx, sy * 28, FRONT + STANDOFF_H / 2)

# speaker grille: hex pattern of round holes inside a circle
holes = []
n = int(GRILLE_D / HOLE_PITCH) + 2
for j in range(-n, n + 1):
    for i in range(-n, n + 1):
        hx = i * HOLE_PITCH + (HOLE_PITCH / 2 if j % 2 else 0)
        hy = j * HOLE_PITCH * 0.866
        if hx * hx + hy * hy <= (GRILLE_D / 2 - HOLE_D) ** 2:
            holes.append(cyl(HOLE_D / 2, FRONT + 2, GRILLE_X + hx, GRILLE_Y + hy, -1))
shell = shell - Manifold.batch_boolean(holes, mf.OpType.Add)
# decorative ring around the grille
ring = (cyl(GRILLE_D / 2 + 5, 0.8, GRILLE_X, GRILLE_Y, -0.01) - cyl(GRILLE_D / 2 + 3, 0.9, GRILLE_X, GRILLE_Y, -0.05))
shell = shell - ring
# speaker glue frame behind the grille
frame = (box(SPK_W + 4, SPK_H + 4, 6, GRILLE_X, GRILLE_Y, FRONT + 3) - box(SPK_W + 0.6, SPK_H + 0.6, 8, GRILLE_X, GRILLE_Y, FRONT + 3))
shell = shell + frame

# knob sockets (radio dials) below the grille
for kx in (GRILLE_X - 26, GRILLE_X + 26):
    shell = shell - cyl(2.1, FRONT + 0.2, kx, -H / 2 + 17, -0.1)  # 4.2 mm hole for the knob peg

# back cover screw posts (in the 4 corners)
for sx in (-1, 1):
    for sy in (-1, 1):
        px, py = sx * (W / 2 - POST_INSET), sy * (H / 2 - POST_INSET)
        post = cyl(POST_D / 2, D - FRONT - LIP, px, py, FRONT) - cyl(POST_HOLE / 2, D, px, py, FRONT + 4)
        # tie the post to the corner walls
        post = post + box(POST_D, 3.0, D - FRONT - LIP, px + sx * POST_D / 2, py, FRONT + (D - FRONT - LIP) / 2) \
                    + box(3.0, POST_D, D - FRONT - LIP, px, py + sy * POST_D / 2, FRONT + (D - FRONT - LIP) / 2)
        shell = shell + (post - cyl(POST_HOLE / 2, D, px, py, FRONT + 4))

# carry handle on top (radio style), printed with the shell
HX, HT, HD = 120.0, 9.0, 20.0     # handle span, bar thickness, depth
handle_cs = (rrect(HX, 2 * 26, 10) - rrect(HX - 2 * HT, 2 * (26 - HT), 4)).translate([0, H / 2 - 4])
handle_cs = handle_cs - CrossSection.square([W, H], True).translate([0, 0])   # keep only the part above the box
handle = Manifold.extrude(handle_cs, HD)   # starts on the print bed (front face) -> no supports
shell = shell + handle

# 2 foot rails under the box (vertical ribs while printing -> no supports)
for fx in (-W / 2 + 28, W / 2 - 28):
    shell = shell + box(30, 4, D - 6, fx, -H / 2 - 1.5, (D - 6) / 2 + 3)

# ---------------- back cover ----------------
CL = 0.35   # fit clearance
back_plate = Manifold.extrude(rrect(W, H, R), 2.4)
back_lip = Manifold.extrude(rrect(W - 2 * WALL - 2 * CL, H - 2 * WALL - 2 * CL, R - WALL), LIP).translate([0, 0, 2.4]) - \
           Manifold.extrude(rrect(W - 2 * WALL - 2 * CL - 3.2, H - 2 * WALL - 2 * CL - 3.2, R - WALL - 1.6), LIP + 0.1).translate([0, 0, 2.35])
back = back_plate + back_lip
for sx in (-1, 1):
    for sy in (-1, 1):
        px, py = sx * (W / 2 - POST_INSET), sy * (H / 2 - POST_INSET)
        back = back - cyl(1.7, 10, px, py, -1) - cyl(3.1, 1.8, px, py, -0.01)   # M3 hole + head recess
        back = back - (Manifold.cylinder(LIP + 0.2, POST_D / 2 + 0.6, POST_D / 2 + 0.6).translate([px, py, 2.4]))  # clear the posts
# vent slots
for i in range(-6, 7):
    back = back - box(3.0, 34, 6, i * 8.0, 22, 1)
# USB cable notch at the bottom edge + SD/reset access window
back = back - box(16, 12, 10, -48, -H / 2 + 6, 1)
back = back - Manifold.extrude(rrect(34, 18, 4), 6).translate([-48, -30, -1])
# text-free label recess
back = back - Manifold.extrude(rrect(70, 20, 4), 0.6).translate([40, -38, -0.01])

# ---------------- knob ----------------
# printed upside-down: flat top on the bed, peg pointing up
knob = Manifold.cylinder(9, 7.2, 9) + cyl(1.95, 6, 0, 0, 9)
for k in range(18):
    knob = knob - box(1.2, 2.2, 9, 0, 8.2, 4.5).rotate([0, 0, k * 20])
knob = knob - box(1.4, 6, 1.2, 0, 3.5, 0.4)   # pointer line on the top face

def save(m, name):
    mesh = m.to_mesh()
    v = np.asarray(mesh.vert_properties)[:, :3]
    f = np.asarray(mesh.tri_verts)
    from stl import mesh as stlmesh
    s = stlmesh.Mesh(np.zeros(len(f), dtype=stlmesh.Mesh.dtype))
    s.vectors = v[f]
    path = os.path.join(OUT, name)
    s.save(path)
    bb = m.bounding_box()
    print(name, "tris", len(f), "bbox", [round(x, 1) for x in bb], "genus", m.genus(), "status", m.status())

os.makedirs(OUT, exist_ok=True)
save(shell, "nhuy_radio_front.stl")
save(back, "nhuy_radio_back.stl")
save(knob, "nhuy_radio_knob.stl")
np.save(os.path.join(OUT, "_parts.npy"), np.array([0]))
