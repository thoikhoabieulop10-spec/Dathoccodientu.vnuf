LingoBot - firmware xiaozhi-esp32 tuy bien (ESP32-S3 N16R8 + man hinh 4.0" ST7796 cam ung)

Chon MOT trong hai thu muc:
  ban_doc_hop_radio  : man hinh dung (320x480) - dung cho hop kieu dai radio
  ban_ngang_robot    : man hinh nam ngang (480x320) - dung cho robot 50 cm

Cach dung:
 1. Fork https://github.com/78/xiaozhi-esp32 tren GitHub.
 2. Chep tat ca file trong thu muc da chon vao main/boards/bread-compact-wifi-lcd/
    (ghi de file cung ten).
 3. Vao tab Actions -> doi build xong -> tai Artifacts -> lay merged-binary.bin.
 4. Nap bang https://espressif.github.io/esptool-js/ o dia chi 0x0.
 5. Lan dau bat may: cham vao tam 3 dau + do de hieu chinh cam ung.
 6. Ban ngang bi lon nguoc: sua LINGOBOT_FLIP_180 thanh 1 trong config.h.

So do chan: xem trang du an LingoBot.
minimp3.h: thu vien giai ma MP3 cua lieff (CC0), https://github.com/lieff/minimp3
