/* =====================================================================
 *  FC_F405.ino — FILE CHÍNH (tên file PHẢI trùng tên thư mục)
 *
 *  QUAN TRỌNG — TRÁNH LỖI "redefinition of ...":
 *    Trong thư mục sketch chỉ được có MỘT file chính chứa setup()/loop().
 *    Nếu còn file FC_F405_Debug.ino (hoặc bản FC_F405.ino cũ) nằm cùng
 *    thư mục, Arduino sẽ GỘP cả hai lại -> mọi biến toàn cục bị định
 *    nghĩa 2 lần. HÃY XÓA file cũ trước khi chép bộ file này vào.
 *
 *  Bản này tích hợp sẵn chẩn đoán ARM qua Serial (DEBUG_ARM trong
 *  Config.h). Đặt DEBUG_ARM 0 trước khi bay thật.
 * =====================================================================
 */

#include <SPI.h>
#include <HardwareTimer.h>
#include "Config.h"
#include "Filters.h"

/* ---- Macro in debug: DEBUG_ARM (Config.h) = 0 thi moi lenh Serial
 * ben duoi bien thanh khong lam gi ca -> vong lap bay hoan toan sach. */
#if DEBUG_ARM
  #define DBG_PRINT(...)    Serial.print(__VA_ARGS__)
  #define DBG_PRINTLN(...)  Serial.println(__VA_ARGS__)
#else
  #define DBG_PRINT(...)
  #define DBG_PRINTLN(...)
#endif


#define REG_CONFIG         0x1A
#define REG_GYRO_CONFIG    0x1B
#define REG_ACCEL_CONFIG   0x1C
#define REG_ACCEL_CONFIG_2 0x1D
#define REG_SMPLRT_DIV     0x19
#define REG_ACCEL_XOUT_H   0x3B
#define REG_SIGPATH_RESET  0x68
#define REG_USER_CTRL      0x6A
#define REG_PWR_MGMT_1     0x6B
#define REG_PWR_MGMT_2     0x6C
#define REG_WHO_AM_I       0x75
#define ICM_WHOAMI         0x12

static SPISettings SPI_SLOW(1000000, MSBFIRST, SPI_MODE3);
static SPISettings SPI_FAST(8000000, MSBFIRST, SPI_MODE3);


HardwareTimer *PPMTimer;
HardwareTimer *MotorTimer;

float RateRoll, RatePitch, RateYaw;
float RateCalibrationRoll, RateCalibrationPitch, RateCalibrationYaw;
float AccX, AccY, AccZ;
float AngleRoll, AnglePitch;
float RateRollFilt = 0, RatePitchFilt = 0, RateYawFilt = 0;

float KalmanAngleRoll = 0,  KalmanUncertaintyAngleRoll  = 2*2;
float KalmanAnglePitch = 0, KalmanUncertaintyAnglePitch = 2*2;
float Kalman1DOutput[] = {0, 0};

#define BMP_CHIP_ID 0x00
#define BMP_DATA_0  0x04
#define BMP_PWR_CTRL 0x1B
#define BMP_OSR     0x1C
#define BMP_ODR     0x1D
#define BMP_CONFIG  0x1F
#define BMP_CAL_DATA 0x31
#define BMP_CMD     0x7E
#define BMP388_ID   0x50
static SPISettings BMP_SPI(8000000, MSBFIRST, SPI_MODE0);
struct { float t1,t2,t3,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11; } bcal;
float SeaLevel = 1013.25;
float BaroAltitude = 0, AltitudeStart = 0, t_lin_b;
float AccZInertial;

float AltitudeKalman = 0, VelocityKalman = 0;
float EkfX[3] = {0, 0, 0};
float EkfP[3][3] = {{100,0,0},{0,100,0},{0,0,25}};
float AccelBiasEst = 0;

float DesiredVelocityVertical, ErrorVelocityVertical;
float PrevErrorVelocityVertical, PrevItermVelocityVertical;
float InputVertical;
bool  AltHoldOn = false;

float DesiredAltitude, ErrorAltitude;
float PrevErrorAltitude, PrevItermAltitude;
float DesiredVel;

#define RX_CH  16
volatile float ReceiverValue[RX_CH] = {0};
volatile int   ChannelNumber = 0;
static volatile uint32_t ppmLastCapture = 0;
static volatile uint8_t  ppmIndex = 0;
static volatile uint32_t ppmLastFrameMs = 0;

float DesiredRateRoll, DesiredRatePitch, DesiredRateYaw;
float ErrorRateRoll, ErrorRatePitch, ErrorRateYaw;
float InputRoll, InputThrottle, InputPitch, InputYaw;
float PrevErrorRateRoll, PrevErrorRatePitch, PrevErrorRateYaw;
float PrevItermRateRoll, PrevItermRatePitch, PrevItermRateYaw;
float PIDReturn[] = {0, 0, 0};

float DesiredAngleRoll, DesiredAnglePitch;
float ErrorAngleRoll, ErrorAnglePitch;
float PrevErrorAngleRoll, PrevErrorAnglePitch;
float PrevItermAngleRoll, PrevItermAnglePitch;

float MotorInput1, MotorInput2, MotorInput3, MotorInput4;
uint32_t LoopTimer;
uint32_t LoopMaxUs = 0;

float YawAngleDeg = 0;
float BatteryVoltage = 0;




bool Armed = false;

// =====================================================================
//  DEBUG ARM — in rõ từng bước
// =====================================================================

void calibrateGyro(void) {
  RateCalibrationRoll = RateCalibrationPitch = RateCalibrationYaw = 0;
  for (int i = 0; i < 2000; i++) {
    gyro_signals();
    RateCalibrationRoll  += RateRoll;
    RateCalibrationPitch += RatePitch;
    RateCalibrationYaw   += RateYaw;
#if RX_PROTOCOL == 1
    crsfUpdate();
#endif
    delay(1);
  }
  RateCalibrationRoll  /= 2000;
  RateCalibrationPitch /= 2000;
  RateCalibrationYaw   /= 2000;
}

void setup() {
  Serial.begin(115200);   // 115200: in nhanh, it chan vong lap hon 57600
  delay(500);
  pinMode(LED_GREEN, OUTPUT); pinMode(LED_RED, OUTPUT);
  pinMode(LED_GPS, OUTPUT);   digitalWrite(LED_GPS, LOW);   // ban nay khong dung den GPS
  digitalWrite(LED_RED, HIGH);

  DBG_PRINTLN(F("\n========================================"));
  DBG_PRINTLN(F("  FC_F405 DEBUG — Chuan doan ARM"));
  DBG_PRINTLN(F("========================================"));

  DBG_PRINT(F("1. Khoi tao ICM-20602... "));
  if (!icmInit()) {
    DBG_PRINTLN(F("LOI!"));
    while (1) { digitalWrite(LED_RED, !digitalRead(LED_RED)); delay(150); }
  }
  DBG_PRINTLN(F("OK"));

  DBG_PRINT(F("2. Khoi tao bo loc... ")); filtersInit(); DBG_PRINTLN(F("OK"));
  DBG_PRINT(F("3. Khoi tao receiver... ")); receiver_init(); DBG_PRINTLN(F("OK"));
  DBG_PRINT(F("4. Khoi tao motor... ")); motor_init(); DBG_PRINTLN(F("OK"));

  DBG_PRINT(F("6. Calibrate gyro... "));
  calibrateGyro();
  DBG_PRINTLN(F("OK"));

  DBG_PRINT(F("7. Khoi tao baro... "));
  if (bmpInit()) {
    float s = 0;
    for (int i = 0; i < 50; i++) { bmpAltitude(); s += BaroAltitude; delay(10); }
    AltitudeStart = s / 50.0;
    DBG_PRINTLN(F("OK"));
  } else {
    DBG_PRINTLN(F("LOI (bo qua)"));
  }

  EkfX[0] = 0; EkfX[1] = 0; EkfX[2] = 0;
  EkfP[0][0]=100; EkfP[0][1]=0;   EkfP[0][2]=0;
  EkfP[1][0]=0;   EkfP[1][1]=100; EkfP[1][2]=0;
  EkfP[2][0]=0;   EkfP[2][1]=0;   EkfP[2][2]=25;


  DBG_PRINTLN(F("\n--- BAT DAU CHO ARM ---"));
  DBG_PRINTLN(F("Dieu kien de thoat setup():"));
  DBG_PRINTLN(F("  a) Co song receiver"));
  DBG_PRINTLN(F("  b) Ga ve day (900-1050us)"));
  DBG_PRINTLN(F("  c) Cong tac ARM o vi tri TAT (<=1500)"));
  DBG_PRINTLN(F("\nDang cho...\n"));

  uint32_t printT = 0;
  while (true) {
#if RX_PROTOCOL == 1
    crsfUpdate();
#endif

    bool song = receiver_alive();
    float t = 0, a = 2000;
    if (song) {
      noInterrupts(); t = ReceiverValue[2]; a = ReceiverValue[ARM_CHANNEL]; interrupts();
    }

    bool gaDay = (t > 900 && t < 1050);
    bool armTat = (a <= ARM_THRESHOLD);

    // In moi 500ms
    if (millis() - printT >= 500) {
      printT = millis();
      DBG_PRINT(F("Song=")); DBG_PRINT(song ? F("OK") : F("MAT"));
      DBG_PRINT(F(" | Ga=")); DBG_PRINT((int)t);
      DBG_PRINT(F(" (")); DBG_PRINT(gaDay ? F("DAY,OK") : F("CHUA DAY"));
      DBG_PRINT(F(") | Arm=")); DBG_PRINT((int)a);
      DBG_PRINT(F(" (")); DBG_PRINT(armTat ? F("TAT,OK") : F("DANG BAT"));
      DBG_PRINTLN(F(")"));

      if (!song) {
        DBG_PRINTLN(F("  -> LOI: Khong co song! Kiem tra day noi ELRS."));
        DBG_PRINT(F("     CRSF_PIN_RX=")); DBG_PRINT((int)CRSF_PIN_RX);
        DBG_PRINT(F(" CRSF_PIN_TX=")); DBG_PRINTLN((int)CRSF_PIN_TX);
        DBG_PRINTLN(F("     Day dung: ELRS TX -> PA1, ELRS RX -> PA0"));
      } else if (!gaDay) {
        DBG_PRINTLN(F("  -> LOI: Ga chua ve day! Ha cac ga xuong."));
      } else if (!armTat) {
        DBG_PRINTLN(F("  -> LOI: Cong tac ARM dang BAT! Gat ve TAT de qua."));
      } else {
        DBG_PRINTLN(F("  -> TAT CA OK! Thoat setup..."));
        delay(200);
        break;
      }
    }

    setMotors(1000, 1000, 1000, 1000);
    digitalWrite(LED_RED, !digitalRead(LED_RED));
    delay(50);
  }

  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, HIGH);
  DBG_PRINTLN(F("\n>>> DA SAN SANG BAY <<<"));
  DBG_PRINTLN(F("Gat cong tac ARM len de ARM.\n"));
  LoopTimer = micros();
}

// =====================================================================
void loop() {
  gyro_signals();
  RateRoll  -= RateCalibrationRoll;
  RatePitch -= RateCalibrationPitch;
  RateYaw   -= RateCalibrationYaw;

  YawAngleDeg += RateYaw * 0.004;
  if (YawAngleDeg >  180) YawAngleDeg -= 360;
  if (YawAngleDeg < -180) YawAngleDeg += 360;

  kalman_1d(KalmanAngleRoll, KalmanUncertaintyAngleRoll, RateRoll, AngleRoll);
  KalmanAngleRoll = Kalman1DOutput[0];
  KalmanUncertaintyAngleRoll = Kalman1DOutput[1];
  kalman_1d(KalmanAnglePitch, KalmanUncertaintyAnglePitch, RatePitch, AnglePitch);
  KalmanAnglePitch = Kalman1DOutput[0];
  KalmanUncertaintyAnglePitch = Kalman1DOutput[1];

  {
    float rr = KalmanAngleRoll * 0.0174533, pr = KalmanAnglePitch * 0.0174533;
    AccZInertial = -sin(pr)*AccX + cos(pr)*sin(rr)*AccY + cos(pr)*cos(rr)*AccZ;
    AccZInertial = (AccZInertial - 1.0) * 9.81 * 100.0;
    bmpAltitude();
    kalman_2d();
  }


  // ---- FAILSAFE ----
  if (!receiver_alive()) {
    setMotors(THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT);
    reset_pid();
    Armed = false;
    digitalWrite(LED_GREEN, LOW); digitalWrite(LED_RED, HIGH);
#if DEBUG_ARM
    static uint32_t failT = 0;
    if (millis() - failT > 1000) {
      failT = millis();
      DBG_PRINTLN(F("[FAILSAFE] Mat song! Disarm."));
    }
#endif
    LoopTimer = micros(); return;
  }

  /* ---- DEN BAO ----
   *   xanh sang, do tat : co song, binh thuong
   *   xanh tat,  do sang: MAT SONG (failsafe, o tren)
   * Den PB5 (GPS) khong dung trong ban nay. */
  digitalWrite(LED_RED, LOW); digitalWrite(LED_GREEN, HIGH);

#if RX_PROTOCOL == 1
  crsfUpdate();
  crsfTelemetryUpdate();      // gui do cao, goc, ve tinh ve tay cam
#endif
  float rx[4]; read_receiver(rx);

  // ---- DEBUG ARM trong loop ----
  // CANH BAO: in Serial trong vong lap bay CHAN nhieu mili-giay.
  // Chi dung khi chan doan tren ban (thao canh!). Dat DEBUG_ARM 0 de bay.
#if DEBUG_ARM
  static uint32_t armDbgT = 0;
  if (millis() - armDbgT > 1000) {
    armDbgT = millis();
    float chArm; noInterrupts(); chArm = ReceiverValue[ARM_CHANNEL]; interrupts();
    DBG_PRINT(F("[ARM] Ga=")); DBG_PRINT((int)rx[2]);
    DBG_PRINT(F(" ArmSw=")); DBG_PRINT((int)chArm);
    DBG_PRINT(F(" Armed=")); DBG_PRINT(Armed ? F("YES") : F("NO"));
    if (!Armed) {
      if (chArm <= ARM_THRESHOLD) DBG_PRINT(F(" (can gat ARM len)"));
      else if (rx[2] >= ARM_THROTTLE_MAX) DBG_PRINT(F(" (can ha ga xuong)"));
    }
    DBG_PRINTLN();
  }
#endif

  DesiredAngleRoll  = stickExpo(rx[0]) * MAX_ANGLE_DEG;
  DesiredAnglePitch = stickExpo(rx[1]) * MAX_ANGLE_DEG;
  if (DesiredAngleRoll  >  MAX_TILT_DEG) DesiredAngleRoll  =  MAX_TILT_DEG;
  if (DesiredAngleRoll  < -MAX_TILT_DEG) DesiredAngleRoll  = -MAX_TILT_DEG;
  if (DesiredAnglePitch >  MAX_TILT_DEG) DesiredAnglePitch =  MAX_TILT_DEG;
  if (DesiredAnglePitch < -MAX_TILT_DEG) DesiredAnglePitch = -MAX_TILT_DEG;
  DesiredRateYaw = STICK_YAW_GAIN * (rx[3] - 1500);

  float chMode; noInterrupts(); chMode = ReceiverValue[MODE_CHANNEL]; interrupts();

  /* ---- CONG TAC CHE DO (CH7) ---------------------------------------
   *   <= MODE_THR_ALT : TU CAN BANG (giu goc bang tay)
   *   >  MODE_THR_ALT : GIU DO CAO (baro)  — ca nac giua va nac tren
   * ------------------------------------------------------------------ */
  bool wantHold = (chMode > MODE_THR_ALT);

  if (wantHold && !AltHoldOn) {
    HoverThrottle = rx[2];
    DesiredAltitude = AltitudeKalman;
    PrevErrorVelocityVertical = 0;
    PrevItermVelocityVertical = 0;
    PrevErrorAltitude = 0;
    PrevItermAltitude = 0;
    AltHoldOn = true;
  }
  if (!wantHold) AltHoldOn = false;

  if (AltHoldOn) {
    DesiredAltitude += STICK_ALT_GAIN * (rx[2] - 1500);
    ErrorAltitude = DesiredAltitude - AltitudeKalman;
    pid_equation(ErrorAltitude, PAltitude, IAltitude, DAltitude,
                 PrevErrorAltitude, PrevItermAltitude);
    DesiredVel = PIDReturn[0];
    PrevErrorAltitude = PIDReturn[1];
    PrevItermAltitude = PIDReturn[2];

    ErrorVelocityVertical = DesiredVel - VelocityKalman;
    pid_equation(ErrorVelocityVertical, PVelocityVertical, IVelocityVertical,
                 DVelocityVertical, PrevErrorVelocityVertical, PrevItermVelocityVertical);
    InputVertical = PIDReturn[0];
    PrevErrorVelocityVertical = PIDReturn[1];
    PrevItermVelocityVertical = PIDReturn[2];

    InputThrottle = HoverThrottle + InputVertical;
  } else {
    InputThrottle = rx[2];
  }

  ErrorAngleRoll  = DesiredAngleRoll  - KalmanAngleRoll;
  ErrorAnglePitch = DesiredAnglePitch - KalmanAnglePitch;

  pid_equation(ErrorAngleRoll, PAngleRoll, IAngleRoll, DAngleRoll,
               PrevErrorAngleRoll, PrevItermAngleRoll);
  DesiredRateRoll = PIDReturn[0];
  PrevErrorAngleRoll = PIDReturn[1]; PrevItermAngleRoll = PIDReturn[2];

  pid_equation(ErrorAnglePitch, PAnglePitch, IAnglePitch, DAnglePitch,
               PrevErrorAnglePitch, PrevItermAnglePitch);
  DesiredRatePitch = PIDReturn[0];
  PrevErrorAnglePitch = PIDReturn[1]; PrevItermAnglePitch = PIDReturn[2];

  ErrorRateRoll  = DesiredRateRoll  - RateRoll;
  ErrorRatePitch = DesiredRatePitch - RatePitch;
  ErrorRateYaw   = DesiredRateYaw   - RateYaw;

  pid_equation(ErrorRateRoll, PRateRoll, IRateRoll, DRateRoll,
               PrevErrorRateRoll, PrevItermRateRoll);
  InputRoll = PIDReturn[0];
  PrevErrorRateRoll = PIDReturn[1]; PrevItermRateRoll = PIDReturn[2];

  pid_equation(ErrorRatePitch, PRatePitch, IRatePitch, DRatePitch,
               PrevErrorRatePitch, PrevItermRatePitch);
  InputPitch = PIDReturn[0];
  PrevErrorRatePitch = PIDReturn[1]; PrevItermRatePitch = PIDReturn[2];

  pid_equation(ErrorRateYaw, PRateYaw, IRateYaw, DRateYaw,
               PrevErrorRateYaw, PrevItermRateYaw);
  InputYaw = PIDReturn[0];
  PrevErrorRateYaw = PIDReturn[1]; PrevItermRateYaw = PIDReturn[2];

  if (InputThrottle > THROTTLE_MAX_CMD) InputThrottle = THROTTLE_MAX_CMD;

  MotorInput1 = (InputThrottle - InputRoll - InputPitch - InputYaw);
  MotorInput2 = (InputThrottle - InputRoll + InputPitch + InputYaw);
  MotorInput3 = (InputThrottle + InputRoll + InputPitch - InputYaw);
  MotorInput4 = (InputThrottle + InputRoll - InputPitch + InputYaw);

  if (MotorInput1 > 2000) MotorInput1 = 1999;
  if (MotorInput2 > 2000) MotorInput2 = 1999;
  if (MotorInput3 > 2000) MotorInput3 = 1999;
  if (MotorInput4 > 2000) MotorInput4 = 1999;
  if (MotorInput1 < THROTTLE_IDLE) MotorInput1 = THROTTLE_IDLE;
  if (MotorInput2 < THROTTLE_IDLE) MotorInput2 = THROTTLE_IDLE;
  if (MotorInput3 < THROTTLE_IDLE) MotorInput3 = THROTTLE_IDLE;
  if (MotorInput4 < THROTTLE_IDLE) MotorInput4 = THROTTLE_IDLE;

  // ---- ARM LOGIC ----
#if ARM_CHANNEL != 255
  {
    float chArm; noInterrupts(); chArm = ReceiverValue[ARM_CHANNEL]; interrupts();
    if (chArm <= ARM_THRESHOLD) {
      if (Armed) {
#if DEBUG_ARM
        DBG_PRINTLN(F("[ARM] Disarm (cong tac TAT)"));
#endif
        Armed = false;
      }
    }
    else if (!Armed && rx[2] < ARM_THROTTLE_MAX) {
#if GYRO_RECAL_ON_ARM
      setMotors(THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT, THROTTLE_CUT);
      digitalWrite(LED_GREEN, LOW);
      for (uint8_t k = 0; k < 4; k++) {
        digitalWrite(LED_RED, HIGH); delay(60);
        digitalWrite(LED_RED, LOW);  delay(60);
      }
      calibrateGyro();
      digitalWrite(LED_GREEN, HIGH);
      reset_pid();
      LoopTimer = micros();
#endif
      Armed = true;
#if DEBUG_ARM
      DBG_PRINTLN(F("[ARM] >>> ARMED! <<<"));
#endif
    }
  }
#else
  Armed = true;
#endif

  if (!Armed || rx[2] < 1050) {
    MotorInput1 = MotorInput2 = MotorInput3 = MotorInput4 = THROTTLE_CUT;
    reset_pid();
  }

  setMotors((uint32_t)MotorInput1, (uint32_t)MotorInput2,
            (uint32_t)MotorInput3, (uint32_t)MotorInput4);

  uint32_t used = micros() - LoopTimer;
  if (used > LoopMaxUs) LoopMaxUs = used;

  while (micros() - LoopTimer < 4000);
  LoopTimer = micros();
}
