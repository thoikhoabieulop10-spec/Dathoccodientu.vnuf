#ifndef CONFIG_H
#define CONFIG_H

/* =====================================================================
 *  ############   MOI THONG SO CHINH DUOC DEU NAM O DAY   ############
 *
 *  MUC LUC (tim nhanh bang Ctrl+F, go so muc, vd "[7]"):
 *    [1]  Chan cam
 *    [2]  May thu va cong tac (ARM, che do bay)
 *    [3]  Telemetry ve tay cam
 *    [4]  Debug
 *    [5]  Cam bien gia toc va con quay (IMU)
 *    [6]  PID rate va PID goc (tu the)
 *    [7]  Ga, can dieu khien, bo tron motor
 *    [8]  Do cao (baro, Kalman, EKF, PID do cao)
 *
 *  BAN NAY CHI CO: TU CAN BANG + GIU DO CAO (baro). Khong la ban, khong GPS.
 *
 *  Cac tab khac chi con nhung hang so cua CHIP (dia chi thanh ghi, ma
 *  nhan dang, kich thuoc bo dem). Dung doi nhung so do.
 * =====================================================================
 */

/* =====================================================================
 *  [1] CHAN CAM — xem them file FC_F405_so_do_chan.pdf
 *
 *  Noi UART luon CHEO: TX cua thiet bi -> RX cua F405 va nguoc lai.
 * ===================================================================== */
// ICM-20602 va BMP388 dung chung SPI1 (SCK PA5, MISO PA6, MOSI PA7)
#define PIN_CS          PA4       // chip select ICM-20602
#define BMP_CS          PA3       // chip select BMP388

// ESC (TIM3 CH1..CH4)
#define M1_PIN          PC6
#define M2_PIN          PC7
#define M3_PIN          PC8
#define M4_PIN          PC9

// Den bao
#define LED_GREEN       PB3       // co song
#define LED_RED         PB4       // mat song (failsafe)
#define LED_GPS         PB5       // ban nay khong dung (luon tat)

// May thu ELRS (UART4): ELRS TX -> PA1, ELRS RX -> PA0
// PA0 BAT BUOC de gui telemetry ve tay cam.
#define CRSF_PIN_RX     PA1
#define CRSF_PIN_TX     PA0

// May thu PPM (chi khi RX_PROTOCOL = 0)
#define PPM_PIN         PA0

/* =====================================================================
 *  [2] MAY THU VA CONG TAC
 * ===================================================================== */
/* Giao thuc may thu:
 *   0 = PPM   (FlySky FS-iA6B, 8 kenh, day tin hieu vao PA0)
 *   1 = CRSF  (ELRS, 16 kenh, UART4 tren PA0/PA1)                     */
#define RX_PROTOCOL     1

/* Toc do CRSF. ELRS 3.x mac dinh 420000. Neu day da dung ma van "Khong
 * co song", thu 115200 (mot so may thu ELRS cu hoac hang nhai).      */
#define CRSF_BAUD       420000
#define CRSF_TIMEOUT_MS 500       // mat goi lau hon nay = MAT SONG (failsafe)

// PPM (chi khi RX_PROTOCOL = 0)
#define PPM_CH          8
#define PPM_MIN_US      900
#define PPM_MAX_US      2100
#define PPM_SYNC_US     3000
#define PPM_TIMEOUT_MS  500

// Cong tac ARM: kenh 5 (dem tu 0 nen la 4)
#define ARM_CHANNEL         4
#define ARM_THRESHOLD       1500  // tren muc nay = muon arm
#define ARM_THROTTLE_MAX    1050  // ga phai thap hon muc nay moi cho arm
#define GYRO_RECAL_ON_ARM   1     // 1 = hieu chuan lai con quay moi lan arm

/* Cong tac che do bay: kenh 7 (dem tu 0 nen la 6)
 *   duoi 1250        : tu can bang
 *   tren 1250        : giu do cao (baro) - nac giua va nac tren nhu nhau
 * Cong tac nam o kenh khac thi doi MODE_CHANNEL.                      */
#define MODE_CHANNEL    6
#define MODE_THR_ALT    1250

/* =====================================================================
 *  [3] TELEMETRY VE TAY CAM (ms giua hai goi cung loai)
 *
 *  Duong telemetry cua ELRS rat hep: thuc te chi ve duoc 5-7 goi CRSF
 *  moi giay. Gui nhanh hon kha nang truyen thi hang doi trong may thu
 *  dai ra va so lieu tren tay cam cang TRE.
 *    Van thay tre  -> tang cac so nay, hoac dat Telem Ratio trong
 *                     script ExpressLRS ve 1:4 hoac 1:8
 *    Muon muot hon -> giam TELEM_ATT_MS xuong 150, kem Telem Ratio 1:4
 * ===================================================================== */
#define TELEM_ATT_MS     200    // pitch, roll, yaw
#define TELEM_ALT_MS     250    // do cao baro
#define TELEM_VARIO_MS   500    // toc do len xuong
#define TELEM_FM_MS     1000    // che do bay

/* =====================================================================
 *  [4] DEBUG
 *
 *  DEBUG_ARM 1: in trang thai qua Serial (USB). In Serial CHAN vong lap
 *    nhieu ms -> chi dung tren ban, THAO CANH. Dat 0 truoc khi bay.
 *  DEBUG_EKF 1: in do cao baro va do cao EKF moi giay.
 *  VIBE_ANALYZE 1: ghi gyro tho vao bo dem de phan tich rung.
 * ===================================================================== */
#define DEBUG_ARM       0
#define DEBUG_EKF       0
#define VIBE_ANALYZE    0
#define NAV_DEBUG       1

/* =====================================================================
 *  [5] CAM BIEN GIA TOC VA CON QUAY (IMU)
 * ===================================================================== */
// Offset gia toc ke (g)
// So do lai sau khi roi (F405_drone_test menu z). So goc: 0.0209 / 0.0015 / -0.0090
#define ACC_OFFSET_X   (-0.0033)
#define ACC_OFFSET_Y   (-0.0048)
#define ACC_OFFSET_Z   (-0.0124)

/* Bo loc TREN CHIP ICM-20602 (loc truoc khi code doc, 250 lan/giay).
 * Phai cat duoc rung motor (do bang F405_drone_test menu v: 130-210 Hz)
 * vi code chi doc 250 lan/giay, rung tren 125 Hz khong loc se bi "gap"
 * xuong thanh dao dong gia o tan so thap.
 *   5 = 10 Hz, tre ~18 ms   <- DANG DUNG (bo loc goc, bay da quen)
 *   4 = 20 Hz, tre ~10 ms   (thu 28/09, da quay lai 30/09)
 *   3 = 41 Hz, tre ~6 ms
 * Motor nong / keu re re sau khi bay -> quay lai so lon hon.           */
#define GYRO_CHIP_DLPF     5

// Loc gyro trong code (biquad bac 2, sau bo loc chip)
#define GYRO_LPF_HZ        60.0f
#define GYRO_NOTCH_ENABLE  0
#define GYRO_NOTCH_HZ      83.0f
#define GYRO_NOTCH_BW      30.0f
/* 1 = EMA cu (GYRO_FILTER_ALPHA 0.15 ~ 6 Hz, tre ~23 ms - qua cham).
 * 0 = biquad GYRO_LPF_HZ (tre ~4 ms). Tong tre moi ~14 ms thay vi ~40 ms.
 * Muon quay ve ban cu: USE_OLD_EMA_FILTER 1 va GYRO_CHIP_DLPF 5.       */
#define USE_OLD_EMA_FILTER 1
#define GYRO_FILTER_ALPHA  0.15f

/* =====================================================================
 *  [6] PID RATE VA PID GOC (tu the)
 * ===================================================================== */
// PID rate: toc do quay (do/giay) -> lenh motor
float PRateRoll = 1.4,  PRatePitch = 1.4,  PRateYaw = 4.4;
float IRateRoll = 3.5,  IRatePitch = 3.5,  IRateYaw = 15.3;
float DRateRoll = 0.04, DRatePitch = 0.04, DRateYaw = 0.0;

// PID goc: goc nghieng (do) -> toc do quay mong muon
float PAngleRoll = 1.7, PAnglePitch = 1.7;
float IAngleRoll = 1.0, IAnglePitch = 0.5;
float DAngleRoll = 0.0, DAnglePitch = 0.0;

/* =====================================================================
 *  [7] GA, CAN DIEU KHIEN, BO TRON MOTOR
 * ===================================================================== */
#define ESC_PERIOD_US      4000   // chu ky PWM ESC (4000us = 250Hz)
#define THROTTLE_CUT       1000   // motor tat han (disarm, failsafe)
#define THROTTLE_IDLE      1180   // motor quay cham khi da arm
#define THROTTLE_MAX_CMD   1800   // ga toi da, chua cong PID
float HoverThrottle = 1500;       // ga de treo (dung khi giu do cao)

// Do nhay can dieu khien
#define MAX_ANGLE_DEG      55.0   // goc nghieng toi da khi day het can
#define STICK_EXPO         0.50
#define STICK_YAW_GAIN     (-0.15)
#define STICK_DEADBAND     0.03
#define MAX_TILT_DEG       60.0
#define STICK_ALT_GAIN     0.0008
/* =====================================================================
 *  [8] DO CAO
 *
 *  BMP388 lo giu do cao. Do cao tinh tu luc BAT NGUON.
 *  Luu y: PAltitude = 0 nghia la chi giu van toc dung bang 0, KHONG keo
 *  ve do cao cu, va can ga khong co tac dung khi dang giu do cao.
 * ===================================================================== */
// PID do cao: sai lech do cao -> van toc dung mong muon
float PAltitude = 0.0;
float IAltitude = 0.0;
float DAltitude = 0.0;

// PID van toc dung: sai lech van toc dung -> ga
float PVelocityVertical = 3.0;
float IVelocityVertical = 0.005;   // so goc. Drone tu tu ha xuong khi giu do cao -> thu 0.4
float DVelocityVertical = 0.08;

// Nhieu Kalman 2D
#define KAL2D_ACC_VAR   (30.0*30.0)
#define KAL2D_BARO_R    (30.0*30.0)

// EKF: toc do hoc bias gia toc ke
#define EKF_BIAS_VAR    (0.05f*0.05f)
#define EKF_BIAS_LIMIT  60.0f

/* =====================================================================
 *  ###################   HET PHAN CHINH THONG SO   ###################
 * =====================================================================
 */

#endif
